"""
Database configuration and session management
"""
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from pathlib import Path
import os

from app.config import settings

# Ensure data directory exists
DATA_DIR = Path("/app/data")
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Create async engine
DATABASE_URL = settings.database_url
engine = create_async_engine(DATABASE_URL, echo=settings.debug)

# Create session factory
async_session = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

# Base for models
Base = declarative_base()


async def init_db():
    """Initialize database tables"""
    from app.models import Image, DownloadJob, Setting
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db():
    """Close database connections"""
    await engine.dispose()


async def get_session() -> AsyncSession:
    """Get database session"""
    async with async_session() as session:
        yield session