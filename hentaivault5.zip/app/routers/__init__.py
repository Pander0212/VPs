"""
API routers package
"""
from .api import router as api
from .web import router as web
from .downloads import router as downloads
from .library import router as library
from .ai import router as ai

__all__ = ["api", "web", "downloads", "library", "ai"]