"""
Download routes
"""
from typing import List
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

from app.schemas import ImageResult, DownloadRequest, DownloadStatus
from app.services.downloader import DownloadService

router = APIRouter()
download_service = DownloadService()


class DownloadResponse(BaseModel):
    job_id: int
    status: str
    message: str


@router.post("/single")
async def download_single(image: ImageResult, background_tasks: BackgroundTasks):
    """Queue a single image for download"""
    try:
        job_id = await download_service.queue_download([image])
        return DownloadResponse(
            job_id=job_id,
            status="queued",
            message="Download queued successfully"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/batch")
async def download_batch(request: DownloadRequest, background_tasks: BackgroundTasks):
    """Queue multiple images for batch download"""
    try:
        job_id = await download_service.queue_download(
            request.images,
            create_zip=request.create_zip
        )
        return DownloadResponse(
            job_id=job_id,
            status="queued",
            message=f"Batch download queued ({len(request.images)} images)"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{job_id}")
async def get_download_status(job_id: int):
    """Get download job status"""
    try:
        status = await download_service.get_status(job_id)
        if not status:
            raise HTTPException(status_code=404, detail="Job not found")
        return status
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/active")
async def get_active_downloads():
    """Get list of active download jobs"""
    try:
        jobs = await download_service.get_active_jobs()
        return {"jobs": jobs}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cancel/{job_id}")
async def cancel_download(job_id: int):
    """Cancel a download job"""
    try:
        success = await download_service.cancel_job(job_id)
        if not success:
            raise HTTPException(status_code=404, detail="Job not found or already completed")
        return {"message": "Download cancelled"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))