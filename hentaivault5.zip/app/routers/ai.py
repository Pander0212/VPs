"""
AI integration routes for SillyTavern LocalImage
"""
from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.ai_service import AIService
from app.schemas import AISettings, AIGenerateRequest, AIGenerateResponse, VisionNamingRequest, VisionNamingResponse

router = APIRouter()
ai_service = AIService()


@router.get("/settings")
async def get_ai_settings():
    """Get current AI API settings"""
    try:
        settings = await ai_service.get_settings()
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/settings")
async def update_ai_settings(settings: AISettings):
    """Update AI API settings"""
    try:
        success = await ai_service.save_settings(settings)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to save settings")
        return {"message": "Settings saved successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/test")
async def test_ai_connection(settings: AISettings):
    """Test AI API connection"""
    try:
        result = await ai_service.test_connection(settings)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate")
async def generate_metadata(request: AIGenerateRequest):
    """Generate SillyTavern LocalImage metadata for images"""
    try:
        results = await ai_service.generate_metadata(
            image_ids=request.image_ids,
            image_urls=request.image_urls,
            use_vision=request.use_vision,
            tags=request.tags
        )
        return AIGenerateResponse(
            success=True,
            results=results
        )
    except Exception as e:
        return AIGenerateResponse(
            success=False,
            results=[],
            error=str(e)
        )


@router.post("/generate/batch")
async def generate_metadata_batch(request: AIGenerateRequest):
    """Generate metadata for multiple images in batch"""
    try:
        results = await ai_service.generate_metadata_batch(
            image_ids=request.image_ids,
            use_vision=request.use_vision
        )
        return AIGenerateResponse(
            success=True,
            results=results
        )
    except Exception as e:
        return AIGenerateResponse(
            success=False,
            results=[],
            error=str(e)
        )


@router.get("/default-prompt")
async def get_default_prompt():
    """Get the default system prompt for SillyTavern LocalImage"""
    prompt = """You are an expert at creating concise, memorable names and descriptions for images used in SillyTavern's LocalImage extension.

Your task is to analyze image tags and generate:

1. A SHORT NAME (kebab-case or snake_case, 1-3 words):
   - Must be memorable and easy to type
   - Examples: bedroom_night, red_dress_outfit, enchanted_sword, forest_clearing, cozy_cafe
   - Perfect for SillyTavern syntax like ::img CharacterName bedroom_night::

2. A SHORT DESCRIPTION (1-2 sentences):
   - Briefly describe the scene, setting, or subject
   - Keep it concise but evocative
   - Example: "A cozy bedroom scene at night with soft lighting. Perfect for intimate conversations."

Rules:
- Names should be generic enough to reuse across characters but specific enough to be useful
- Avoid overly long or complex names
- Focus on the setting, mood, or key visual elements
- The name will be used with ::img syntax, so keep it simple

Respond in this exact format:
NAME: <your_kebab_case_name>
DESCRIPTION: <your description here>"""
    
    return {"prompt": prompt}


@router.post("/vision-name")
async def vision_name_image(request: VisionNamingRequest):
    """Generate a name for an image by analyzing its actual content via AI vision.
    
    This endpoint reads the image file from disk, converts it to base64,
    and sends it to the configured AI vision model to generate a name
    based on the actual visual content of the image.
    """
    try:
        result = await ai_service.generate_name_from_image(request.image_id)
        return VisionNamingResponse(
            success=True,
            name=result.get("name"),
            description=result.get("description")
        )
    except ValueError as e:
        return VisionNamingResponse(
            success=False,
            error=str(e)
        )
    except Exception as e:
        return VisionNamingResponse(
            success=False,
            error=f"Unexpected error: {str(e)}"
        )