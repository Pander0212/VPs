"""
Danbooru.donmai.us scraper - uses official API
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class DanbooruScraper(BaseScraper):
    """Danbooru.donmai.us API scraper"""
    
    name = "danbooru"
    base_url = "https://danbooru.donmai.us"
    api_url = f"{base_url}/posts.json"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Danbooru"""
        
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 100
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            
            if not isinstance(data, list):
                return {"images": [], "total": 0, "page": page, "has_more": False}
            
            images = [self._parse_image(img) for img in data]
            
            # Danbooru doesn't provide total count easily
            has_more = len(images) == 100
            
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        # Danbooru has tag_string_* fields
        tags = []
        if data.get("tag_string"):
            tags = [t.strip() for t in data["tag_string"].split() if t.strip()]
        
        # Get file URLs
        file_url = data.get("file_url", "")
        preview_url = data.get("preview_file_url", "")
        sample_url = data.get("large_file_url", "")
        
        # Construct full URLs if relative
        if file_url and file_url.startswith("/"):
            file_url = f"{self.base_url}{file_url}"
        if preview_url and preview_url.startswith("/"):
            preview_url = f"{self.base_url}{preview_url}"
        if sample_url and sample_url.startswith("/"):
            sample_url = f"{self.base_url}{sample_url}"
        
        # Extract artist and character
        artist = None
        character = None
        if data.get("tag_string_artist"):
            artist = data["tag_string_artist"].split()[0] if data["tag_string_artist"] else None
        if data.get("tag_string_character"):
            character = data["tag_string_character"].split()[0] if data["tag_string_character"] else None
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/posts/{data.get('id')}",
            "file_url": file_url,
            "preview_url": preview_url,
            "sample_url": sample_url,
            "width": data.get("image_width"),
            "height": data.get("image_height"),
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_ext"),
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("score", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details"""
        url = f"{self.base_url}/posts/{image_id}.json"
        
        try:
            data = await self.fetch_json(url)
            if data:
                return self._parse_image(data)
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images"""
        # Danbooru has an explore page
        url = f"{self.base_url}/explore/posts/popular.json"
        
        # Map timeframe
        scale_map = {
            "day": "day",
            "week": "week",
            "month": "month"
        }
        scale = scale_map.get(timeframe, "week")
        
        params = {
            "scale": scale,
            "limit": 50
        }
        
        try:
            data = await self.fetch_json(url, params)
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data[:50]]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            pass
        
        # Fallback to score search
        params = {
            "tags": "order:score",
            "limit": 50
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data[:50]]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        params = {
            "tags": "order:random",
            "limit": count
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data[:count]]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions"""
        url = f"{self.base_url}/tags.json"
        params = {
            "search[name_matches]": f"{partial}*",
            "search[order]": "count",
            "limit": 10
        }
        
        try:
            data = await self.fetch_json(url, params)
            if isinstance(data, list):
                suggestions = []
                for tag in data:
                    suggestions.append({
                        "tag": tag.get("name", ""),
                        "count": tag.get("post_count", 0),
                        "type": tag.get("category", "general")
                    })
                return suggestions
        except Exception:
            pass
        return []