"""
nhentai.net scraper - uses API
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class NhentaiScraper(BaseScraper):
    """nhentai.net scraper"""
    
    name = "nhentai"
    base_url = "https://nhentai.net"
    api_url = "https://nhentai.net/api"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search nhentai"""
        
        # Build query
        tags = []
        if query:
            tags.append(query)
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "query": " ".join(tags) if tags else "",
            "page": page
        }
        
        try:
            data = await self.fetch_json(f"{self.api_url}/galleries/search", params)
            
            results = data.get("result", [])
            if not isinstance(results, list):
                return {"images": [], "total": 0, "page": page, "has_more": False}
            
            images = [self._parse_gallery(gallery) for gallery in results]
            
            # nhentai returns galleries, not individual images
            # We'll treat each gallery as an "image" for the UI
            
            has_more = len(images) == 25  # nhentai default page size
            
            return {
                "images": images,
                "total": data.get("num_pages", 0) * 25,
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    def _parse_gallery(self, data: Dict) -> Dict[str, Any]:
        """Parse gallery data"""
        gallery_id = data.get("id", "")
        media_id = data.get("media_id", "")
        
        # Get cover image
        images = data.get("images", {})
        cover = images.get("cover", {})
        
        # Build cover URL
        cover_ext = cover.get("t", "j")  # j for jpg, p for png
        ext_map = {"j": "jpg", "p": "png", "g": "gif"}
        cover_ext = ext_map.get(cover_ext, "jpg")
        
        cover_url = f"https://t.nhentai.net/galleries/{media_id}/cover.{cover_ext}"
        
        # Get tags
        tags = []
        artist = None
        character = None
        
        for tag in data.get("tags", []):
            tag_name = tag.get("name", "")
            tag_type = tag.get("type", "")
            tags.append(tag_name)
            
            if tag_type == "artist":
                artist = tag_name
            elif tag_type == "character":
                character = tag_name
        
        return {
            "source_site": self.name,
            "source_id": str(gallery_id),
            "source_url": f"{self.base_url}/g/{gallery_id}",
            "file_url": cover_url,  # Use cover as main image
            "preview_url": cover_url,
            "sample_url": cover_url,
            "width": cover.get("w"),
            "height": cover.get("h"),
            "file_size": None,
            "file_ext": cover_ext,
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": "explicit",  # nhentai is always explicit
            "score": data.get("num_favorites", 0),
            "title": data.get("title", {}).get("english", ""),
            "pages": data.get("num_pages", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get gallery details"""
        try:
            data = await self.fetch_json(f"{self.api_url}/gallery/{image_id}")
            if data:
                return self._parse_gallery(data)
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular galleries"""
        try:
            data = await self.fetch_json(f"{self.base_url}/api/galleries/all", {"page": 1})
            results = data.get("result", [])
            if isinstance(results, list):
                images = [self._parse_gallery(gallery) for gallery in results[:50]]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            pass
        return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random galleries"""
        # nhentai doesn't have a random endpoint
        # Use popular as fallback
        return await self.get_popular()
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions"""
        try:
            data = await self.fetch_json(f"{self.api_url}/galleries/search", {"query": partial, "page": 1})
            results = data.get("result", [])
            
            # Extract unique tags from results
            tag_counts = {}
            for gallery in results:
                for tag in gallery.get("tags", []):
                    tag_name = tag.get("name", "")
                    if partial.lower() in tag_name.lower():
                        tag_counts[tag_name] = tag_counts.get(tag_name, 0) + 1
            
            suggestions = []
            for tag_name, count in sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
                suggestions.append({
                    "tag": tag_name,
                    "count": count,
                    "type": "general"
                })
            
            return suggestions
        except Exception:
            return []