"""
Gelbooru.com scraper - uses official API
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class GelbooruScraper(BaseScraper):
    """Gelbooru.com API scraper"""
    
    name = "gelbooru"
    base_url = "https://gelbooru.com/index.php"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Gelbooru"""
        
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": " ".join(tags) if tags else "",
            "pid": page - 1,
            "limit": 100,
            "json": 1
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            
            if not data or "post" not in data:
                return {"images": [], "total": 0, "page": page, "has_more": False}
            
            posts = data.get("post", [])
            if not isinstance(posts, list):
                posts = [posts]
            
            images = [self._parse_image(img) for img in posts]
            
            # Gelbooru provides count in @attributes
            total = data.get("@attributes", {}).get("count", len(images))
            has_more = len(images) == 100
            
            return {
                "images": images,
                "total": total,
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        tags = []
        if data.get("tags"):
            tags = [t.strip() for t in data["tags"].split() if t.strip()]
        
        # Extract artist and character from tags
        artist = None
        character = None
        for tag in tags:
            if tag.startswith("artist:"):
                artist = tag.split(":", 1)[1]
            elif tag.startswith("character:"):
                character = tag.split(":", 1)[1]
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"https://gelbooru.com/index.php?page=post&s=view&id={data.get('id')}",
            "file_url": data.get("file_url", ""),
            "preview_url": data.get("preview_url", ""),
            "sample_url": data.get("sample_url", ""),
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_url", "").split(".")[-1] if data.get("file_url") else None,
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("score", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "id": image_id,
            "json": 1
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            if data and "post" in data:
                posts = data["post"]
                if isinstance(posts, list) and len(posts) > 0:
                    return self._parse_image(posts[0])
                elif isinstance(posts, dict):
                    return self._parse_image(posts)
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": "order:score",
            "limit": 50,
            "json": 1
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            posts = data.get("post", [])
            if not isinstance(posts, list):
                posts = [posts]
            images = [self._parse_image(img) for img in posts[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": "sort:random",
            "limit": count,
            "json": 1
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            posts = data.get("post", [])
            if not isinstance(posts, list):
                posts = [posts]
            images = [self._parse_image(img) for img in posts[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions"""
        params = {
            "page": "dapi",
            "s": "tag",
            "q": "index",
            "name_pattern": f"{partial}*",
            "order": "count",
            "json": 1
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            tags = data.get("tag", [])
            if not isinstance(tags, list):
                tags = [tags]
            
            suggestions = []
            for tag in tags[:10]:
                suggestions.append({
                    "tag": tag.get("name", ""),
                    "count": tag.get("count", 0),
                    "type": self._get_tag_type(tag.get("type", 0))
                })
            return suggestions
        except Exception:
            return []
    
    def _get_tag_type(self, type_id: int) -> str:
        """Convert tag type ID to name"""
        types = {
            0: "general",
            1: "artist",
            3: "copyright",
            4: "character"
        }
        return types.get(type_id, "general")