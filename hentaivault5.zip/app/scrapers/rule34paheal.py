"""
Rule34.paheal.net scraper - uses Shimmie API (XML-based)
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper
import xml.etree.ElementTree as ET


class Rule34PahealScraper(BaseScraper):
    """Rule34.paheal.net API scraper (Shimmie-based)"""
    
    name = "rule34paheal"
    base_url = "https://rule34.paheal.net"
    api_url = f"{base_url}/api/danbooru/find_posts"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Rule34.paheal"""
        
        tags = []
        if query:
            tags.append(query)
        if rating:
            rating_map = {"safe": "safe", "questionable": "questionable", "explicit": "explicit"}
            tags.append(f"rating:{rating_map.get(rating, rating)}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "tags": " ".join(tags) if tags else "all",
            "limit": 100,
            "offset": (page - 1) * 100
        }
        
        try:
            response = await self.fetch(self.api_url, params)
            xml_text = response.text
            
            # Parse XML
            root = ET.fromstring(xml_text)
            posts = []
            
            for post_elem in root.findall('tag'):
                post_data = {
                    'id': post_elem.get('id', ''),
                    'md5': post_elem.get('md5', ''),
                    'file_name': post_elem.get('file_name', ''),
                    'file_url': post_elem.get('file_url', ''),
                    'height': post_elem.get('height', ''),
                    'width': post_elem.get('width', ''),
                    'preview_url': post_elem.get('preview_url', ''),
                    'preview_height': post_elem.get('preview_height', ''),
                    'preview_width': post_elem.get('preview_width', ''),
                    'rating': post_elem.get('rating', ''),
                    'tags': post_elem.get('tags', ''),
                    'score': post_elem.get('score', '0'),
                    'author': post_elem.get('author', ''),
                    'source': post_elem.get('source', '')
                }
                posts.append(post_data)
            
            images = [self._parse_image(img) for img in posts]
            has_more = len(posts) == 100
            
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        tags = []
        if data.get("tags"):
            tags = [t.strip() for t in data["tags"].split() if t.strip()]
        
        artist = None
        character = None
        if data.get("author"):
            artist = data["author"]
        
        for tag in tags:
            if tag.startswith("character:"):
                character = tag.split(":", 1)[1]
        
        file_url = data.get("file_url", "")
        extension = file_url.split(".")[-1] if file_url else None
        
        # Convert string values to appropriate types
        try:
            width = int(data.get("width", 0)) if data.get("width") else None
        except:
            width = None
        try:
            height = int(data.get("height", 0)) if data.get("height") else None
        except:
            height = None
        try:
            score = int(data.get("score", 0)) if data.get("score") else 0
        except:
            score = 0
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/post/view/{data.get('id')}",
            "file_url": file_url,
            "preview_url": data.get("preview_url", ""),
            "sample_url": data.get("preview_url", ""),
            "width": width,
            "height": height,
            "file_size": None,
            "file_ext": extension,
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating") if data.get("rating") != "?" else None,
            "score": score
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details by ID"""
        params = {
            "id": image_id
        }
        
        try:
            response = await self.fetch(self.api_url, params)
            xml_text = response.text
            root = ET.fromstring(xml_text)
            
            post_elem = root.find('tag')
            if post_elem is not None:
                post_data = {
                    'id': post_elem.get('id', ''),
                    'md5': post_elem.get('md5', ''),
                    'file_name': post_elem.get('file_name', ''),
                    'file_url': post_elem.get('file_url', ''),
                    'height': post_elem.get('height', ''),
                    'width': post_elem.get('width', ''),
                    'preview_url': post_elem.get('preview_url', ''),
                    'preview_height': post_elem.get('preview_height', ''),
                    'preview_width': post_elem.get('preview_width', ''),
                    'rating': post_elem.get('rating', ''),
                    'tags': post_elem.get('tags', ''),
                    'score': post_elem.get('score', '0'),
                    'author': post_elem.get('author', ''),
                    'source': post_elem.get('source', '')
                }
                return self._parse_image(post_data)
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images"""
        params = {
            "tags": "order:score",
            "limit": 50,
            "offset": 0
        }
        
        try:
            response = await self.fetch(self.api_url, params)
            xml_text = response.text
            root = ET.fromstring(xml_text)
            
            posts = []
            for post_elem in root.findall('tag'):
                post_data = {attr: post_elem.get(attr, '') for attr in 
                           ['id', 'md5', 'file_name', 'file_url', 'height', 'width',
                            'preview_url', 'preview_height', 'preview_width', 'rating',
                            'tags', 'score', 'author', 'source']}
                posts.append(post_data)
            
            images = [self._parse_image(img) for img in posts[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        params = {
            "tags": "order:random",
            "limit": count,
            "offset": 0
        }
        
        try:
            response = await self.fetch(self.api_url, params)
            xml_text = response.text
            root = ET.fromstring(xml_text)
            
            posts = []
            for post_elem in root.findall('tag'):
                post_data = {attr: post_elem.get(attr, '') for attr in 
                           ['id', 'md5', 'file_name', 'file_url', 'height', 'width',
                            'preview_url', 'preview_height', 'preview_width', 'rating',
                            'tags', 'score', 'author', 'source']}
                posts.append(post_data)
            
            images = [self._parse_image(img) for img in posts[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions"""
        params = {
            "page": "tags",
            "q": "list",
            "s": partial
        }
        
        try:
            html = await self.fetch_html(f"{self.base_url}/index.php", params)
            # Parse HTML for tag suggestions
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'lxml')
            suggestions = []
            
            for row in soup.select('table tr')[:10]:
                cols = row.find_all('td')
                if len(cols) >= 2:
                    tag = cols[0].get_text(strip=True)
                    if partial.lower() in tag.lower():
                        suggestions.append({
                            "tag": tag,
                            "count": int(cols[1].get_text(strip=True)) if cols[1].get_text(strip=True).isdigit() else 0,
                            "type": "general"
                        })
            
            return suggestions
        except Exception:
            return []