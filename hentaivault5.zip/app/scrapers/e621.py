"""
e621.net scraper - uses official API
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class E621Scraper(BaseScraper):
    """e621.net API scraper"""
    
    name = "e621"
    base_url = "https://e621.net"
    api_url = f"{base_url}/posts.json"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search e621"""
        
        tags = []
        if query:
            tags.append(query)
        if rating:
            rating_map = {"safe": "rating:s", "questionable": "rating:q", "explicit": "rating:e"}
            tags.append(rating_map.get(rating, f"rating:{rating}"))
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 100
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            
            posts = data.get("posts", [])
            if not isinstance(posts, list):
                return {"images": [], "total": 0, "page": page, "has_more": False}
            
            images = [self._parse_image(img) for img in posts]
            # Filter out None results (images without valid URLs)
            images = [img for img in images if img is not None]
            
            has_more = len(images) == 100
            
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        post = data.get("file", {}) or {}
        preview = data.get("preview", {}) or {}
        sample = data.get("sample", {}) or {}
        tags = data.get("tags", {}) or {}
        
        # Combine all tags
        all_tags = []
        for tag_type, tag_list in tags.items():
            if isinstance(tag_list, list):
                all_tags.extend(tag_list)
        
        # Get artist and character
        artist = None
        character = None
        if tags.get("artist"):
            artist = tags["artist"][0] if tags["artist"] else None
        if tags.get("character"):
            character = tags["character"][0] if tags["character"] else None
        
        # Get URLs - ensure we always have a fallback
        file_url = post.get("url", "") or ""
        preview_url = preview.get("url", "") or file_url
        sample_url = sample.get("url", "") or file_url
        
        # If no URLs, use a placeholder or skip
        if not file_url and not preview_url:
            return None  # Signal to skip this image
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/posts/{data.get('id')}",
            "file_url": file_url,
            "preview_url": preview_url,
            "sample_url": sample_url,
            "width": post.get("width"),
            "height": post.get("height"),
            "file_size": post.get("size"),
            "file_ext": post.get("ext"),
            "tags": all_tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("score", {}).get("total", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details"""
        url = f"{self.base_url}/posts/{image_id}.json"
        
        try:
            data = await self.fetch_json(url)
            if data and "post" in data:
                return self._parse_image(data["post"])
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images"""
        # e621 has popular posts endpoint
        url = f"{self.base_url}/popular.json"
        
        try:
            data = await self.fetch_json(url)
            posts = data.get("posts", [])
            if isinstance(posts, list):
                images = [self._parse_image(img) for img in posts[:50]]
                images = [img for img in images if img is not None]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            pass
        
        # Fallback to score search
        params = {
            "tags": "order:score",
            "limit": 50
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", [])
            if isinstance(posts, list):
                images = [self._parse_image(img) for img in posts[:50]]
                images = [img for img in images if img is not None]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        params = {
            "tags": "order:random",
            "limit": count
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", [])
            if isinstance(posts, list):
                images = [self._parse_image(img) for img in posts[:count]]
                images = [img for img in images if img is not None]
                return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions"""
        url = f"{self.base_url}/tags.json"
        params = {
            "search[name_matches]": f"{partial}*",
            "search[order]": "count",
            "limit": 10
        }
        
        try:
            data = await self.fetch_json(url, params)
            if isinstance(data, list):
                suggestions = []
                for tag in data:
                    suggestions.append({
                        "tag": tag.get("name", ""),
                        "count": tag.get("post_count", 0),
                        "type": tag.get("category", "general")
                    })
                return suggestions
        except Exception:
            pass
        return []