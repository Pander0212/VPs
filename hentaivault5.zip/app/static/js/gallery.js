// Gallery-specific JavaScript

function galleryApp() {
    return {
        images: [],
        selectedImages: [],
        searchQuery: '',
        selectedSite: '',
        rating: '',
        page: 1,
        hasMore: false,
        loading: false,
        totalImages: 0,
        availableSites: [],
        modalOpen: false,
        selectedImage: null,
        
        init() {
            this.loadSites();
            this.parseUrlParams();
        },
        
        async loadSites() {
            try {
                const response = await fetch('/api/sites');
                const data = await response.json();
                this.availableSites = data.sites;
            } catch (error) {
                console.error('Failed to load sites:', error);
            }
        },
        
        parseUrlParams() {
            const params = new URLSearchParams(window.location.search);
            this.searchQuery = params.get('q') || '';
            this.selectedSite = params.get('site') || '';
            this.rating = params.get('rating') || '';
            
            const type = params.get('type');
            if (type === 'popular') {
                this.loadPopular();
            } else if (type === 'random') {
                this.loadRandom();
            } else if (this.searchQuery) {
                this.search();
            }
        },
        
        async search() {
            this.loading = true;
            this.page = 1;
            this.images = [];
            
            try {
                const sites = this.selectedSite || 'rule34';
                const response = await fetch(`/api/search?query=${encodeURIComponent(this.searchQuery)}&sites=${sites}&page=${this.page}&rating=${this.rating}`);
                const data = await response.json();
                
                this.processResults(data);
            } catch (error) {
                console.error('Search failed:', error);
            } finally {
                this.loading = false;
            }
        },
        
        async loadPopular() {
            this.loading = true;
            const site = this.selectedSite || 'rule34';
            
            try {
                const response = await fetch(`/api/popular?site=${site}`);
                const data = await response.json();
                this.images = data.images || [];
                this.totalImages = data.total;
                this.hasMore = data.has_more;
            } catch (error) {
                console.error('Failed to load popular:', error);
            } finally {
                this.loading = false;
            }
        },
        
        async loadRandom() {
            this.loading = true;
            const site = this.selectedSite || 'rule34';
            
            try {
                const response = await fetch(`/api/random?site=${site}&count=50`);
                const data = await response.json();
                this.images = data.images || [];
                this.totalImages = data.total;
                this.hasMore = data.has_more;
            } catch (error) {
                console.error('Failed to load random:', error);
            } finally {
                this.loading = false;
            }
        },
        
        processResults(data) {
            const allImages = [];
            for (const [site, result] of Object.entries(data.results || {})) {
                allImages.push(...(result.images || []));
            }
            this.images = allImages;
            this.totalImages = data.total_images;
            this.hasMore = Object.values(data.results || {}).some(r => r.has_more);
        },
        
        async loadMore() {
            this.page++;
            this.loading = true;
            
            try {
                const sites = this.selectedSite || 'rule34';
                const response = await fetch(`/api/search?query=${encodeURIComponent(this.searchQuery)}&sites=${sites}&page=${this.page}&rating=${this.rating}`);
                const data = await response.json();
                
                const allImages = [];
                for (const [site, result] of Object.entries(data.results || {})) {
                    allImages.push(...(result.images || []));
                }
                this.images.push(...allImages);
                this.hasMore = Object.values(data.results || {}).some(r => r.has_more);
            } catch (error) {
                console.error('Failed to load more:', error);
            } finally {
                this.loading = false;
            }
        },
        
        toggleSelection(img) {
            const index = this.selectedImages.indexOf(img);
            if (index > -1) {
                this.selectedImages.splice(index, 1);
            } else {
                this.selectedImages.push(img);
            }
        },
        
        selectAll() {
            this.selectedImages = [...this.images];
        },
        
        openModal(img) {
            this.selectedImage = img;
            this.modalOpen = true;
        },
        
        async quickDownload(img) {
            try {
                const response = await fetch('/api/downloads/single', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(img)
                });
                const data = await response.json();
                alert('Download queued! Job ID: ' + data.job_id);
            } catch (error) {
                console.error('Download failed:', error);
                alert('Download failed');
            }
        },
        
        async downloadSelected() {
            try {
                const response = await fetch('/api/downloads/batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        images: this.selectedImages,
                        create_zip: true
                    })
                });
                const data = await response.json();
                alert('Batch download queued! Job ID: ' + data.job_id);
                this.selectedImages = [];
            } catch (error) {
                console.error('Batch download failed:', error);
                alert('Batch download failed');
            }
        }
    };
}