// AI integration JavaScript

function aiApp() {
    return {
        aiSettings: {
            enabled: false,
            base_url: '',
            api_key: '',
            model: 'gpt-4o',
            system_prompt: ''
        },
        saving: false,
        testing: false,
        testResult: null,
        
        async init() {
            await this.loadSettings();
        },
        
        async loadSettings() {
            try {
                const response = await fetch('/api/ai/settings');
                const data = await response.json();
                this.aiSettings = { ...this.aiSettings, ...data };
            } catch (error) {
                console.error('Failed to load AI settings:', error);
            }
        },
        
        async saveSettings() {
            this.saving = true;
            try {
                const response = await fetch('/api/ai/settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.aiSettings)
                });
                const data = await response.json();
                alert(data.message || 'Settings saved');
            } catch (error) {
                console.error('Failed to save AI settings:', error);
                alert('Failed to save settings');
            } finally {
                this.saving = false;
            }
        },
        
        async testConnection() {
            this.testing = true;
            this.testResult = null;
            
            try {
                const response = await fetch('/api/ai/test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.aiSettings)
                });
                this.testResult = await response.json();
            } catch (error) {
                this.testResult = { success: false, message: error.message };
            } finally {
                this.testing = false;
            }
        },
        
        async resetPrompt() {
            try {
                const response = await fetch('/api/ai/default-prompt');
                const data = await response.json();
                this.aiSettings.system_prompt = data.prompt;
            } catch (error) {
                console.error('Failed to load default prompt:', error);
            }
        }
    };
}

// Batch AI generation helper
async function generateBatchMetadata(imageIds, onProgress) {
    const results = [];
    const batchSize = 5;
    
    for (let i = 0; i < imageIds.length; i += batchSize) {
        const batch = imageIds.slice(i, i + batchSize);
        
        try {
            const response = await fetch('/api/ai/generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image_ids: batch })
            });
            
            const data = await response.json();
            if (data.success) {
                results.push(...data.results);
            }
            
            if (onProgress) {
                onProgress(Math.min(i + batchSize, imageIds.length), imageIds.length);
            }
            
            // Small delay between batches
            await new Promise(r => setTimeout(r, 500));
            
        } catch (error) {
            console.error('Batch generation error:', error);
        }
    }
    
    return results;
}

// Vision-based image naming
async function visionNameImage(imageId) {
    try {
        const response = await fetch('/api/ai/vision-name', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image_id: imageId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            return {
                success: true,
                name: data.name,
                description: data.description
            };
        } else {
            return {
                success: false,
                error: data.error || 'Unknown error'
            };
        }
    } catch (error) {
        console.error('Vision naming error:', error);
        return {
            success: false,
            error: error.message || 'Network error'
        };
    }
}

// Batch vision naming
async function visionNameBatch(imageIds, onProgress) {
    const results = [];
    
    // Vision naming processes one at a time (each image needs individual API call)
    for (let i = 0; i < imageIds.length; i++) {
        const result = await visionNameImage(imageIds[i]);
        results.push({ id: imageIds[i], ...result });
        
        if (onProgress) {
            onProgress(i + 1, imageIds.length);
        }
        
        // Small delay between calls to avoid rate limiting
        if (i < imageIds.length - 1) {
            await new Promise(r => setTimeout(r, 1000));
        }
    }
    
    return results;
}