"""
Pydantic schemas for API requests/responses
"""
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class SearchRequest(BaseModel):
    """Search request parameters"""
    query: str = Field(..., min_length=1, max_length=500)
    sites: List[str] = Field(default_factory=lambda: ["rule34"])
    page: int = Field(default=1, ge=1)
    rating: Optional[str] = None  # safe, questionable, explicit
    artist: Optional[str] = None
    character: Optional[str] = None


class ImageResult(BaseModel):
    """Single image result"""
    source_site: str
    source_id: str
    source_url: str
    file_url: Optional[str] = None  # Some posts may not have file_url
    preview_url: Optional[str] = None
    sample_url: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    file_size: Optional[int] = None
    file_ext: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    artist: Optional[str] = None
    character: Optional[str] = None
    rating: Optional[str] = None
    score: Optional[int] = None


class SearchResult(BaseModel):
    """Search results response"""
    images: List[ImageResult]
    total: int
    page: int
    has_more: bool
    site: str


class MultiSearchResult(BaseModel):
    """Multi-site search results"""
    results: Dict[str, SearchResult]  # keyed by site name
    total_images: int


class DownloadRequest(BaseModel):
    """Download request for single or batch"""
    images: List[ImageResult]
    create_zip: bool = True


class DownloadStatus(BaseModel):
    """Download job status"""
    job_id: int
    status: str
    progress: int
    total: int
    result_url: Optional[str] = None


class AISettings(BaseModel):
    """AI API configuration"""
    enabled: bool = False
    base_url: str = ""
    api_key: str = ""
    model: str = "gpt-4o"
    system_prompt: Optional[str] = None


class AIGenerateRequest(BaseModel):
    """Request for AI metadata generation"""
    image_ids: List[int] = Field(default_factory=list)
    image_urls: List[str] = Field(default_factory=list)  # For new images not yet downloaded
    use_vision: bool = False
    tags: List[str] = Field(default_factory=list)  # Manual tags to include


class VisionNamingRequest(BaseModel):
    """Request for vision-based naming"""
    image_id: int


class VisionNamingResponse(BaseModel):
    """Response for vision-based naming"""
    success: bool
    name: Optional[str] = None
    description: Optional[str] = None
    error: Optional[str] = None


class SillyTavernMetadata(BaseModel):
    """Generated SillyTavern LocalImage metadata"""
    name: str  # kebab-case, 1-3 words
    description: str  # 1-2 sentences


class AIGenerateResponse(BaseModel):
    """AI generation response"""
    success: bool
    results: List[Dict[str, Any]]  # list of {image_id: int, name: str, description: str}
    error: Optional[str] = None


class LibraryFilter(BaseModel):
    """Library search filters"""
    query: Optional[str] = None
    site: Optional[str] = None
    artist: Optional[str] = None
    character: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    rating: Optional[str] = None
    has_st_metadata: Optional[bool] = None
    page: int = Field(default=1, ge=1)
    per_page: int = Field(default=50, ge=1, le=200)


class LibraryImage(BaseModel):
    """Library image with full metadata"""
    id: int
    source_site: str
    source_id: str
    local_filename: str
    local_url: str  # URL to served file
    file_url: str  # Original source URL
    preview_url: Optional[str]
    width: Optional[int]
    height: Optional[int]
    file_ext: str
    tags: List[str]
    artist: Optional[str]
    character: Optional[str]
    rating: Optional[str]
    score: int
    st_name: Optional[str]
    st_description: Optional[str]
    downloaded_at: datetime


class LibraryResponse(BaseModel):
    """Library search results"""
    images: List[LibraryImage]
    total: int
    page: int
    per_page: int
    has_more: bool


class TagSuggestion(BaseModel):
    """Tag autocomplete suggestion"""
    tag: str
    count: Optional[int] = None
    type: Optional[str] = None  # general, artist, character, copyright


class SettingsResponse(BaseModel):
    """Full application settings"""
    # Download settings
    max_concurrent_downloads: int = 5
    
    # Scraper settings
    request_timeout: int = 30
    rate_limit_delay: float = 0.5
    enabled_sites: List[str] = Field(default_factory=list)
    
    # Proxy settings  
    proxy_enabled: bool = False
    proxy_url: Optional[str] = None
    
    # AI settings
    ai: AISettings = Field(default_factory=AISettings)