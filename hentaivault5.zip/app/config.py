"""
Application configuration
"""
import os
from pathlib import Path
from typing import Optional, List
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application settings"""
    
    # Server settings
    app_name: str = "HentaiVault"
    host: str = "0.0.0.0"
    port: int = 8080
    debug: bool = False
    
    # Database
    database_url: str = "sqlite+aiosqlite:///data/hentaivault.db"
    
    # Download settings
    downloads_dir: Path = Path("/app/downloads")
    max_concurrent_downloads: int = 5
    download_chunk_size: int = 8192
    
    # Scraper settings
    request_timeout: int = 30
    rate_limit_delay: float = 0.5
    user_agent: str = "HentaiVault/1.0 (Self-hosted Image Archiver)"
    
    # Proxy settings
    proxy_enabled: bool = False
    proxy_url: Optional[str] = None
    
    # AI API settings
    ai_api_enabled: bool = False
    ai_api_base_url: Optional[str] = None
    ai_api_key: Optional[str] = None
    ai_api_model: str = "gpt-4o"
    
    # Supported sites
    enabled_sites: List[str] = Field(
        default_factory=lambda: [
            "rule34",
            "rule34paheal",
            "gelbooru",
            "safebooru",
            "danbooru",
            "e621",
            "e926",
            "nhentai"
        ]
    )
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()


def load_user_config() -> dict:
    """Load user configuration from JSON file"""
    config_path = Path("/app/config.json")
    if config_path.exists():
        with open(config_path, "r") as f:
            return json.load(f)
    return {}


def save_user_config(config: dict) -> bool:
    """Save user configuration to JSON file"""
    config_path = Path("/app/config.json")
    try:
        import json
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        return True
    except Exception:
        return False