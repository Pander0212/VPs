# HentaiVault 🎨

A self-hosted, production-ready web application for searching, browsing, and downloading images from multiple adult image boards (Booru sites). Designed for personal offline archiving.

## Features

- **Multi-site Support**: Rule34.xxx, Rule34.paheal.net, Gelbooru, Safebooru, Danbooru, e621, e926, nhentai
- **Unified Search**: Search across multiple sites simultaneously
- **Modern UI**: Dark theme with responsive design, infinite scroll gallery
- **Batch Downloads**: Download multiple images as ZIP with progress tracking
- **Local Library**: Browse, search, and manage all downloaded images
- **SillyTavern Integration**: Generate LocalImage names and descriptions using your AI API
- **API-first Design**: Uses official JSON APIs where available

## Quick Start

### Local Development

```bash
# Clone repository
git clone https://github.com/yourusername/hentaivault.git
cd hentaivault

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Run development server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8080
```

### Docker Deployment (Recommended for VPS)

```bash
# Build and run
docker-compose up -d --build

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

### VPS Deployment (Oracle Cloud Always Free / Hetzner / Contabo)

```bash
# SSH into your VPS
ssh user@your-vps-ip

# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Clone and start
git clone https://github.com/yourusername/hentaivault.git
cd hentaivault
docker-compose up -d --build

# The app will be available at http://your-vps-ip:8080
```

## Configuration

Edit `config.json` for persistent settings or use the web UI Settings page.

### AI API Configuration (SillyTavern LocalImage)

1. Open Settings → AI API Settings
2. Enter your API provider details:
   - **Base URL**: e.g., `https://api.nanogpt.io/v1` (or any OpenAI-compatible endpoint)
   - **API Key**: Your API key
   - **Model**: e.g., `gpt-4o`, `claude-3-opus`, etc.
3. Test connection before saving

When viewing images, click "Generate SillyTavern Name" to automatically create:
- A short kebab-case name (e.g., `bedroom_night`, `red_dress_outfit`)
- A brief description for SillyTavern's LocalImage extension

## Adding New Sites

Add a new Booru site in under 50 lines:

```python
# app/scrapers/newsite.py
from .base import BaseScraper

class NewSiteScraper(BaseScraper):
    name = "newsite"
    base_url = "https://newsite.com"
    
    async def search(self, query: str, page: int = 1, **filters):
        # Implement search logic
        results = await self._fetch_search_results(query, page)
        return self._parse_results(results)
    
    async def get_image_details(self, image_id: str):
        # Get full image info
        pass
```

Register in `app/scrapers/__init__.py`:
```python
from .newsite import NewSiteScraper
SCRAPERS["newsite"] = NewSiteScraper
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/search` | GET | Search images across sites |
| `/api/library` | GET | Get local library images |
| `/api/download` | POST | Queue image(s) for download |
| `/api/ai/generate` | POST | Generate SillyTavern metadata |

## Directory Structure

```
hentaivault/
├── app/
│   ├── main.py           # FastAPI app entry
│   ├── routers/          # API routes
│   ├── scrapers/         # Site-specific scrapers
│   ├── services/         # Business logic
│   ├── templates/        # Jinja2 templates
│   └── static/           # CSS/JS files
├── downloads/            # Downloaded images
└── data/                 # SQLite database
```

## Tech Stack

- **Backend**: FastAPI (Python 3.11+) with async support
- **Frontend**: HTML + Tailwind CSS + Alpine.js
- **Database**: SQLite with SQLAlchemy
- **HTTP Client**: httpx (async)
- **Scraping**: BeautifulSoup4 (fallback only)

## License

Personal use only. Not for redistribution.

## Disclaimer

This application is for personal offline archiving only. Users are responsible for complying with the terms of service of each site they access. The developers are not responsible for how this software is used.