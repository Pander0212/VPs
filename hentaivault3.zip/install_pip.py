#!/usr/bin/env python3
import urllib.request
import subprocess
import sys

url = "https://bootstrap.pypa.io/get-pip.py"
print(f"Downloading pip from {url}...")
with urllib.request.urlopen(url) as response:
    data = response.read()

print("Running get-pip.py...")
exec(data)
