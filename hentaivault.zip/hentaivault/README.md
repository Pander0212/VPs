# HentaiVault 🎨

A self-hosted, production-ready web application for searching, browsing, and downloading images from multiple booru image boards. Designed for personal offline archiving and SillyTavern integration.

## Features

- **12 Sites Supported**: Rule34.xxx, Rule34.paheal.net, Gelbooru, Safebooru, Danbooru, e621, e926, nHentai, Yande.re, Konachan, Zerochan, Sankaku Complex
- **High-Quality Downloads**: Always fetches the highest available resolution (full original > sample > preview)
- **Per-Site Auth**: Configure API keys for Gelbooru, Danbooru, and Sankaku login credentials
- **Tag Autocomplete**: Real-time tag suggestions from all 12 sites with smart deduplication
- **AI Name Generation**: One-click "Generate AI Name" button that calls your configured OpenAI-compatible API (NanoGPT, OpenAI, OpenRouter, LocalAI, etc.) to generate clean filenames and auto-rename
- **Local Library**: Full folder scanning, metadata JSON sidecars, search/filter/sort, folder tree view
- **SillyTavern Integration**: Copy SillyTavern embed codes, export character folders as ZIP with manifest
- **Dark Modern UI**: Tailwind CSS + Alpine.js, responsive design, toast notifications
- **Batch Operations**: Select multiple images, download them all, or generate AI names in batch

## Quick Start

### Local Development

```bash
cd hentaivault

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run development server
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8081
```

### Docker Deployment

```bash
docker-compose up -d --build
```

## Configuration

### AI API Settings (Settings → AI)

1. Enter your OpenAI-compatible **Base URL** (e.g. `https://api.nanogpt.com/v1`)
2. Enter your **API Key**
3. Set your **Model** (e.g. `gpt-4o`, `gpt-3.5-turbo`, `claude-3-opus`)
4. Click **Test Connection** to verify, then **Save Settings**
5. Use the **🤖 AI Name** button on any image to auto-generate and rename

### Per-Site Authentication (Settings → Site Auth)

- **Gelbooru**: Enter API Key + User ID for full API access (free account at gelbooru.com)
- **Danbooru**: Enter API Key + Username (requires Gold+ account, get API key from Account settings)
- **Sankaku Complex**: Enter Username/Email + Password for authenticated API access

## Troubleshooting

### Images not appearing in Library
- Ensure images are in the `/downloads` directory with their `.json` metadata sidecar files
- Click the **🔄 Refresh** button to re-scan
- Check that folders don't have special characters in names

### Search returns no results
- **Danbooru**: Requires authentication (Settings → Site Auth). Without auth, falls back to HTML scraping which may be rate-limited
- **Gelbooru**: Works without auth but rate-limited. Add API key for better results
- **Sankaku**: May need login credentials for full access
- Try searching across multiple sites simultaneously for better coverage

### Tag autocomplete not working
- Autocomplete queries the selected sites' tag APIs. Ensure at least one site is selected
- Some sites have rate limits on their tag endpoints - if a particular site doesn't return suggestions, try others
- Minimum 2 characters required to trigger autocomplete

### AI Name Generation fails
- Verify your Base URL ends with the API path (e.g. `/v1`). The app appends `/chat/completions`
- Check that your API key is valid and has not expired
- Use the **Test Connection** button in Settings to verify
- Common errors:
  - **401 Unauthorized**: Invalid API key
  - **404 Not Found**: Incorrect Base URL
  - **502 Connection Error**: Cannot reach the API server
  - **504 Timeout**: API took too long to respond (30s timeout)

### Low-quality downloads
- The app always tries the `file_url` (full original) first, then falls back to `sample_url` and `preview_url`
- Rule34.xxx: Full-resolution images are derived from the `/images/` path, not `/thumbnails/`
- If you get small images, the source site may have restricted the full version (common on Danbooru without auth)

### Port already in use
- Default port is 8081. If busy, use `--port 8082` or change in `config.json`
- Port 8080 is used by File Browser if installed alongside

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/search` | GET | Search images across sites (`q` param) |
| `/api/sites` | GET | List available sites with auth info |
| `/api/tags/suggest` | GET | Tag autocomplete (`partial` + `site` params) |
| `/api/popular` | GET | Popular images from a site |
| `/api/random` | GET | Random images from a site |
| `/api/download` | POST | Download image batch |
| `/api/downloads/ai/generate-name` | POST | Generate AI filename |
| `/api/library/images` | GET | List local library images |
| `/api/library/folders` | GET | Folder tree structure |
| `/api/library/image/{path}` | DELETE | Delete an image |
| `/api/ai/settings` | GET/POST | AI API configuration |
| `/api/ai/test` | POST | Test AI connection |
| `/api/sources/config` | GET/POST | Per-site auth configuration |

## Directory Structure

```
hentaivault/
├── app/
│   ├── main.py              # FastAPI app entry
│   ├── config.py            # Settings and paths
│   ├── database.py          # SQLite + SQLAlchemy async
│   ├── models.py            # ORM models
│   ├── schemas.py           # Pydantic schemas
│   ├── routers/             # API route handlers
│   │   ├── api.py           # Search, sites, tags
│   │   ├── downloads.py     # Download + AI naming
│   │   ├── library.py       # Local library
│   │   ├── ai.py            # AI settings + generation
│   │   ├── folders.py       # Character folders
│   │   └── web.py           # HTML page routes
│   ├── scrapers/            # Per-site scrapers (12 sites)
│   │   ├── base.py          # Base scraper with retry logic
│   │   ├── rule34.py        # Rule34.xxx (API + HTML)
│   │   ├── rule34paheal.py  # Rule34.paheal.net (Shimmie)
│   │   ├── gelbooru.py      # Gelbooru (JSON API + auth)
│   │   ├── safebooru.py     # Safebooru (XML API)
│   │   ├── danbooru.py      # Danbooru (JSON API + auth)
│   │   ├── e621.py          # e621 (JSON API)
│   │   ├── e926.py          # e926 (JSON API)
│   │   ├── nhentai.py       # nHentai (API + HTML)
│   │   ├── yandere.py       # Yande.re (Moebooru JSON)
│   │   ├── konachan.py      # Konachan (Moebooru JSON)
│   │   ├── zerochan.py      # Zerochan (JSON API)
│   │   └── sankaku.py       # Sankaku (v2 API + auth)
│   ├── services/
│   │   └── ai_service.py    # AI metadata generation
│   ├── templates/           # Jinja2 + Alpine.js pages
│   │   ├── base.html        # Layout, nav, toast system
│   │   ├── index.html       # Search page
│   │   ├── library.html     # Local library
│   │   ├── settings.html    # AI + site auth config
│   │   ├── folders.html     # Character folder management
│   │   └── components/      # Shared modals
│   └── static/
│       └── js/              # Alpine.js components
├── downloads/               # Downloaded images + metadata
├── data/                    # SQLite database + source configs
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

## Tech Stack

- **Backend**: FastAPI (Python 3.11+), async httpx, BeautifulSoup4
- **Frontend**: HTML + Tailwind CSS CDN + Alpine.js 3.x CDN
- **Database**: SQLite with SQLAlchemy (async)
- **Deployment**: Docker + docker-compose

## License

Personal use only. Not for redistribution.

## Disclaimer

This application is for personal offline archiving only. Users are responsible for complying with the terms of service of each site they access.
