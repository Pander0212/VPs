/**
 * Shrimp Stew Skill
 * 智能生图生视频提示词生成
 * 
 * 连接 ShrimpStew LLM (默认 kimi-k2.5)，自动分析用户需求并生成图像/视频提示词
 */
// Read from environment variables
const OPENAI_BASE_URL = process.env.OPENAI_BASE_URL || "https://cephalon.cloud";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

const OpenAI = require('openai');
const fs = require('fs');
const path = require('path');

// ShrimpStew 配置
const SHRIMPSTEW_CONFIG = {
  baseUrl: "${OPENAI_BASE_URL}/user-center/v1/model",
  apiKey: "${OPENAI_API_KEY}"
};

// 模型优先级列表 (默认优先使用 kimi-k2.5)
const MODEL_PRIORITY = [
  "kimi-k2.5",
  "MiniMax-M2.5",
  "glm-5",
  "qwen3.5-397b-a17b",
  "gpt-5.4",
  "gemini-3.1-pro-preview",
  "claude-opus-4-6"
];

// 触发关键词
const TRIGGER_KEYWORD = "龙虾煲";

// ============ 异步生图功能（ComfyUI / Nano Banana 2） ============

const COMFYUI_CONFIG = {
  baseUrl: "${OPENAI_BASE_URL}/user-center/v1/model/comfyui",
  apiKey: "${OPENAI_API_KEY}",
  modelId: "1820402673401271273",
  outputDir: "/root/.openclaw/workspace/images",
  pollInterval: 3000,
  maxPollCount: 60
};

/**
 * 解析用户输入，提取实际需求
 * 格式: "龙虾煲 [需求描述]" 或直接是需求描述
 */
function parseInput(input) {
  if (!input) return null;
  
  const trimmed = input.trim();
  
  // 检查是否包含触发关键词
  if (trimmed.startsWith(TRIGGER_KEYWORD)) {
    // 移除触发词，获取实际需求
    const request = trimmed.substring(TRIGGER_KEYWORD.length).trim();
    return request || null;
  }
  
  // 如果没有触发词但有内容，也返回
  return trimmed || null;
}

/**
 * 创建 SHRIMPSTEW OpenAI 客户端
 */
function createShrimpStewClient(modelId) {
  return new OpenAI({
    baseURL: SHRIMPSTEW_CONFIG.baseUrl,
    apiKey: SHRIMPSTEW_CONFIG.apiKey,
    dangerouslyAllowBrowser: false,
    defaultQuery: { "model": modelId }
  });
}

/**
 * 尝试连接模型，自动降级
 */
async function connectWithFallback(userRequest) {
  let lastError = null;
  
  for (const modelId of MODEL_PRIORITY) {
    try {
      console.log(`[Shrimp Stew] 尝试连接模型: ${modelId}`);
      
      const client = createShrimpStewClient(modelId);
      
      const response = await client.chat.completions.create({
        model: modelId,
        messages: [
          {
            role: "system",
            content: `你是一个专业的AI提示词生成专家。当用户提出需求时，你需要：
1. 分析用户需求的核心要点
2. 拆解需求（主题、类型、风格、情感、构图等）
3. 生成适合生图/生视频的高质量提示词

请严格按照以下格式输出：
## 需求分析
- 主题: xxx
- 类型: [图像/视频]
- 风格: xxx
- 其他要点: xxx

## 生成的提示词
[详细的中英文提示词，包含所有必要的视觉元素和描述]`
          },
          {
            role: "user",
            content: userRequest
          }
        ],
        temperature: 0.8,
        max_tokens: 2000
      }, {
        timeout: 30000 // 30秒超时
      });
      
      return {
        success: true,
        model: modelId,
        content: response.choices[0]?.message?.content || "生成失败"
      };
      
    } catch (error) {
      console.log(`[Shrimp Stew] 模型 ${modelId} 连接失败: ${error.message}`);
      lastError = error;
      continue; // 尝试下一个模型
    }
  }
  
  return {
    success: false,
    error: `所有模型都不可用: ${lastError?.message}`,
    triedModels: MODEL_PRIORITY
  };
}

/**
 * 主处理函数
 */
async function handleRequest(userRequest) {
  // 解析输入，提取实际需求
  const request = parseInput(userRequest);
  
  if (!request) {
    return {
      success: false,
      error: `请提供需求描述。例如: "${TRIGGER_KEYWORD} 帮我生成一个赛博朋克城市的图像提示词"`,
      triggerWord: TRIGGER_KEYWORD
    };
  }
  
  console.log(`[Shrimp Stew] 收到请求: ${request}`);
  
  // 调用 LLM 生成提示词
  const result = await connectWithFallback(request);
  
  if (result.success) {
    console.log(`[Shrimp Stew] 成功使用模型: ${result.model}`);
    return {
      success: true,
      model: result.model,
      content: result.content
    };
  } else {
    console.log(`[Shrimp Stew] 所有模型连接失败`);
    return result;
  }
}

// ============ 异步生图功能 ============

/**
 * 提交生图任务（异步模式）
 * @param {string} prompt - 生图提示词
 * @param {string} aspectRatio - 宽高比
 * @param {string[]} imageUrls - 参考图片URL数组
 * @returns {Promise<{taskId: string}>}
 */
async function submitImageTask(prompt, aspectRatio = "16:9", imageUrls = []) {
  const widthHeight = getWidthHeight(aspectRatio);

  const response = await fetch(COMFYUI_CONFIG.baseUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${COMFYUI_CONFIG.apiKey}`,
      'Model-Id': COMFYUI_CONFIG.modelId,
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'User-Agent': 'Apifox/1.0.0'
    },
    body: JSON.stringify({
      prompt: prompt,
      aspect_ratio: aspectRatio,
      image_urls: imageUrls,
      width: widthHeight.width,
      height: widthHeight.height,
      sync: false
    })
  });

  const data = await response.json();
  return { taskId: data.task_id || data.id };
}

/**
 * 查询生图任务状态
 * @param {string} taskId - 任务ID
 * @returns {Promise<{status: string, imageUrl?: string, data: object}>}
 */
async function queryImageTask(taskId) {
  const response = await fetch(`${COMFYUI_CONFIG.baseUrl}/tasks/${taskId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${COMFYUI_CONFIG.apiKey}`,
      'Model-Id': COMFYUI_CONFIG.modelId,
      'Accept': '*/*',
      'User-Agent': 'Apifox/1.0.0'
    }
  });

  const data = await response.json();
  
  const status = data.status || data.task_status || 'pending';
  let imageUrl = null;
  
  if (status === 'completed' || status === 'success') {
    imageUrl = data.output?.image_url || 
               data.image_url || 
               data.result?.image_url ||
               data.output?.[0]?.image_url;
  }
  
  return { status, imageUrl, data };
}

/**
 * 轮询等待生图任务完成
 * @param {string} taskId - 任务ID
 * @returns {Promise<{imageUrl: string}>}
 */
async function waitForImage(taskId) {
  console.log(`[ComfyUI] 开始轮询任务: ${taskId}`);
  
  for (let i = 0; i < COMFYUI_CONFIG.maxPollCount; i++) {
    const result = await queryImageTask(taskId);
    
    console.log(`[ComfyUI] 轮询 ${i + 1}/${COMFYUI_CONFIG.maxPollCount}, 状态: ${result.status}`);
    
    if (result.status === 'completed' || result.status === 'success') {
      if (result.imageUrl) {
        console.log(`[ComfyUI] 图片生成完成: ${result.imageUrl}`);
        return { imageUrl: result.imageUrl };
      }
      if (result.data?.output) {
        const url = result.data.output.image_url || 
                    result.data.output[0]?.image_url ||
                    result.data.output[0]?.url;
        if (url) {
          return { imageUrl: url };
        }
      }
    } else if (result.status === 'failed' || result.status === 'error') {
      throw new Error(`生图任务失败: ${result.data?.message || result.status}`);
    }
    
    await new Promise(r => setTimeout(r, COMFYUI_CONFIG.pollInterval));
  }
  
  throw new Error('生图任务超时');
}

/**
 * 异步模式生图（提交任务 → 轮询 → 下载）
 * @param {string} prompt - 生图提示词
 * @param {string} aspectRatio - 宽高比
 * @param {string[]} imageUrls - 参考图片URL数组
 * @returns {Promise<{localPath: string, imageUrl: string, taskId: string}>}
 */
async function generateImageAsync(prompt, aspectRatio = "16:9", imageUrls = []) {
  // Step 1: 提交任务
  console.log(`[ComfyUI] 提交生图任务...`);
  const { taskId } = await submitImageTask(prompt, aspectRatio, imageUrls);
  console.log(`[ComfyUI] 任务ID: ${taskId}`);
  
  // Step 2: 轮询等待完成
  const { imageUrl } = await waitForImage(taskId);
  
  // Step 3: 下载到本地
  const timestamp = Date.now();
  const outputPath = `${COMFYUI_CONFIG.outputDir}/img_${timestamp}.jpg`;
  
  await downloadToLocal(imageUrl, outputPath);
  
  return {
    taskId,
    imageUrl,
    localPath: outputPath
  };
}

/**
 * 获取宽高比对应的尺寸
 */
function getWidthHeight(aspectRatio) {
  const ratios = {
    "16:9": { width: 1280, height: 720 },
    "9:16": { width: 720, height: 1280 },
    "1:1": { width: 1024, height: 1024 },
    "4:3": { width: 1024, height: 768 },
    "3:2": { width: 1024, height: 683 },
    "2:3": { width: 683, height: 1024 },
    "21:9": { width: 1920, height: 820 }
  };
  return ratios[aspectRatio] || { width: 1280, height: 720 };
}

/**
 * 下载文件到本地
 */
async function downloadToLocal(url, outputPath) {
  const dir = path.dirname(outputPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  const response = await fetch(url);
  const buffer = await response.arrayBuffer();
  fs.writeFileSync(outputPath, Buffer.from(buffer));
  
  console.log(`[ComfyUI] 已保存到: ${outputPath}`);
  return outputPath;
}

// 导出模块
module.exports = {
  name: "shrimp-stew",
  triggerWord: TRIGGER_KEYWORD,
  description: "智能生图生视频提示词生成技能",
  handleRequest,
  parseInput,
  connectWithFallback,
  SHRIMPSTEW_CONFIG,
  MODEL_PRIORITY,
  generateImageAsync,
  submitImageTask,
  queryImageTask,
  waitForImage,
  COMFYUI_CONFIG
};

// 如果直接运行
if (require.main === module) {
  const request = process.argv[2] || "帮我生成一个赛博朋克城市的图像提示词";
  handleRequest(request).then(result => {
    console.log("\n=== 结果 ===");
    console.log(JSON.stringify(result, null, 2));
  }).catch(err => {
    console.error("错误:", err);
  });
}