const fs = require('fs');

// Read from environment variables
const OPENAI_BASE_URL = process.env.OPENAI_BASE_URL || "https://cephalon.cloud";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

// Search Config
const searchConfig = {
  baseUrl: `${OPENAI_BASE_URL}/cephalon/user-center/v1/model`,
  endpoint: "/search",
  apiKey: OPENAI_API_KEY
};

// Search function
async function searchWeb(query, options = {}) {
  const { endpoint = "web", count = 10 } = options;
  
  const encodedQuery = encodeURIComponent(query);
  const url = `${searchConfig.baseUrl}${searchConfig.endpoint}?q=${encodedQuery}&endpoint=${endpoint}&count=${count}`;
  
  console.log(`🔍 搜索 URL: ${url}`);
  
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${searchConfig.apiKey}`,
      'Accept': 'application/json'
    }
  });
  
  const data = await response.json();
  
  // Handle different response formats
  if (data.code === 20000 && data.data) {
    return {
      success: true,
      results: data.data.results || [],
      total: data.data.total || 0
    };
  }
  
  // Handle Brave Search API format
  if (data.web && data.web.results) {
    return {
      success: true,
      results: data.web.results,
      total: data.web.results.length
    };
  }
  
  return {
    success: false,
    error: data.msg || "搜索失败"
  };
}

// Main function
async function main() {
  try {
    console.log("🦐 龙虾煲 - 开始搜索");
    
    const query = "今天有什么大新闻";
    console.log(`📝 搜索关键词：${query}`);
    
    const result = await searchWeb(query, { count: 10 });
    
    if (result.success) {
      console.log(`\n✅ 找到 ${result.total} 条结果\n`);
      console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
      
      result.results.forEach((item, i) => {
        const title = item.title || '无标题';
        const url = item.url || '';
        const desc = item.description || item.snippet || '';
        const age = item.age || '';
        
        console.log(`📰 ${i + 1}. ${title}`);
        if (age) console.log(`   ⏰ ${age}`);
        if (url) console.log(`   🔗 ${url}`);
        if (desc) console.log(`   📄 ${desc.substring(0, 200)}...`);
        console.log();
      });
      
      console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    } else {
      console.log(`❌ 搜索失败：${result.error}`);
    }
    
  } catch (error) {
    console.error("❌ 搜索异常:", error);
  }
}

main();
