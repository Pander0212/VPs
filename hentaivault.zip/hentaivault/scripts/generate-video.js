const fs = require('fs');
const path = require('path');

// Read from environment variables
const OPENAI_BASE_URL = process.env.OPENAI_BASE_URL || "https://cephalon.cloud";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

// ShrimpStew LLM Config
const shrimpStewConfig = {
  baseUrl: `${OPENAI_BASE_URL}/user-center/v1/model`,
  chatEndpoint: "/chat/completions",
  apiKey: OPENAI_API_KEY
};

// Video Config (豆包 Seedance)
const videoConfig = {
  baseUrl: `${OPENAI_BASE_URL}/user-center/v1/model/video/tasks`,
  apiKey: OPENAI_API_KEY,
  modelName: "doubao-seedance-1-5-pro-responses",
  outputDir: "/root/.openclaw/workspace/videos"
};

// Token Usage Config
const tokenUsageConfig = {
  baseUrl: `${OPENAI_BASE_URL}/user-center/v1`,
  apiKey: OPENAI_API_KEY
};

// Call ShrimpStew LLM
async function callShrimpStewLLM(userMessage, systemPrompt) {
  const response = await fetch(`${shrimpStewConfig.baseUrl}${shrimpStewConfig.chatEndpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${shrimpStewConfig.apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: "kimi-k2.5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      max_tokens: 1000,
      temperature: 0.8
    })
  });
  
  const data = await response.json();
  return data.choices[0].message.content;
}

// Generate video prompts
async function generatePrompts() {
  const systemPrompt = `你是一个 AI 视频提示词专家。根据用户需求，生成 3 个高质量的英文视频提示词。
要求：
1. 每个提示词 30-80 词
2. 描述动态场景、动作、运镜
3. 包含时长和节奏提示
4. 用英文逗号分隔关键元素

直接输出 3 个提示词，用换行分隔，不要编号，不要解释。`;

  const response = await callShrimpStewLLM("生成一个创意视频提示词", systemPrompt);
  const prompts = response.split('\n').filter(p => p.trim().length > 20);
  return prompts.slice(0, 3);
}

// Submit video generation task
async function submitVideoTask(prompt, options = {}) {
  const {
    resolution = "1080p",
    ratio = "16:9",
    duration = 5,
    generateAudio = true,
    watermark = false
  } = options;

  const response = await fetch(videoConfig.baseUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${videoConfig.apiKey}`,
      'Model-Name': videoConfig.modelName,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: videoConfig.modelName,
      content: [{ type: "text", text: prompt }],
      resolution,
      ratio,
      duration,
      generate_audio: generateAudio,
      watermark
    })
  });

  const data = await response.json();
  console.log("📋 提交任务响应:", JSON.stringify(data, null, 2));
  return data.task_id || data.id;
}

// Parse SSE stream and extract video URL
async function queryVideoTaskSSE(taskId) {
  const response = await fetch(videoConfig.baseUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${videoConfig.apiKey}`,
      'Model-Name': videoConfig.modelName,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: "seedance-get",
      input: taskId,
      stream: true
    })
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let fullText = '';

  console.log("📡 开始接收 SSE 流...");

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        const data = line.slice(6);
        if (data.trim() === '[DONE]') {
          console.log("✅ SSE 流结束");
          break;
        }

        try {
          const parsed = JSON.parse(data);
          
          // Accumulate all text deltas
          if (parsed.type === 'response.output_text.delta' && parsed.delta) {
            fullText += parsed.delta;
          }
          
          // Also check response.completed
          if (parsed.type === 'response.completed' && parsed.response) {
            const output = parsed.response.output;
            if (output && output[0] && output[0].content) {
              const text = output[0].content[0]?.text || '';
              fullText += text;
            }
          }
        } catch (e) {
          // Skip invalid JSON
        }
      }
    }
  }

  console.log("📝 完整响应文本:");
  console.log(fullText);
  console.log("---");

  // Extract video URL - match full URL with all query parameters
  const urlMatch = fullText.match(/https:\/\/[^\s"']+\.mp4\?[^\s"']+/);
  if (urlMatch) {
    return { videoUrl: urlMatch[0], fullText };
  }

  // Fallback: try without query params
  const simpleMatch = fullText.match(/https:\/\/[^\s"']+\.mp4/);
  if (simpleMatch) {
    return { videoUrl: simpleMatch[0], fullText };
  }

  throw new Error("未找到视频 URL");
}

// Download video to local
async function downloadVideo(videoUrl, outputPath) {
  console.log(`⬇️ 下载视频：${videoUrl}`);
  const response = await fetch(videoUrl);
  const buffer = await response.arrayBuffer();
  
  const dir = path.dirname(outputPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  
  fs.writeFileSync(outputPath, Buffer.from(buffer));
  
  return outputPath;
}

// Query token usage
async function queryTokenUsage() {
  const url = `${tokenUsageConfig.baseUrl}/api_token/usage?page_index=1&page_size=20`;
  
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${tokenUsageConfig.apiKey}`,
      'User-Agent': 'Apifox/1.0.0',
      'Accept': '*/*'
    }
  });
  
  const data = await response.json();
  
  if (data.code === 20000 && data.data && data.data.summary) {
    const summary = data.data.summary;
    return {
      tokenName: summary.token_name,
      totalInput: parseInt(summary.total_input_token_cost).toLocaleString(),
      totalOutput: parseInt(summary.total_output_token_cost).toLocaleString(),
      totalCost: parseInt(summary.total_token_cost).toLocaleString(),
      invokeCount: summary.total_invoke_count
    };
  }
  
  return null;
}

// Main function
async function main() {
  try {
    console.log("🦐 龙虾煲 - 开始生视频流程 (SSE 版本)");
    
    // Step 1: Generate prompts
    console.log("🔄 正在生成提示词...");
    const prompts = await generatePrompts();
    console.log(`✅ 生成 ${prompts.length} 个提示词`);
    console.log("📝 提示词:");
    prompts.forEach((p, i) => console.log(`   ${i + 1}. ${p.substring(0, 80)}...`));
    
    const selectedPrompt = prompts[0];
    
    // Step 2: Submit video task
    console.log("\n🎬 正在提交视频生成任务...");
    const taskId = await submitVideoTask(selectedPrompt, {
      resolution: "1080p",
      ratio: "16:9",
      duration: 5,
      generateAudio: true,
      watermark: false
    });
    console.log(`📋 任务 ID: ${taskId}`);
    
    // Step 3: Query with SSE
    console.log("\n📡 正在查询视频状态 (SSE)...");
    const result = await queryVideoTaskSSE(taskId);
    
    if (!result.videoUrl) {
      throw new Error("未找到视频 URL");
    }
    
    console.log("🎬 完整视频 URL:", result.videoUrl);
    
    // Step 4: Download video IMMEDIATELY (URL expires quickly)
    const timestamp = Date.now();
    const outputDir = videoConfig.outputDir;
    const outputPath = `${outputDir}/video_${timestamp}.mp4`;
    
    console.log(`\n⬇️ 立即下载视频...`);
    await downloadVideo(result.videoUrl, outputPath);
    
    // Verify file size
    const stats = fs.statSync(outputPath);
    console.log(`📦 文件大小：${(stats.size / 1024 / 1024).toFixed(2)} MB`);
    
    if (stats.size < 1000) {
      console.error("⚠️ 警告：文件太小，可能下载失败");
    } else {
      console.log(`✅ 视频已保存到：${outputPath}`);
    }
    
    // Step 5: Query token usage
    console.log("\n📊 正在查询 Token 用量...");
    const usage = await queryTokenUsage();
    
    if (usage) {
      console.log("📊 Token 用量，仅供参考:");
      console.log(`   - Token 名称：${usage.tokenName}`);
      console.log(`   - 输入 Token: ${usage.totalInput}`);
      console.log(`   - 输出 Token: ${usage.totalOutput}`);
      console.log(`   - 总消耗：${usage.totalCost}`);
      console.log(`   - 调用次数：${usage.invokeCount}`);
    }
    
    console.log("\n✅ 生视频完成!");
    console.log(`📁 本地路径：${outputPath}`);
    console.log(`🔗 在线 URL: ${result.videoUrl}`);
    
  } catch (error) {
    console.error("❌ 生视频失败:", error);
  }
}

main();
