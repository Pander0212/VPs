const fs = require('fs');
const path = require('path');

// Read from environment variables
const OPENAI_BASE_URL = process.env.OPENAI_BASE_URL || "https://cephalon.cloud";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

// ShrimpStew LLM Config
const shrimpStewConfig = {
  baseUrl: `${OPENAI_BASE_URL}/user-center/v1/model`,
  chatEndpoint: "/chat/completions",
  apiKey: OPENAI_API_KEY
};

// Nano Banana Config
const nanoBananaConfig = {
  baseUrl: `${OPENAI_BASE_URL}/user-center/v1/model`,
  endpoint: "/comfyui",
  apiKey: OPENAI_API_KEY,
  modelId: "1820402673401271273"
};

// Token Usage Config
const tokenUsageConfig = {
  baseUrl: `${OPENAI_BASE_URL}/user-center/v1`,
  apiKey: OPENAI_API_KEY
};

// Call ShrimpStew LLM
async function callShrimpStewLLM(userMessage, systemPrompt) {
  const response = await fetch(`${shrimpStewConfig.baseUrl}${shrimpStewConfig.chatEndpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${shrimpStewConfig.apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: "kimi-k2.5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      max_tokens: 1000,
      temperature: 0.8
    })
  });
  
  const data = await response.json();
  return data.choices[0].message.content;
}

// Generate image prompts
async function generatePrompts(type = "image") {
  const systemPrompt = `你是一个 AI 图像提示词专家。根据用户需求，生成 3 个高质量的英文图像提示词。
要求：
1. 每个提示词 50-100 词
2. 风格明确（摄影/插画/3D/电影感等）
3. 包含光线、氛围、构图描述
4. 用英文逗号分隔关键元素

直接输出 3 个提示词，用换行分隔，不要编号，不要解释。`;

  const response = await callShrimpStewLLM("生成一个创意图片提示词", systemPrompt);
  const prompts = response.split('\n').filter(p => p.trim().length > 20);
  return prompts.slice(0, 3);
}

// Get width/height from aspect ratio
function getWidthHeight(aspectRatio) {
  const ratios = {
    "16:9": { width: 1280, height: 720 },
    "9:16": { width: 720, height: 1280 },
    "1:1": { width: 1024, height: 1024 },
    "4:3": { width: 1024, height: 768 },
    "3:2": { width: 1024, height: 683 },
    "2:3": { width: 683, height: 1024 },
    "21:9": { width: 1920, height: 820 }
  };
  return ratios[aspectRatio] || { width: 1280, height: 720 };
}

// Generate image via Nano Banana
async function generateImageNanoBanana(prompt, aspectRatio = "16:9") {
  const { width, height } = getWidthHeight(aspectRatio);
  
  const response = await fetch(`${nanoBananaConfig.baseUrl}${nanoBananaConfig.endpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${nanoBananaConfig.apiKey}`,
      'Model-Id': nanoBananaConfig.modelId,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      prompt: prompt,
      aspect_ratio: aspectRatio,
      image_urls: [],
      width: width,
      height: height
    })
  });
  
  // Check content type - might be JSON or direct image
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    return response.json();
  } else {
    // Direct image response - save it directly
    const buffer = await response.arrayBuffer();
    return { 
      isDirectImage: true, 
      buffer: Buffer.from(buffer),
      contentType: contentType 
    };
  }
}

// Download file to local
async function downloadToLocal(url, outputPath) {
  const dir = path.dirname(outputPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  
  const response = await fetch(url);
  const buffer = await response.arrayBuffer();
  fs.writeFileSync(outputPath, Buffer.from(buffer));
  
  return outputPath;
}

// Query token usage
async function queryTokenUsage() {
  const url = `${tokenUsageConfig.baseUrl}/api_token/usage?page_index=1&page_size=20`;
  
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${tokenUsageConfig.apiKey}`,
      'User-Agent': 'Apifox/1.0.0',
      'Accept': '*/*'
    }
  });
  
  const data = await response.json();
  
  if (data.code === 20000 && data.data && data.data.summary) {
    const summary = data.data.summary;
    return {
      tokenName: summary.token_name,
      totalInput: parseInt(summary.total_input_token_cost).toLocaleString(),
      totalOutput: parseInt(summary.total_output_token_cost).toLocaleString(),
      totalCost: parseInt(summary.total_token_cost).toLocaleString(),
      invokeCount: summary.total_invoke_count
    };
  }
  
  return null;
}

// Main function
async function main() {
  try {
    console.log("🦐 龙虾煲 - 开始生图流程");
    
    // Step 1: Generate prompts
    console.log("🔄 正在生成提示词...");
    const prompts = await generatePrompts();
    console.log(`✅ 生成 ${prompts.length} 个提示词`);
    console.log("📝 提示词:");
    prompts.forEach((p, i) => console.log(`   ${i + 1}. ${p.substring(0, 80)}...`));
    
    const selectedPrompt = prompts[0];
    
    // Step 2: Generate image
    console.log("🎨 正在调用 Nano Banana 生图...");
    const result = await generateImageNanoBanana(selectedPrompt, "16:9");
    
    // Step 3: Handle result
    const timestamp = Date.now();
    const outputDir = "/root/.openclaw/workspace/images";
    const outputPath = `${outputDir}/img_${timestamp}.jpg`;
    
    if (result.isDirectImage) {
      // Direct image response
      const dir = path.dirname(outputPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(outputPath, result.buffer);
      console.log(`✅ 图片已保存到：${outputPath}`);
    } else {
      // JSON response
      console.log("📋 生图结果:", JSON.stringify(result, null, 2));
      const imageUrl = result.image_url || result.url || result.output_url;
      if (imageUrl) {
        await downloadToLocal(imageUrl, outputPath);
        console.log(`✅ 图片已保存到：${outputPath}`);
      } else {
        console.log("❌ 未找到图片 URL");
      }
    }
    
    // Step 4: Query token usage
    console.log("📊 正在查询 Token 用量...");
    const usage = await queryTokenUsage();
    
    if (usage) {
      console.log("📊 Token 用量，仅供参考:");
      console.log(`   - Token 名称：${usage.tokenName}`);
      console.log(`   - 输入 Token: ${usage.totalInput}`);
      console.log(`   - 输出 Token: ${usage.totalOutput}`);
      console.log(`   - 总消耗：${usage.totalCost}`);
      console.log(`   - 调用次数：${usage.invokeCount}`);
    }
    
    console.log("\n✅ 生图完成!");
    console.log(`📁 本地路径：${outputPath}`);
    
  } catch (error) {
    console.error("❌ 生图失败:", error);
  }
}

main();
