"""
SQLAlchemy database models
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, JSON, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base


class Image(Base):
    """Downloaded image metadata"""
    __tablename__ = "images"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Source info
    source_site = Column(String(50), nullable=False, index=True)
    source_id = Column(String(100), nullable=False, index=True)
    source_url = Column(String(500), nullable=False)
    
    # Image info
    file_url = Column(String(1000), nullable=False)
    preview_url = Column(String(1000))
    sample_url = Column(String(1000))
    width = Column(Integer)
    height = Column(Integer)
    file_size = Column(Integer)  # bytes
    file_ext = Column(String(10))
    
    # Metadata
    tags = Column(JSON, default=list)
    artist = Column(String(100))
    character = Column(String(200))
    rating = Column(String(20))  # safe, questionable, explicit
    score = Column(Integer, default=0)
    
    # Local storage
    local_filename = Column(String(255), unique=True)
    local_path = Column(String(500))
    
    # SillyTavern integration
    st_name = Column(String(100))  # SillyTavern LocalImage name
    st_description = Column(Text)  # SillyTavern description
    
    # Relationships
    folders = relationship("CharacterFolder", secondary="folder_images", back_populates="images")
    
    # Timestamps
    downloaded_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    def to_dict(self):
        return {
            "id": self.id,
            "source_site": self.source_site,
            "source_id": self.source_id,
            "source_url": self.source_url,
            "file_url": self.file_url,
            "preview_url": self.preview_url,
            "width": self.width,
            "height": self.height,
            "file_ext": self.file_ext,
            "tags": self.tags or [],
            "artist": self.artist,
            "character": self.character,
            "rating": self.rating,
            "score": self.score,
            "local_filename": self.local_filename,
            "st_name": self.st_name,
            "st_description": self.st_description,
            "downloaded_at": self.downloaded_at.isoformat() if self.downloaded_at else None
        }


class DownloadJob(Base):
    """Background download job"""
    __tablename__ = "download_jobs"
    
    id = Column(Integer, primary_key=True)
    
    # Job info
    image_id = Column(Integer, ForeignKey("images.id"), nullable=True)
    batch_id = Column(String(50), index=True)  # for batch downloads
    
    # URLs to download
    urls = Column(JSON, nullable=False)  # list of image URLs
    
    # Status
    status = Column(String(20), default="pending", index=True)  # pending, downloading, complete, failed
    progress = Column(Integer, default=0)  # 0-100
    total = Column(Integer, default=1)
    error_message = Column(Text)
    
    # Result
    result_path = Column(String(500))  # path to ZIP or directory
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    
    def to_dict(self):
        return {
            "id": self.id,
            "batch_id": self.batch_id,
            "status": self.status,
            "progress": self.progress,
            "total": self.total,
            "error_message": self.error_message,
            "result_path": self.result_path,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None
        }


class CharacterFolder(Base):
    """Character folders for organizing images"""
    __tablename__ = "character_folders"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    images = relationship("Image", secondary="folder_images", back_populates="folders")
    
    def to_dict(self):
        # Note: image_count is now calculated in the router's list endpoint
        # to avoid lazy-loading issues with SQLAlchemy relationships
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "image_count": 0  # Will be set by the router
        }


class FolderImage(Base):
    """Association table for folder-image relationships"""
    __tablename__ = "folder_images"
    
    folder_id = Column(Integer, ForeignKey("character_folders.id"), primary_key=True)
    image_id = Column(Integer, ForeignKey("images.id"), primary_key=True)
    added_at = Column(DateTime, default=datetime.utcnow)
    custom_name = Column(String(100))  # Custom SillyTavern name for this folder


class Setting(Base):
    """Application settings stored in database"""
    __tablename__ = "settings"
    
    id = Column(Integer, primary_key=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(JSON)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)