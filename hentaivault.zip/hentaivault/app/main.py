"""
HentaiVault - Universal Booru Image Scraper & Downloader
Main FastAPI application entry point
"""
import os
import json
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from app.config import settings
from app.database import init_db, close_db
from app.routers import api, web, downloads, library, ai
from app.routers.folders import router as folders_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize database on startup"""
    await init_db()
    yield
    await close_db()


app = FastAPI(
    title="HentaiVault",
    description="Universal Booru Image Scraper & Downloader",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware for API access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files and templates
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATE_DIR = BASE_DIR / "templates"

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATE_DIR))

# Create downloads directory if not exists
DOWNLOADS_DIR = Path("/app/downloads")
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)

# Include routers
app.include_router(web, tags=["web"])
app.include_router(api, prefix="/api", tags=["api"])
app.include_router(downloads, prefix="/api/downloads", tags=["downloads"])
app.include_router(library, prefix="/api/library", tags=["library"])
app.include_router(ai, prefix="/api/ai", tags=["ai"])
app.include_router(folders_router, prefix="/api/folders", tags=["folders"])


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    """Custom 404 page"""
    return templates.TemplateResponse(
        "base.html",
        {"request": request, "error": "Page not found"},
        status_code=404
    )


@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    """Custom 500 page"""
    return templates.TemplateResponse(
        "base.html", 
        {"request": request, "error": "Internal server error"},
        status_code=500
    )