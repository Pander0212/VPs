"""
Base scraper class with common functionality
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import httpx
from datetime import datetime
import random
import asyncio

from app.config import settings


class BaseScraper(ABC):
    """Abstract base class for all booru scrapers"""
    
    name: str = "base"
    base_url: str = ""
    
    # Rotate user agents to avoid detection
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    ]
    
    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout,
            follow_redirects=True
        )
    
    async def close(self):
        """Close HTTP client"""
        await self.client.aclose()
    
    def get_headers(self) -> Dict[str, str]:
        """Generate request headers"""
        headers = {
            "User-Agent": random.choice(self.USER_AGENTS),
            "Accept": "application/json, text/html, */*",
            "Accept-Language": "en-US,en;q=0.9",
        }
        return headers
    
    async def _rate_limit(self):
        """Apply rate limiting"""
        await asyncio.sleep(settings.rate_limit_delay)
    
    async def fetch(self, url: str, params: Dict = None) -> httpx.Response:
        """Make HTTP GET request with rate limiting"""
        await self._rate_limit()
        
        headers = self.get_headers()
        
        # Use the persistent client for connection pooling
        response = await self.client.get(url, params=params, headers=headers)
        response.raise_for_status()
        return response
    
    async def fetch_json(self, url: str, params: Dict = None) -> Dict:
        """Fetch and parse JSON response"""
        response = await self.fetch(url, params)
        return response.json()
    
    async def fetch_html(self, url: str, params: Dict = None) -> str:
        """Fetch HTML content"""
        response = await self.fetch(url, params)
        return response.text
    
    @abstractmethod
    async def search(
        self, 
        query: str, 
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """
        Search for images by tags.
        
        Returns:
            {
                "images": List[ImageResult-like dict],
                "total": int,
                "page": int,
                "has_more": bool
            }
        """
        pass
    
    @abstractmethod
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """
        Get detailed information for a specific image.
        
        Returns:
            ImageResult-like dict with all available metadata
        """
        pass
    
    @abstractmethod
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """
        Get popular/trending images.
        
        Args:
            timeframe: day, week, month
        """
        pass
    
    @abstractmethod
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        pass
    
    @abstractmethod
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """
        Get tag suggestions for autocomplete.
        
        Returns:
            [{"tag": str, "count": int, "type": str}, ...]
        """
        pass
    
    def clean_filename(self, text: str) -> str:
        """Clean text for use in filename"""
        import re
        from slugify import slugify
        
        # Remove special characters
        cleaned = slugify(text, lowercase=True)
        # Limit length
        return cleaned[:100]