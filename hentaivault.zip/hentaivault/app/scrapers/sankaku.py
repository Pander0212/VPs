"""
SankakuComplex.com scraper - with login support and tag autocomplete
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class SankakuScraper(BaseScraper):
    """SankakuComplex scraper with login/token support"""

    name = "sankaku"
    base_url = "https://sankakuapi.com"
    web_url = "https://chan.sankakucomplex.com"

    # Auth tokens
    _access_token: Optional[str] = None
    _login: Optional[str] = None
    _password: Optional[str] = None

    def set_auth(self, login: str = "", password: str = "", access_token: str = ""):
        self._login = login
        self._password = password
        self._access_token = access_token

    def get_headers(self) -> Dict[str, str]:
        headers = super().get_headers()
        headers["Accept"] = "application/vnd.sankaku.api+json;v=2"
        if self._access_token:
            headers["Authorization"] = f"Bearer {self._access_token}"
        return headers

    async def _authenticate(self) -> bool:
        """Try to authenticate and get access token"""
        if self._access_token:
            return True
        if not self._login or not self._password:
            return False

        try:
            response = await self.fetch_json(
                f"{self.base_url}/auth/token",
                params=None,
            )
            # fetch_json uses GET, but auth needs POST - use client directly
            resp = await self.client.post(
                f"{self.base_url}/auth/token",
                json={"login": self._login, "password": self._password},
                headers=self.get_headers(),
            )
            if resp.status_code == 200:
                data = resp.json()
                self._access_token = data.get("access_token", "")
                return bool(self._access_token)
        except Exception as e:
            print(f"Sankaku auth error: {e}")
        return False

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Sankaku"""
        tags = []
        if query:
            tags.append(query)
        if rating:
            rating_map = {
                "safe": "rating:s",
                "questionable": "rating:q",
                "explicit": "rating:e",
            }
            tags.append(rating_map.get(rating, f"rating:{rating}"))
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        # Try auth if credentials available
        if self._login and self._password and not self._access_token:
            await self._authenticate()

        # Try API endpoints
        api_result = await self._search_api(tags, page)
        if api_result and api_result.get("images"):
            return api_result

        # Try keyset endpoint
        ks_result = await self._search_keyset(tags, page)
        if ks_result and ks_result.get("images"):
            return ks_result

        return {"images": [], "total": 0, "page": page, "has_more": False}

    async def _search_api(
        self, tags: List[str], page: int
    ) -> Optional[Dict[str, Any]]:
        """Search using Sankaku API"""
        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 40,
        }

        try:
            data = await self.fetch_json(f"{self.base_url}/posts", params)

            if isinstance(data, list):
                images = [self._parse_image(img) for img in data]
                has_more = len(images) == 40
                return {
                    "images": images,
                    "total": len(images),
                    "page": page,
                    "has_more": has_more,
                }
        except Exception as e:
            print(f"Sankaku API error: {e}")
        return None

    async def _search_keyset(
        self, tags: List[str], page: int
    ) -> Optional[Dict[str, Any]]:
        """Search using Sankaku keyset endpoint"""
        params = {
            "tags": " ".join(tags) if tags else "",
            "limit": 40,
        }

        try:
            data = await self.fetch_json(f"{self.base_url}/posts/keyset", params)

            if isinstance(data, list):
                images = [self._parse_image(img) for img in data]
                return {
                    "images": images,
                    "total": len(images),
                    "page": page,
                    "has_more": len(images) == 40,
                }
        except Exception as e:
            print(f"Sankaku keyset error: {e}")
        return None

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        # Tags handling
        raw_tags = data.get("tags", [])
        all_tags = []
        artist = None
        character = None
        tag_types = {}

        if isinstance(raw_tags, list):
            for t in raw_tags:
                if isinstance(t, dict):
                    name = t.get("name", "")
                    tag_type = t.get("type", 0)
                    all_tags.append(name)
                    if not name:
                        continue
                    # Map type
                    if tag_type == 1:
                        artist = name
                    elif tag_type == 4:
                        character = name
                    tag_types[name] = tag_type
                else:
                    all_tags.append(str(t))

        # URL resolution - prefer highest quality
        file_url = ""
        sample_url = ""
        preview_url = ""

        # Try various URL fields
        for key in [
            "file_url",
            "sample_url",
            "preview_url",
            "image_url",
            "thumbnail_url",
        ]:
            val = data.get(key, "")
            if not val:
                continue
            # Fix relative URLs
            if val.startswith("//"):
                val = "https:" + val
            elif val.startswith("/"):
                val = f"https://sankaku.app{val}"

            if key == "file_url" or key == "image_url":
                file_url = file_url or val
            elif key == "sample_url":
                sample_url = sample_url or val
            elif key in ("preview_url", "thumbnail_url"):
                preview_url = preview_url or val

        # Fallback chain
        best_url = file_url or sample_url or preview_url
        if not best_url:
            best_url = data.get("url", "")

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.web_url}/post/show/{data.get('id')}",
            "file_url": best_url,
            "preview_url": preview_url or best_url,
            "sample_url": sample_url or best_url,
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_type", "").split("/")[-1]
            if data.get("file_type")
            else (best_url.split(".")[-1].split("?")[0] if best_url else "jpg"),
            "tags": all_tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("total_score", 0) or data.get("fav_count", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        try:
            data = await self.fetch_json(f"{self.base_url}/posts/{image_id}")
            if data:
                return self._parse_image(data)
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        result = await self._search_api(["order:popular"], 1)
        return result or {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        result = await self._search_api(["order:random"], 1)
        return result or {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions from Sankaku"""
        try:
            params = {
                "name": partial,
                "limit": 15,
                "order": "count",
            }
            data = await self.fetch_json(f"{self.base_url}/tags", params)
            if isinstance(data, list):
                return [
                    {
                        "tag": t.get("name", ""),
                        "count": t.get("post_count", 0),
                        "type": self._map_tag_type(
                            t.get("type", 0)
                        ),
                    }
                    for t in data[:15]
                ]
        except Exception:
            pass

        # Try autocomplete endpoint
        try:
            data = await self.fetch_json(
                f"{self.base_url}/tags/autocomplete",
                {"term": partial, "limit": 15},
            )
            if isinstance(data, list):
                return [
                    {
                        "tag": (
                            item.get("name", "")
                            if isinstance(item, dict)
                            else str(item)
                        ),
                        "count": item.get("post_count", 0)
                        if isinstance(item, dict)
                        else 0,
                        "type": "general",
                    }
                    for item in data[:15]
                ]
        except Exception:
            pass
        return []

    @staticmethod
    def _map_tag_type(t: int) -> str:
        # Sankaku types: 0=general, 1=artist, 2=studio, 3=copyright, 4=character, 5=meta
        return {
            0: "general",
            1: "artist",
            2: "studio",
            3: "copyright",
            4: "character",
            5: "meta",
        }.get(t, "general")
