"""
SankakuComplex.com scraper - uses public API
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class SankakuScraper(BaseScraper):
    """SankakuComplex scraper"""
    
    name = "sankaku"
    base_url = "https://capi-v2.sankakucomplex.com"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Sankaku"""
        tags = []
        if query:
            tags.append(query)
        if rating:
            rating_map = {"safe": "rating:s", "questionable": "rating:q", "explicit": "rating:e"}
            tags.append(rating_map.get(rating, f"rating:{rating}"))
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 40
        }
        
        # Sankaku needs a specific user-agent / auth sometimes for v2 API
        headers = self.get_headers()
        headers["Accept"] = "application/vnd.sankaku.api+json;v=2"
        
        try:
            async with self.client as client:
                response = await client.get(
                    f"{self.base_url}/posts",
                    params=params,
                    headers=headers
                )
                response.raise_for_status()
                data = response.json()
            
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data]
                has_more = len(images) == 40
                return {
                    "images": images,
                    "total": len(images),
                    "page": page,
                    "has_more": has_more
                }
        except Exception:
            pass
        
        # Fallback: try the old API
        try:
            fallback_url = "https://capi-v2.sankakucomplex.com/posts/keyset"
            params["limit"] = 40
            response = await self.fetch(fallback_url, params)
            data = response.json()
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data]
                return {
                    "images": images,
                    "total": len(images),
                    "page": page,
                    "has_more": len(images) == 40
                }
        except Exception:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": "API unavailable"}
        
        return {"images": [], "total": 0, "page": page, "has_more": False}
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        tags_data = data.get("tags", [])
        if isinstance(tags_data, list):
            all_tags = []
            for t in tags_data:
                if isinstance(t, dict):
                    all_tags.append(t.get("name", ""))
                else:
                    all_tags.append(str(t))
        else:
            all_tags = []
        
        # Get artist and character from tags
        artist = None
        character = None
        if isinstance(tags_data, list):
            for t in tags_data:
                name = t.get("name", "") if isinstance(t, dict) else str(t)
                tag_type = t.get("type", "") if isinstance(t, dict) else ""
                if tag_type == "artist" or name.startswith("artist:"):
                    artist = name.replace("artist:", "")
                elif tag_type == "character" or name.startswith("character:"):
                    character = name.replace("character:", "")
        
        # URLs - Sankaku uses various formats
        file_url = data.get("file_url", "") or data.get("sample_url", "") or ""
        preview_url = data.get("preview_url", "") or file_url
        sample_url = data.get("sample_url", "") or file_url
        
        # Fix relative URLs
        for url_key in ["file_url", "preview_url", "sample_url"]:
            url = data.get(url_key, "")
            if url and not url.startswith("http"):
                if url_key == "file_url":
                    file_url = "https:" + url if url.startswith("//") else f"https://sankaku.app{url}" if url.startswith("/") else url
                elif url_key == "preview_url":
                    preview_url = "https:" + url if url.startswith("//") else f"https://sankaku.app{url}" if url.startswith("/") else url
                elif url_key == "sample_url":
                    sample_url = "https:" + url if url.startswith("//") else f"https://sankaku.app{url}" if url.startswith("/") else url
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"https://chan.sankakucomplex.com/post/show/{data.get('id')}",
            "file_url": file_url,
            "preview_url": preview_url,
            "sample_url": sample_url,
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_type", "").split("/")[-1] if data.get("file_type") else (file_url.split(".")[-1] if file_url else "jpg"),
            "tags": all_tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("total_score", 0) or data.get("fav_count", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        try:
            response = await self.fetch(f"{self.base_url}/posts/{image_id}")
            data = response.json()
            if data:
                return self._parse_image(data)
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        params = {"tags": "order:popular", "limit": 50}
        try:
            response = await self.fetch(f"{self.base_url}/posts", params)
            data = response.json()
            images = [self._parse_image(img) for img in data[:50]] if isinstance(data, list) else []
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        params = {"tags": "order:random", "limit": count}
        try:
            response = await self.fetch(f"{self.base_url}/posts", params)
            data = response.json()
            images = [self._parse_image(img) for img in data[:count]] if isinstance(data, list) else []
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        try:
            response = await self.fetch(
                f"{self.base_url}/tags",
                {"name": partial, "limit": 10, "order": "count"}
            )
            data = response.json()
            if isinstance(data, list):
                return [{
                    "tag": t.get("name", ""),
                    "count": t.get("post_count", 0),
                    "type": t.get("type", "general")
                } for t in data[:10]]
        except Exception:
            pass
        return []
