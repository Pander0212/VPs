"""
Konachan.com scraper - API-compatible with Moebooru (same as yande.re)
"""
from app.scrapers.yandere import YandereScraper


class KonachanScraper(YandereScraper):
    """Konachan.com scraper (reuses Moebooru API)"""
    
    name = "konachan"
    base_url = "https://konachan.com"
    api_url = f"{base_url}/post.json"
