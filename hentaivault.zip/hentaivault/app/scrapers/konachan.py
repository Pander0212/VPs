"""
Konachan.com scraper - Moebooru-based, high-quality wallpapers
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class KonachanScraper(BaseScraper):
    """Konachan.com API scraper (Moebooru-based, same as Yande.re)"""

    name = "konachan"
    base_url = "https://konachan.com"
    api_url = f"{base_url}/post.json"

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search konachan.com"""
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 100,
        }

        try:
            data = await self.fetch_json(self.api_url, params)
            if not isinstance(data, list):
                return {"images": [], "total": 0, "page": page, "has_more": False}

            images = [self._parse_image(img) for img in data]
            has_more = len(images) == 100
            return {"images": images, "total": len(images), "page": page, "has_more": has_more}
        except Exception as e:
            print(f"Konachan error: {e}")
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response with full quality URL priority"""
        tags = []
        if data.get("tags"):
            tags = data["tags"].split() if isinstance(data["tags"], str) else data["tags"]

        artist = data.get("author")
        if not artist:
            for t in tags:
                if t.startswith("artist:"):
                    artist = t.split(":", 1)[1]
                    break

        # URL hierarchy: file_url > jpeg_url > sample_url > preview_url
        file_url = data.get("file_url", "") or data.get("jpeg_url", "") or data.get("sample_url", "")
        if file_url and not file_url.startswith("http"):
            file_url = self.base_url + file_url

        preview_url = data.get("preview_url", "") or file_url
        if preview_url and not preview_url.startswith("http"):
            preview_url = self.base_url + preview_url

        sample_url = data.get("sample_url", "") or data.get("jpeg_url", "") or file_url
        if sample_url and not sample_url.startswith("http"):
            sample_url = self.base_url + sample_url

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/post/show/{data.get('id')}",
            "file_url": file_url,
            "preview_url": preview_url,
            "sample_url": sample_url,
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_ext", data.get("file_url", ".").split(".")[-1] if data.get("file_url") else "jpg"),
            "tags": tags,
            "artist": artist,
            "character": None,
            "rating": data.get("rating"),
            "score": data.get("score", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        url = f"{self.api_url}?tags=id:{image_id}"
        try:
            data = await self.fetch_json(url)
            if isinstance(data, list) and data:
                return self._parse_image(data[0])
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        params = {"tags": "order:score", "limit": 50}
        try:
            data = await self.fetch_json(self.api_url, params)
            images = [self._parse_image(img) for img in data[:50]] if isinstance(data, list) else []
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        params = {"tags": "order:random", "limit": count}
        try:
            data = await self.fetch_json(self.api_url, params)
            images = [self._parse_image(img) for img in data[:count]] if isinstance(data, list) else []
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions from konachan tag API"""
        url = f"{self.base_url}/tag.json"
        params = {"name": f"{partial}*", "order": "count", "limit": 15}
        try:
            data = await self.fetch_json(url, params)
            if isinstance(data, list):
                return [
                    {"tag": t.get("name", ""), "count": t.get("count", 0), "type": self._map_type(t.get("type", 0))}
                    for t in data[:15]
                ]
        except Exception:
            pass
        return []

    @staticmethod
    def _map_type(t: int) -> str:
        return {0: "general", 1: "artist", 3: "copyright", 4: "character"}.get(t, "general")
