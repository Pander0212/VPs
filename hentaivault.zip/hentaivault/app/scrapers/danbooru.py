"""
Danbooru.donmai.us scraper - uses official JSON API with auth support
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class DanbooruScraper(BaseScraper):
    """Danbooru.donmai.us API scraper with authentication support"""

    name = "danbooru"
    base_url = "https://danbooru.donmai.us"
    api_url = f"{base_url}/posts.json"

    # Per-site credentials
    _api_key: Optional[str] = None
    _username: Optional[str] = None

    def set_auth(self, api_key: str, username: str = ""):
        self._api_key = api_key
        self._username = username

    def get_headers(self) -> Dict[str, str]:
        headers = super().get_headers()
        # Danbooru auth can use basic auth or API key in headers
        if self._api_key and self._username:
            import base64
            auth_str = base64.b64encode(
                f"{self._username}:{self._api_key}".encode()
            ).decode()
            headers["Authorization"] = f"Basic {auth_str}"
        return headers

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Danbooru using JSON API"""

        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        params = {"tags": " ".join(tags) if tags else "", "page": page, "limit": 200}

        # Add auth params if available
        if self._api_key and self._username:
            params["login"] = self._username
            params["api_key"] = self._api_key

        try:
            data = await self.fetch_json(self.api_url, params)

            if not isinstance(data, list) or len(data) == 0:
                # Try HTML fallback
                return await self._search_html(query, page, rating, artist, character)

            images = [self._parse_image(img) for img in data]
            has_more = len(images) == 200

            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception as e:
            print(f"Danbooru API error: {e}")
            try:
                return await self._search_html(
                    query, page, rating, artist, character
                )
            except Exception as e2:
                return {
                    "images": [],
                    "total": 0,
                    "page": page,
                    "has_more": False,
                    "error": str(e2),
                }

    async def _search_html(
        self,
        query: str,
        page: int,
        rating: Optional[str],
        artist: Optional[str],
        character: Optional[str],
    ) -> Dict[str, Any]:
        """Fallback HTML scraping"""
        from bs4 import BeautifulSoup

        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        tags_str = "+".join(tags) if tags else ""
        url = f"{self.base_url}/posts?tags={tags_str}&page={page}"

        try:
            html = await self.fetch_html(url)
            soup = BeautifulSoup(html, "html.parser")

            images = []
            posts = soup.find_all("article", class_="post-preview")

            for post in posts:
                try:
                    post_id = post.get("data-id", "")
                    img = post.find("img")

                    if not img:
                        continue

                    preview_url = img.get("src", "")
                    if preview_url and preview_url.startswith("//"):
                        preview_url = "https:" + preview_url

                    # Get tags from data attributes
                    tags_data = post.get("data-tags", "")
                    tags_list = tags_data.split() if tags_data else []

                    # Get file URL from data attributes
                    file_url = (
                        post.get("data-file-url", "")
                        or post.get("data-large-file-url", "")
                        or preview_url
                    )
                    if file_url and file_url.startswith("//"):
                        file_url = "https:" + file_url
                    elif file_url and file_url.startswith("/"):
                        file_url = f"{self.base_url}{file_url}"

                    # Parse artist/character
                    artist_val = None
                    character_val = None
                    rating_val = None
                    for tag in tags_list:
                        if tag.startswith("artist:"):
                            artist_val = tag.split(":", 1)[1]
                        elif tag.startswith("character:"):
                            character_val = tag.split(":", 1)[1]
                        elif tag.startswith("rating:"):
                            rating_val = tag.split(":", 1)[1]

                    # Score
                    score_elem = post.find("span", class_="post-score")
                    score = 0
                    if score_elem:
                        try:
                            score = int(score_elem.get_text(strip=True))
                        except:
                            pass

                    # Dimensions from data
                    width = None
                    height = None
                    try:
                        width = int(post.get("data-width", 0)) or None
                        height = int(post.get("data-height", 0)) or None
                    except:
                        pass

                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": post_id,
                            "source_url": f"{self.base_url}/posts/{post_id}",
                            "file_url": file_url or preview_url,
                            "preview_url": preview_url,
                            "sample_url": file_url or preview_url,
                            "width": width,
                            "height": height,
                            "file_size": None,
                            "file_ext": (
                                preview_url.split(".")[-1].split("?")[0]
                                if preview_url
                                else "jpg"
                            ),
                            "tags": tags_list,
                            "artist": artist_val,
                            "character": character_val,
                            "rating": rating_val,
                            "score": score,
                        }
                    )
                except Exception as e:
                    print(f"Danbooru HTML parse error: {e}")
                    continue

            has_more = len(images) >= 20
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception as e:
            print(f"Danbooru HTML error: {e}")
            return {
                "images": [],
                "total": 0,
                "page": page,
                "has_more": False,
                "error": str(e),
            }

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response into standard format"""
        tags = []
        if data.get("tag_string"):
            tags = [t.strip() for t in data["tag_string"].split() if t.strip()]

        # Danbooru URL hierarchy: file_url (full) > large_file_url (sample) > preview_file_url
        file_url = data.get("file_url", "")
        large_url = data.get("large_file_url", "")
        preview_url = data.get("preview_file_url", "")

        # Fix relative URLs
        for url_key in ["file_url", "large_file_url", "preview_file_url"]:
            if data.get(url_key):
                val = data[url_key]
                if val.startswith("/"):
                    data[url_key] = f"{self.base_url}{val}"
                elif val.startswith("//"):
                    data[url_key] = f"https:{val}"

        file_url = data.get("file_url", "")
        large_url = data.get("large_file_url", "")
        preview_url = data.get("preview_file_url", "")

        # Best quality download URL
        best_url = file_url or large_url or preview_url

        # Extract artist/character
        artist = None
        character = None
        if data.get("tag_string_artist"):
            artist = data["tag_string_artist"].split()[0] if data["tag_string_artist"] else None
        if data.get("tag_string_character"):
            character = (
                data["tag_string_character"].split()[0]
                if data["tag_string_character"]
                else None
            )

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/posts/{data.get('id')}",
            "file_url": best_url,
            "preview_url": preview_url or best_url,
            "sample_url": large_url or best_url,
            "width": data.get("image_width"),
            "height": data.get("image_height"),
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_ext"),
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("score", 0) or data.get("fav_count", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        url = f"{self.base_url}/posts/{image_id}.json"
        try:
            data = await self.fetch_json(url)
            if data:
                return self._parse_image(data)
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        scale_map = {"day": "day", "week": "week", "month": "month"}
        scale = scale_map.get(timeframe, "week")
        url = f"{self.base_url}/explore/posts/popular.json"
        params = {"scale": scale, "limit": 50}
        try:
            data = await self.fetch_json(url, params)
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data[:50]]
                return {
                    "images": images,
                    "total": len(images),
                    "page": 1,
                    "has_more": False,
                }
        except Exception:
            pass
        # Fallback: score search
        params = {"tags": "order:score", "limit": 50}
        try:
            data = await self.fetch_json(self.api_url, params)
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data[:50]]
                return {
                    "images": images,
                    "total": len(images),
                    "page": 1,
                    "has_more": False,
                }
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        params = {"tags": "order:random", "limit": count}
        try:
            data = await self.fetch_json(self.api_url, params)
            if isinstance(data, list):
                images = [self._parse_image(img) for img in data[:count]]
                return {
                    "images": images,
                    "total": len(images),
                    "page": 1,
                    "has_more": False,
                }
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions from Danbooru autocomplete"""
        # Danbooru has a powerful autocomplete endpoint
        url = f"{self.base_url}/autocomplete.json"
        params = {
            "search[query]": partial,
            "search[type]": "tag_query",
            "version": "1",
            "limit": 15,
        }
        try:
            data = await self.fetch_json(url, params)
            suggestions = []
            if isinstance(data, list):
                for item in data[:15]:
                    if isinstance(item, dict):
                        tag_name = item.get("value", "") or item.get("label", "")
                        tag_type = item.get("type", "tag")
                        tag_count = item.get("post_count", 0)
                        # Category mapping
                        cat = item.get("category", 0)
                        type_map = {0: "general", 1: "artist", 3: "copyright", 4: "character"}
                        tag_type = type_map.get(cat, "general")
                        if tag_name:
                            suggestions.append(
                                {
                                    "tag": tag_name,
                                    "count": tag_count,
                                    "type": tag_type,
                                }
                            )
                    elif isinstance(item, str):
                        suggestions.append(
                            {"tag": item, "count": 0, "type": "general"}
                        )
            return suggestions
        except Exception as e:
            print(f"Danbooru autocomplete error: {e}")

        # Fallback: tag search
        try:
            url2 = f"{self.base_url}/tags.json"
            params2 = {
                "search[name_matches]": f"{partial}*",
                "search[order]": "count",
                "limit": 15,
            }
            data = await self.fetch_json(url2, params2)
            if isinstance(data, list):
                return [
                    {
                        "tag": t.get("name", ""),
                        "count": t.get("post_count", 0),
                        "type": {
                            0: "general",
                            1: "artist",
                            3: "copyright",
                            4: "character",
                        }.get(t.get("category", 0), "general"),
                    }
                    for t in data[:15]
                ]
        except Exception:
            pass
        return []
