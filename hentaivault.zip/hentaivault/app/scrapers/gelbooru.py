"""
Gelbooru.com scraper - uses HTML scraping (API now requires authentication)
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class GelbooruScraper(BaseScraper):
    """Gelbooru.com scraper (HTML-based)"""
    
    name = "gelbooru"
    base_url = "https://gelbooru.com"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Gelbooru using HTML scraping"""
        return await self._search_html(query, page, rating, artist, character)
    
    async def _search_html(
        self,
        query: str,
        page: int,
        rating: Optional[str],
        artist: Optional[str],
        character: Optional[str]
    ) -> Dict[str, Any]:
        """HTML scraping for Gelbooru"""
        from bs4 import BeautifulSoup
        
        # Build tags for URL
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        tags_str = " ".join(tags) if tags else ""
        # Gelbooru uses 42 items per page
        url = f"{self.base_url}/index.php?page=post&s=list&tags={tags_str}&pid={(page - 1) * 42}"
        
        try:
            html = await self.fetch_html(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            images = []
            thumbs = soup.find_all('span', class_='thumb')
            
            for thumb in thumbs:
                try:
                    link = thumb.find('a')
                    img = thumb.find('img')
                    
                    if link and img:
                        post_id = link.get('id', '').replace('p', '')
                        if not post_id:
                            # Try getting from href
                            href = link.get('href', '')
                            if 'id=' in href:
                                post_id = href.split('id=')[-1].split('&')[0]
                        
                        preview_url = img.get('src', '')
                        if preview_url and preview_url.startswith('//'):
                            preview_url = 'https:' + preview_url
                        elif preview_url and preview_url.startswith('/'):
                            preview_url = 'https://gelbooru.com' + preview_url
                        
                        # Get tags from title attribute
                        title = img.get('title', '')
                        tags_list = []
                        if title:
                            tags_list = [t.strip() for t in title.split(',') if t.strip()]
                        
                        # Extract artist and character from tags
                        artist_val = None
                        character_val = None
                        for tag in tags_list:
                            if tag.startswith('artist:'):
                                artist_val = tag.split(':', 1)[1]
                            elif tag.startswith('character:'):
                                character_val = tag.split(':', 1)[1]
                        
                        # Convert preview to sample
                        sample_url = preview_url
                        file_url = preview_url
                        if preview_url and 'thumbnails' in preview_url:
                            sample_url = preview_url.replace('/thumbnails/', '/samples/').replace('thumbnail_', 'sample_')
                            file_url = sample_url
                        
                        images.append({
                            "source_site": self.name,
                            "source_id": post_id,
                            "source_url": f"{self.base_url}/index.php?page=post&s=view&id={post_id}",
                            "file_url": file_url,
                            "preview_url": preview_url,
                            "sample_url": sample_url,
                            "width": None,
                            "height": None,
                            "file_size": None,
                            "file_ext": preview_url.split('.')[-1] if preview_url else 'jpg',
                            "tags": tags_list,
                            "artist": artist_val,
                            "character": character_val,
                            "rating": None,
                            "score": 0
                        })
                except Exception:
                    continue
            
            has_more = len(images) == 42
            
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details via HTML page parsing"""
        url = f"{self.base_url}/index.php?page=post&s=view&id={image_id}"
        try:
            html = await self.fetch_html(url)
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            
            # Find the main image
            img = soup.find('img', id='image') or soup.find('img', class_='preview')
            if img:
                src = img.get('src', '')
                if src and src.startswith('//'):
                    src = 'https:' + src
                return {
                    "source_site": self.name,
                    "source_id": image_id,
                    "source_url": url,
                    "file_url": src,
                    "preview_url": src,
                    "sample_url": src,
                }
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images using tags=order:score"""
        # Gelbooru doesn't have a popular page, use high-score search
        return await self._search_html("order:score", 1, None, None, None)

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images using order:random tag"""
        return await self._search_html("order:random", 1, None, None, None)

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions using Gelbooru's autocomplete API"""
        url = f"{self.base_url}/index.php?page=autocomplete&type=tag&term={partial}"
        try:
            # The autocomplete returns JSON in a specific format
            response = await self.fetch(url)
            data = response.json()
            if isinstance(data, list):
                suggestions = []
                for item in data[:10]:
                    suggestions.append({
                        "tag": item.get('name', ''),
                        "count": item.get('post_count', 0),
                        "type": item.get('type', 'general')
                    })
                return suggestions
        except Exception:
            pass
        return []