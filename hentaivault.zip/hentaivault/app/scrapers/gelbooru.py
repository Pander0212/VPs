"""
Gelbooru.com scraper - uses official JSON API with optional auth
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class GelbooruScraper(BaseScraper):
    """Gelbooru.com API scraper with JSON API and HTML fallback"""

    name = "gelbooru"
    base_url = "https://gelbooru.com"
    api_url = f"{base_url}/index.php"

    # Per-site credentials loaded from config
    _api_key: Optional[str] = None
    _user_id: Optional[str] = None

    def set_auth(self, api_key: str, user_id: str):
        self._api_key = api_key
        self._user_id = user_id

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Gelbooru using JSON API. Falls back to HTML scraping."""
        # Build tags
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        # Try JSON API first (works better with auth)
        api_result = await self._search_api(tags, page)
        if api_result and api_result.get("images"):
            return api_result

        # Fallback to HTML
        return await self._search_html(query, page, rating, artist, character)

    async def _search_api(self, tags: List[str], page: int) -> Optional[Dict[str, Any]]:
        """Search using Gelbooru JSON API"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": " ".join(tags),
            "pid": (page - 1),
            "limit": 100,
            "json": 1,
        }

        # Add auth if configured
        if self._api_key and self._user_id:
            params["api_key"] = self._api_key
            params["user_id"] = self._user_id

        try:
            data = await self.fetch_json(self.api_url, params)

            # Gelbooru returns {"post": [...]} or a list directly
            if isinstance(data, list):
                posts = data
            elif isinstance(data, dict) and "post" in data:
                posts = data.get("post", [])
                if not isinstance(posts, list):
                    posts = [posts] if posts else []
            else:
                return None

            if not posts:
                return None

            images = [self._parse_image(img) for img in posts]
            has_more = len(images) == 100

            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception as e:
            print(f"Gelbooru API error: {e}")
            return None

    async def _search_html(
        self,
        query: str,
        page: int,
        rating: Optional[str],
        artist: Optional[str],
        character: Optional[str],
    ) -> Dict[str, Any]:
        """HTML scraping fallback for Gelbooru"""
        from bs4 import BeautifulSoup

        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        tags_str = " ".join(tags) if tags else ""
        url = f"{self.base_url}/index.php?page=post&s=list&tags={tags_str}&pid={(page - 1) * 42}"

        try:
            html = await self.fetch_html(url)
            soup = BeautifulSoup(html, "html.parser")

            images = []
            # Find all thumb articles
            articles = soup.find_all("article", class_="thumb-preview") or soup.find_all(
                "span", class_="thumb"
            )

            for elem in articles:
                try:
                    link = elem.find("a")
                    img = elem.find("img")

                    if not link or not img:
                        continue

                    # Get post ID
                    post_id = ""
                    href = link.get("href", "")
                    if "id=" in href:
                        import re

                        m = re.search(r"id=(\d+)", href)
                        if m:
                            post_id = m.group(1)
                    if not post_id:
                        elem_id = elem.get("id", "") or link.get("id", "")
                        post_id = elem_id.replace("p", "").replace("s", "")

                    # Get preview URL - construct full URL
                    preview_url = img.get("src", "")
                    if preview_url:
                        if preview_url.startswith("//"):
                            preview_url = "https:" + preview_url
                        elif preview_url.startswith("/"):
                            preview_url = f"https://gelbooru.com{preview_url}"

                    # Build sample (higher res) URL from preview
                    # preview: /thumbnails/.../thumbnail_XXXXX.jpg
                    # sample:  /samples/.../sample_XXXXX.jpg
                    # full:    /images/.../XXXXX.jpg
                    sample_url = preview_url
                    file_url = preview_url
                    if preview_url and "thumbnails" in preview_url:
                        sample_url = (
                            preview_url.replace("/thumbnails/", "/samples/")
                            .replace("thumbnail_", "sample_")
                        )
                        # Try to derive full image URL
                        file_url = (
                            preview_url.replace("/thumbnails/", "/images/")
                            .replace("thumbnail_", "")
                        )

                    # Get tags from title
                    title = img.get("title", "")
                    tags_list = []
                    rating_val = None
                    if title:
                        parts = [t.strip() for t in title.split("Rating:")]
                        if len(parts) > 1:
                            rating_part = parts[1].strip().split()
                            if rating_part:
                                r = rating_part[0].lower()
                                rating_map = {
                                    "safe": "safe",
                                    "general": "safe",
                                    "questionable": "questionable",
                                    "sensitive": "questionable",
                                    "explicit": "explicit",
                                }
                                rating_val = rating_map.get(r, r)
                        tag_part = parts[0] if len(parts) > 1 else title
                        tags_list = [t.strip() for t in tag_part.split() if t.strip()]

                    # Extract artist/character
                    artist_val = None
                    character_val = None
                    score_val = 0
                    for tag in tags_list:
                        if tag.startswith("artist:"):
                            artist_val = tag.split(":", 1)[1]
                        elif tag.startswith("character:"):
                            character_val = tag.split(":", 1)[1]
                        elif tag.startswith("score:"):
                            try:
                                score_val = int(tag.split(":", 1)[1])
                            except:
                                pass

                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": post_id,
                            "source_url": f"{self.base_url}/index.php?page=post&s=view&id={post_id}",
                            "file_url": file_url,
                            "preview_url": preview_url,
                            "sample_url": sample_url,
                            "width": None,
                            "height": None,
                            "file_size": None,
                            "file_ext": preview_url.split(".")[-1].split("?")[0]
                            if preview_url
                            else "jpg",
                            "tags": tags_list,
                            "artist": artist_val,
                            "character": character_val,
                            "rating": rating_val,
                            "score": score_val,
                        }
                    )
                except Exception as e:
                    print(f"Gelbooru parse error: {e}")
                    continue

            has_more = len(images) == 42

            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception as e:
            print(f"Gelbooru HTML error: {e}")
            return {
                "images": [],
                "total": 0,
                "page": page,
                "has_more": False,
                "error": str(e),
            }

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse Gelbooru JSON API response into standard format"""
        tags = []
        if data.get("tags"):
            tags = [t.strip() for t in data["tags"].split() if t.strip()]

        artist = None
        character = None
        rating_val = None
        for tag in tags:
            if tag.startswith("artist:") and not artist:
                artist = tag.split(":", 1)[1]
            elif tag.startswith("character:") and not character:
                character = tag.split(":", 1)[1]
            elif tag.startswith("rating:") and not rating_val:
                rating_val = tag.split(":", 1)[1]

        # Construct full URLs (relative paths need base URL)
        file_url = data.get("file_url", "")
        sample_url = data.get("sample_url", "")
        preview_url = data.get("preview_url", "")

        # Ensure URLs are absolute
        for key in ["file_url", "sample_url", "preview_url"]:
            url = data.get(key, "")
            if url and url.startswith("/"):
                if key == "file_url":
                    file_url = f"https://{data.get('server', 'img3.gelbooru.com')}{url}" if "server" in data else f"{self.base_url}{url}"
                elif key == "sample_url":
                    sample_url = (
                        f"https://{data.get('server', 'img3.gelbooru.com')}{url}"
                        if "server" in data
                        else f"{self.base_url}{url}"
                    )
                elif key == "preview_url":
                    preview_url = f"{self.base_url}{url}"

        # PRIORITY: prefer file_url (highest quality), fallback to sample_url
        # For download quality, file_url > sample_url > preview_url
        best_url = file_url or sample_url or preview_url

        try:
            width = int(data.get("width", 0)) if data.get("width") else None
        except (ValueError, TypeError):
            width = None
        try:
            height = int(data.get("height", 0)) if data.get("height") else None
        except (ValueError, TypeError):
            height = None
        try:
            score = int(data.get("score", 0))
        except (ValueError, TypeError):
            score = 0

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/index.php?page=post&s=view&id={data.get('id')}",
            "file_url": best_url,
            "preview_url": preview_url,
            "sample_url": sample_url or best_url,
            "width": width,
            "height": height,
            "file_size": data.get("file_size"),
            "file_ext": data.get("file_url", "").split(".")[-1].split("?")[0]
            if data.get("file_url")
            else "jpg",
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": rating_val or data.get("rating"),
            "score": score,
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details via JSON API"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "id": image_id,
            "json": 1,
        }
        if self._api_key and self._user_id:
            params["api_key"] = self._api_key
            params["user_id"] = self._user_id

        try:
            data = await self.fetch_json(self.api_url, params)
            posts = []
            if isinstance(data, list):
                posts = data
            elif isinstance(data, dict) and "post" in data:
                post = data["post"]
                posts = [post] if isinstance(post, dict) else post
            if posts:
                return self._parse_image(posts[0])
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        return await self._search_api(["order:score"], 1) or {
            "images": [],
            "total": 0,
            "page": 1,
            "has_more": False,
        }

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        return await self._search_api(["order:random"], 1) or {
            "images": [],
            "total": 0,
            "page": 1,
            "has_more": False,
        }

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions using Gelbooru autocomplete API"""
        url = f"{self.base_url}/index.php"
        params = {
            "page": "autocomplete",
            "type": "tag_query",
            "term": partial,
            "limit": 15,
        }
        try:
            response = await self.fetch(url, params)
            data = response.json()
            suggestions = []
            if isinstance(data, list):
                for item in data[:15]:
                    tag_name = ""
                    tag_type = "general"
                    tag_count = 0
                    if isinstance(item, dict):
                        tag_name = item.get("value", "") or item.get("label", "")
                        tag_type = item.get("type", "general")
                        tag_count = item.get("post_count", 0) or item.get("count", 0)
                    elif isinstance(item, str):
                        tag_name = item
                    if tag_name:
                        suggestions.append(
                            {
                                "tag": tag_name,
                                "count": tag_count,
                                "type": tag_type,
                            }
                        )
            return suggestions
        except Exception:
            pass
        return []
