"""
e621.net scraper - excellent JSON API, no auth required
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class E621Scraper(BaseScraper):
    """e621.net API scraper"""

    name = "e621"
    base_url = "https://e621.net"
    api_url = f"{base_url}/posts.json"

    def get_headers(self) -> Dict[str, str]:
        headers = super().get_headers()
        headers["User-Agent"] = "HentaiVault/3.0 (by username on e621)"
        return headers

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search e621.net"""
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(artist)
        if character:
            tags.append(character)

        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 200,
        }

        try:
            data = await self.fetch_json(self.api_url, params)

            posts = data.get("posts", []) if isinstance(data, dict) else []
            images = [self._parse_image(img) for img in posts]

            # e621 returns empty dict when no results
            if not images and isinstance(data, dict) and not data.get("posts"):
                return {"images": [], "total": 0, "page": page, "has_more": False}

            has_more = len(images) == 200
            return {"images": images, "total": len(images), "page": page, "has_more": has_more}
        except Exception as e:
            print(f"e621 error: {e}")
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse e621 API response - priority for full-quality URL"""

        # Tags
        tags_general = data.get("tags", {}).get("general", [])
        tags_species = data.get("tags", {}).get("species", [])
        tags_meta = data.get("tags", {}).get("meta", [])
        tags_lore = data.get("tags", {}).get("lore", [])

        all_tags = []
        artist = None
        character = None

        # Artist tags
        artist_tags = data.get("tags", {}).get("artist", [])
        if artist_tags:
            artist = artist_tags[0]  # Primary artist

        # Character tags
        char_tags = data.get("tags", {}).get("character", [])
        if char_tags:
            character = char_tags[0]  # Primary character

        # Copyright tags
        copyright_tags = data.get("tags", {}).get("copyright", [])

        # Build full tag list with prefixes for SillyTavern compatibility
        all_tags.extend(tags_general)
        all_tags.extend(tags_species)
        all_tags.extend(tags_meta)
        all_tags.extend(tags_lore)
        all_tags.extend(f"artist:{a}" for a in artist_tags)
        all_tags.extend(f"character:{c}" for c in char_tags)
        all_tags.extend(f"copyright:{c}" for c in copyright_tags)

        # URL hierarchy: file_url (full original) > sample_url (scaled) > preview_url (thumbnail)
        file_url = data.get("file", {}).get("url", "")
        sample_url = data.get("sample", {}).get("url", "")
        preview_url = data.get("preview", {}).get("url", "")

        # Use full original file_url as primary download
        best_url = file_url or sample_url or preview_url

        # File extension
        file_ext = data.get("file", {}).get("ext", "jpg")

        # e621 uses "e" "q" "s" for rating
        rating_map = {"e": "explicit", "q": "questionable", "s": "safe"}
        rating_val = rating_map.get(data.get("rating", "s"), "safe")

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/posts/{data.get('id')}",
            "file_url": best_url,
            "preview_url": preview_url or best_url,
            "sample_url": sample_url or best_url,
            "width": data.get("file", {}).get("width"),
            "height": data.get("file", {}).get("height"),
            "file_size": data.get("file", {}).get("size"),
            "file_ext": file_ext,
            "tags": all_tags,
            "artist": artist,
            "character": character,
            "rating": rating_val,
            "score": data.get("score", {}).get("total", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        url = f"{self.api_url}?tags=id:{image_id}"
        try:
            data = await self.fetch_json(url)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            if posts:
                return self._parse_image(posts[0])
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        params = {"tags": "order:score", "limit": 50}
        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            images = [self._parse_image(img) for img in posts[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        params = {"tags": "order:random", "limit": count}
        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            images = [self._parse_image(img) for img in posts[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions from e621 autocomplete"""
        url = f"{self.base_url}/tags/autocomplete.json"
        params = {"search[name_matches]": f"{partial}*", "search[order]": "count", "limit": 15}
        try:
            data = await self.fetch_json(url, params)
            suggestions = []
            if isinstance(data, list):
                for tag in data[:15]:
                    tag_type = "general"
                    cat = tag.get("category", 0)
                    if cat == 1:
                        tag_type = "artist"
                    elif cat == 4:
                        tag_type = "character"
                    elif cat == 3:
                        tag_type = "copyright"
                    elif cat == 5:
                        tag_type = "species"

                    suggestions.append({
                        "tag": tag.get("name", ""),
                        "count": tag.get("post_count", 0),
                        "type": tag_type,
                    })
            return suggestions
        except Exception:
            pass
        return []
