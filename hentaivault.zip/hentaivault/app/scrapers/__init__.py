"""
Booru site scrapers registry
"""
from typing import Dict, Type
from .base import BaseScraper
from .rule34 import Rule34Scraper
from .rule34paheal import Rule34PahealScraper
from .gelbooru import GelbooruScraper
from .safebooru import SafebooruScraper
from .danbooru import DanbooruScraper
from .e621 import E621Scraper
from .e926 import E926Scraper
from .nhentai import NhentaiScraper


SCRAPERS: Dict[str, Type[BaseScraper]] = {
    "rule34": Rule34Scraper,
    "rule34paheal": Rule34PahealScraper,
    "gelbooru": GelbooruScraper,
    "safebooru": SafebooruScraper,
    "danbooru": DanbooruScraper,
    "e621": E621Scraper,
    "e926": E926Scraper,
    "nhentai": NhentaiScraper,
}


def get_scraper(site: str) -> BaseScraper:
    """Get scraper instance for a site"""
    if site not in SCRAPERS:
        raise ValueError(f"Unknown site: {site}")
    return SCRAPERS[site]()


def get_all_scrapers() -> Dict[str, BaseScraper]:
    """Get all scraper instances"""
    return {name: cls() for name, cls in SCRAPERS.items()}