"""
Booru site scrapers registry
"""
from typing import Dict, Type
from .base import BaseScraper
from .rule34 import Rule34Scraper
from .rule34paheal import Rule34PahealScraper
from .gelbooru import GelbooruScraper
from .safebooru import SafebooruScraper
from .danbooru import DanbooruScraper
from .e621 import E621Scraper
from .e926 import E926Scraper
from .nhentai import NhentaiScraper
from .yandere import YandereScraper
from .konachan import KonachanScraper
from .zerochan import ZerochanScraper
from .sankaku import SankakuScraper


# Site metadata: display name, requires auth, auth type, description
SITE_META = {
    "rule34": {
        "name": "Rule34.xxx",
        "needs_auth": False,
        "auth_type": None,
        "quality": "Medium",
        "description": "Large booru, full-resolution available",
    },
    "rule34paheal": {
        "name": "Rule34 Paheal",
        "needs_auth": False,
        "auth_type": None,
        "quality": "Low-Med",
        "description": "Alternative Rule34 mirror (Shimmie)",
    },
    "gelbooru": {
        "name": "Gelbooru",
        "needs_auth": False,
        "auth_type": "apikey",
        "quality": "Medium-High",
        "description": "Popular booru, optional API key for full access",
        "auth_fields": [
            {"key": "api_key", "label": "API Key", "type": "password"},
            {"key": "user_id", "label": "User ID", "type": "text"},
        ],
    },
    "safebooru": {
        "name": "Safebooru",
        "needs_auth": False,
        "auth_type": None,
        "quality": "Medium",
        "description": "SFW booru, good quality",
    },
    "danbooru": {
        "name": "Danbooru",
        "needs_auth": True,
        "auth_type": "apikey",
        "quality": "High",
        "description": "High-quality, requires API key (Gold+) or login",
        "auth_hint": "Get your API key from Danbooru → My Account → API Key",
        "auth_fields": [
            {"key": "api_key", "label": "API Key", "type": "password"},
            {"key": "username", "label": "Username", "type": "text"},
        ],
    },
    "e621": {
        "name": "e621",
        "needs_auth": False,
        "auth_type": None,
        "quality": "High",
        "description": "Furry booru, excellent API",
    },
    "e926": {
        "name": "e926",
        "needs_auth": False,
        "auth_type": None,
        "quality": "High",
        "description": "SFW version of e621",
    },
    "nhentai": {
        "name": "nHentai",
        "needs_auth": False,
        "auth_type": None,
        "quality": "Medium",
        "description": "Doujinshi/gallery site",
    },
    "yandere": {
        "name": "Yande.re",
        "needs_auth": False,
        "auth_type": None,
        "quality": "High",
        "description": "High-quality anime images",
    },
    "konachan": {
        "name": "Konachan",
        "needs_auth": False,
        "auth_type": None,
        "quality": "High",
        "description": "Anime/manga wallpapers (Moebooru)",
    },
    "zerochan": {
        "name": "Zerochan",
        "needs_auth": False,
        "auth_type": None,
        "quality": "High",
        "description": "Anime image board with JSON API",
    },
    "sankaku": {
        "name": "Sankaku Complex",
        "needs_auth": False,
        "auth_type": "login",
        "quality": "High",
        "description": "Large anime image archive, login for full access",
        "auth_fields": [
            {"key": "login", "label": "Username/Email", "type": "text"},
            {"key": "password", "label": "Password", "type": "password"},
        ],
    },
}


# Working scrapers (some sites require auth or have broken APIs)
SCRAPERS: Dict[str, Type[BaseScraper]] = {
    "rule34": Rule34Scraper,
    "rule34paheal": Rule34PahealScraper,
    "gelbooru": GelbooruScraper,
    "safebooru": SafebooruScraper,
    "danbooru": DanbooruScraper,
    "e621": E621Scraper,
    "e926": E926Scraper,
    "nhentai": NhentaiScraper,
    "yandere": YandereScraper,
    "konachan": KonachanScraper,
    "zerochan": ZerochanScraper,
    "sankaku": SankakuScraper,
}

# Cache for scraper instances with auth configured
_scraper_instances: Dict[str, BaseScraper] = {}


def get_scraper(site: str) -> BaseScraper:
    """Get scraper instance for a site (cached with auth)"""
    if site not in SCRAPERS:
        raise ValueError(f"Unknown site: {site}")

    # Return cached instance if exists
    if site in _scraper_instances:
        return _scraper_instances[site]

    instance = SCRAPERS[site]()
    _scraper_instances[site] = instance
    return instance


def apply_auth_to_scrapers(source_configs: dict):
    """Apply per-site authentication to scraper instances"""
    for site_id, config in source_configs.items():
        if site_id not in SCRAPERS:
            continue
        scraper = get_scraper(site_id)

        api_key = config.get("api_key", "")
        user_id = config.get("user_id", "")
        username = config.get("username", "")
        password = config.get("password", "")
        login = config.get("login", "")
        access_token = config.get("access_token", "")

        if hasattr(scraper, "set_auth"):
            if site_id in ("gelbooru",):
                scraper.set_auth(api_key, user_id)
            elif site_id in ("danbooru",):
                scraper.set_auth(api_key, username)
            elif site_id in ("sankaku",):
                scraper.set_auth(
                    login=login or username, password=password, access_token=access_token
                )


def get_all_scrapers() -> Dict[str, BaseScraper]:
    """Get all scraper instances"""
    return {name: get_scraper(name) for name in SCRAPERS}
