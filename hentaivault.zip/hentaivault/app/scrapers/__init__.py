"""
Booru site scrapers registry
"""
from typing import Dict, Type
from .base import BaseScraper
from .rule34 import Rule34Scraper
from .rule34paheal import Rule34PahealScraper
from .gelbooru import GelbooruScraper
from .safebooru import SafebooruScraper
from .danbooru import DanbooruScraper
from .e621 import E621Scraper
from .e926 import E926Scraper
from .nhentai import NhentaiScraper
from .yandere import YandereScraper
from .konachan import KonachanScraper
from .zerochan import ZerochanScraper
from .sankaku import SankakuScraper


# Site metadata: display name, requires auth, auth type, description
SITE_META = {
    "rule34": {"name": "Rule34.xxx", "needs_auth": False, "auth_type": None, "quality": "Low-Med", "description": "Large booru, lower resolution"},
    "rule34paheal": {"name": "Rule34 Paheal", "needs_auth": False, "auth_type": None, "quality": "Low", "description": "Alternative Rule34 mirror"},
    "gelbooru": {"name": "Gelbooru", "needs_auth": False, "auth_type": None, "quality": "Medium", "description": "Popular booru with good tagging"},
    "safebooru": {"name": "Safebooru", "needs_auth": False, "auth_type": None, "quality": "Medium", "description": "SFW booru, good quality"},
    "danbooru": {"name": "Danbooru", "needs_auth": True, "auth_type": "apikey", "quality": "High", "description": "High-quality, requires API key"},
    "e621": {"name": "e621", "needs_auth": False, "auth_type": None, "quality": "High", "description": "Furry booru, excellent API"},
    "e926": {"name": "e926", "needs_auth": False, "auth_type": None, "quality": "High", "description": "SFW version of e621"},
    "nhentai": {"name": "nHentai", "needs_auth": False, "auth_type": None, "quality": "Medium", "description": "Doujinshi/gallery site"},
    "yandere": {"name": "Yande.re", "needs_auth": False, "auth_type": None, "quality": "High", "description": "High-quality anime images"},
    "konachan": {"name": "Konachan", "needs_auth": False, "auth_type": None, "quality": "High", "description": "Anime/manga wallpapers"},
    "zerochan": {"name": "Zerochan", "needs_auth": False, "auth_type": None, "quality": "High", "description": "Anime image board"},
    "sankaku": {"name": "Sankaku Complex", "needs_auth": False, "auth_type": None, "quality": "High", "description": "Large anime image archive"},
}


# Working scrapers (some sites require auth or have broken APIs)
SCRAPERS: Dict[str, Type[BaseScraper]] = {
    "rule34": Rule34Scraper,
    "rule34paheal": Rule34PahealScraper,
    "gelbooru": GelbooruScraper,
    "safebooru": SafebooruScraper,
    "danbooru": DanbooruScraper,
    "e621": E621Scraper,
    "e926": E926Scraper,
    "nhentai": NhentaiScraper,
    "yandere": YandereScraper,
    "konachan": KonachanScraper,
    "zerochan": ZerochanScraper,
    "sankaku": SankakuScraper,
}


def get_scraper(site: str) -> BaseScraper:
    """Get scraper instance for a site"""
    if site not in SCRAPERS:
        raise ValueError(f"Unknown site: {site}")
    return SCRAPERS[site]()


def get_all_scrapers() -> Dict[str, BaseScraper]:
    """Get all scraper instances"""
    return {name: cls() for name, cls in SCRAPERS.items()}