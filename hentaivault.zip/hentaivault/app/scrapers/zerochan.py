"""
Zerochan.net scraper - uses official JSON API with proper User-Agent
"""
from typing import Dict, List, Any, Optional
import re
from app.scrapers.base import BaseScraper


class ZerochanScraper(BaseScraper):
    """Zerochan.net API scraper with HTML fallback"""

    name = "zerochan"
    base_url = "https://www.zerochan.net"

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Zerochan using JSON API first, then HTML"""

        # Try JSON API first
        api_result = await self._search_api(query, page, rating, artist, character)
        if api_result and api_result.get("images"):
            return api_result

        # Fallback to HTML
        return await self._search_html(query, page, rating, artist, character)

    async def _search_api(
        self,
        query: str,
        page: int,
        rating: Optional[str],
        artist: Optional[str],
        character: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        """Search using Zerochan JSON API"""
        # Zerochan's JSON API: https://www.zerochan.net/{tag}?json
        search_term = query
        if character:
            search_term = f"{search_term}+{character}" if search_term else character
        if artist:
            search_term = f"{search_term}+{artist}" if search_term else artist

        if not search_term:
            return None

        params = {"json": "", "p": page, "l": 100}
        url = f"{self.base_url}/{search_term.replace(' ', '+')}"

        try:
            data = await self.fetch_json(url, params)

            if not isinstance(data, dict):
                return None

            items = data.get("items", [])
            if not items:
                return None

            images = []
            for item in items[:100]:
                try:
                    pid = str(item.get("id", ""))

                    # Get highest quality URL
                    # Zerochan provides: small, medium, full URLs
                    full_url = item.get("full", "") or item.get("fullsize", "")
                    if full_url and not full_url.startswith("http"):
                        full_url = (
                            self.base_url + full_url
                            if full_url.startswith("/")
                            else f"{self.base_url}/{full_url}"
                        )

                    thumb_url = item.get("small", "") or item.get("thumbnail", "")
                    if thumb_url and not thumb_url.startswith("http"):
                        thumb_url = (
                            self.base_url + thumb_url
                            if thumb_url.startswith("/")
                            else f"{self.base_url}/{thumb_url}"
                        )

                    # Tags
                    tag_list = []
                    raw_tags = item.get("tags", [])
                    if isinstance(raw_tags, list):
                        tag_list = [
                            t if isinstance(t, str) else t.get("tag", "")
                            for t in raw_tags
                        ]
                    elif isinstance(raw_tags, str):
                        tag_list = [t.strip() for t in raw_tags.split(",")]

                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": pid,
                            "source_url": f"{self.base_url}/{pid}",
                            "file_url": full_url or thumb_url,
                            "preview_url": thumb_url or full_url,
                            "sample_url": full_url or thumb_url,
                            "width": item.get("width"),
                            "height": item.get("height"),
                            "file_size": item.get("size") or item.get("filesize"),
                            "file_ext": (full_url or thumb_url or ".jpg")
                            .split(".")[-1]
                            .split("?")[0],
                            "tags": tag_list,
                            "artist": None,
                            "character": None,
                            "rating": rating or "safe",
                            "score": item.get("favorites", 0)
                            or item.get("favs", 0),
                        }
                    )
                except Exception as e:
                    print(f"Zerochan parse error: {e}")
                    continue

            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": len(items) >= 100,
            }
        except Exception as e:
            print(f"Zerochan API error: {e}")
            return None

    async def _search_html(
        self,
        query: str,
        page: int,
        rating: Optional[str],
        artist: Optional[str],
        character: Optional[str],
    ) -> Dict[str, Any]:
        """HTML scraping fallback"""
        from bs4 import BeautifulSoup

        search_term = query
        if character:
            search_term = f"{search_term}+{character}" if search_term else character
        if artist:
            search_term = f"{search_term}+{artist}" if search_term else artist

        params = {"p": page} if page > 1 else {}
        url = (
            f"{self.base_url}/{search_term.replace(' ', '+')}"
            if search_term
            else self.base_url
        )

        try:
            html = await self.fetch_html(url, params)
            soup = BeautifulSoup(html, "html.parser")

            images = []
            # Zerochan uses <ul id="thumbs2"> with <li> items
            thumbs_container = soup.find("ul", id="thumbs2") or soup.find(
                "ul", id="thumbs"
            )
            if thumbs_container:
                lis = thumbs_container.find_all("li")
            else:
                lis = soup.find_all("li")

            for li in lis:
                try:
                    link = li.find("a")
                    img = li.find("img")
                    if not link or not img:
                        continue

                    href = link.get("href", "")
                    pid = ""
                    m = re.search(r"/(\d+)", href)
                    if m:
                        pid = m.group(1)

                    src = img.get("src", "")
                    if src and not src.startswith("http"):
                        src = (
                            self.base_url + src
                            if src.startswith("/")
                            else f"{self.base_url}/{src}"
                        )

                    # Derive full URL from thumbnail
                    full_url = src
                    if src and ("thumb" in src.lower() or ".240." in src):
                        full_url = src.replace(".240.", ".full.")

                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": pid,
                            "source_url": (
                                f"{self.base_url}{href}"
                                if href.startswith("/")
                                else href
                            ),
                            "file_url": full_url,
                            "preview_url": src,
                            "sample_url": full_url,
                            "width": None,
                            "height": None,
                            "file_size": None,
                            "file_ext": src.split(".")[-1].split("?")[0]
                            if src
                            else "jpg",
                            "tags": [],
                            "artist": None,
                            "character": None,
                            "rating": "safe",
                            "score": 0,
                        }
                    )
                except Exception:
                    continue

            has_more = len(images) >= 30
            return {
                "images": images[:100],
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception as e:
            print(f"Zerochan HTML error: {e}")
            return {
                "images": [],
                "total": 0,
                "page": page,
                "has_more": False,
                "error": str(e),
            }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        url = f"{self.base_url}/{image_id}?json"
        try:
            data = await self.fetch_json(url)
            if not data:
                return None

            full_url = data.get("full", "") or data.get("fullsize", "")
            if full_url and not full_url.startswith("http"):
                full_url = (
                    self.base_url + full_url
                    if full_url.startswith("/")
                    else f"{self.base_url}/{full_url}"
                )

            tags = []
            raw_tags = data.get("tags", [])
            if isinstance(raw_tags, list):
                tags = [
                    t if isinstance(t, str) else t.get("tag", "")
                    for t in raw_tags
                ]
            elif isinstance(raw_tags, str):
                tags = [t.strip() for t in raw_tags.split(",")]

            return {
                "source_site": self.name,
                "source_id": image_id,
                "source_url": url,
                "file_url": full_url,
                "preview_url": data.get("small", full_url),
                "sample_url": full_url,
                "width": data.get("width"),
                "height": data.get("height"),
                "tags": tags,
            }
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        url = f"{self.base_url}/top?json"
        try:
            data = await self.fetch_json(url)
            if isinstance(data, dict) and "items" in data:
                items = data["items"][:50]
                images = []
                for item in items:
                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": str(item.get("id", "")),
                            "source_url": f"{self.base_url}/{item.get('id')}",
                            "file_url": item.get("full", item.get("small", "")),
                            "preview_url": item.get("small", ""),
                            "sample_url": item.get("full", ""),
                            "tags": [],
                            "score": item.get("favorites", 0),
                            "rating": "safe",
                        }
                    )
                return {
                    "images": images[:50],
                    "total": len(images),
                    "page": 1,
                    "has_more": False,
                }
        except Exception:
            pass
        return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        url = f"{self.base_url}/random?json"
        try:
            data = await self.fetch_json(url)
            if isinstance(data, dict) and "items" in data:
                items = data["items"][:count]
                images = []
                for item in items:
                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": str(item.get("id", "")),
                            "source_url": f"{self.base_url}/{item.get('id')}",
                            "file_url": item.get("full", item.get("small", "")),
                            "preview_url": item.get("small", ""),
                            "sample_url": item.get("full", ""),
                            "tags": [],
                            "score": 0,
                            "rating": "safe",
                        }
                    )
                return {
                    "images": images[:count],
                    "total": len(images),
                    "page": 1,
                    "has_more": False,
                }
        except Exception:
            pass
        return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Zerochan tag autocomplete via suggestive search"""
        url = f"{self.base_url}/suggest?q={partial}&limit=10&json"
        try:
            data = await self.fetch_json(url)
            suggestions = []
            if isinstance(data, list):
                for item in data[:10]:
                    if isinstance(item, dict):
                        tag = item.get("value", "") or item.get("label", "")
                        if tag:
                            suggestions.append(
                                {
                                    "tag": tag,
                                    "count": item.get("count", 0),
                                    "type": "general",
                                }
                            )
                    elif isinstance(item, str):
                        suggestions.append(
                            {"tag": item, "count": 0, "type": "general"}
                        )
            elif isinstance(data, dict):
                # Some suggest endpoints return {suggestions: [...]}
                items = data.get("suggestions", []) or data.get("results", [])
                for item in items[:10]:
                    if isinstance(item, dict):
                        tag = item.get("value", "") or item.get("label", "")
                        if tag:
                            suggestions.append(
                                {
                                    "tag": tag,
                                    "count": 0,
                                    "type": "general",
                                }
                            )
            return suggestions
        except Exception:
            pass
        return []
