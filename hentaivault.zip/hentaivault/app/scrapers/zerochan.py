"""
Zerochan.net scraper - uses HTML scraping with BeautifulSoup
"""
from typing import Dict, List, Any, Optional
import re
from app.scrapers.base import BaseScraper


class ZerochanScraper(BaseScraper):
    """Zerochan.net HTML scraper"""
    
    name = "zerochan"
    base_url = "https://www.zerochan.net"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Zerochan"""
        from bs4 import BeautifulSoup
        
        # Build search URL - Zerochan uses query params
        params = {}
        q_parts = []
        if query:
            q_parts.append(query)
        if artist:
            q_parts.append(artist)
        if character:
            q_parts.append(character)
        
        if q_parts:
            params["q"] = " ".join(q_parts)
        
        params["p"] = page
        search_url = f"{self.base_url}/search"
        # Zerochan uses a specific search path format
        if q_parts:
            search_url = f"{self.base_url}/{'+'.join(q_parts)}?p={page}"
        else:
            search_url = f"{self.base_url}/?p={page}"
        
        try:
            html = await self.fetch_html(search_url)
            soup = BeautifulSoup(html, 'html.parser')
            
            images = []
            thumbs = soup.find_all('li')  # Zerochan uses li for thumbnails
            
            for thumb in thumbs:
                try:
                    link = thumb.find('a')
                    img = thumb.find('img')
                    if not (link and img):
                        continue
                    
                    href = link.get('href', '')
                    src = img.get('src', '')
                    alt = img.get('alt', '')
                    
                    # Skip if no valid href (not an image link)
                    if '/full/' not in href and not href.startswith('/'):
                        continue
                    
                    post_id = href.strip('/').split('/')[-1]
                    if not post_id.isdigit():
                        # Try extracting from the URL
                        match = re.search(r'/(\d+)', href)
                        if match:
                            post_id = match.group(1)
                        else:
                            continue
                    
                    if src and not src.startswith('http'):
                        src = self.base_url + src if src.startswith('/') else f"{self.base_url}/{src}"
                    
                    tags = [t.strip() for t in alt.split(',')] if alt else []
                    
                    images.append({
                        "source_site": self.name,
                        "source_id": post_id,
                        "source_url": f"{self.base_url}{href}" if href.startswith('/') else href,
                        "file_url": src.replace('.240.', '.full.'),  # try full res
                        "preview_url": src,
                        "sample_url": src,
                        "width": None,
                        "height": None,
                        "file_size": None,
                        "file_ext": src.split('.')[-1] if src else 'jpg',
                        "tags": tags,
                        "artist": None,
                        "character": None,
                        "rating": rating,
                        "score": 0
                    })
                except Exception:
                    continue
            
            has_more = len(images) >= 30
            return {
                "images": images[:100],
                "total": len(images),
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        url = f"{self.base_url}/{image_id}"
        try:
            html = await self.fetch_html(url)
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            img = soup.find('img', id='large') or soup.find('img', class_='preview')
            if img:
                src = img.get('src', '')
                if src and not src.startswith('http'):
                    src = self.base_url + src if src.startswith('/') else f"{self.base_url}/{src}"
                return {
                    "source_site": self.name,
                    "source_id": image_id,
                    "source_url": url,
                    "file_url": src,
                    "preview_url": src,
                }
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        url = f"{self.base_url}/top?period={timeframe}"
        try:
            html = await self.fetch_html(url)
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            images = []
            for thumb in soup.find_all('li')[:50]:
                link = thumb.find('a')
                img = thumb.find('img')
                if link and img:
                    src = img.get('src', '')
                    if src and not src.startswith('http'):
                        src = self.base_url + src if src.startswith('/') else f"{self.base_url}/{src}"
                    images.append({
                        "source_site": self.name,
                        "source_id": link.get('href', '').strip('/').split('/')[-1],
                        "source_url": self.base_url + link.get('href', ''),
                        "file_url": src,
                        "preview_url": src,
                        "sample_url": src,
                        "tags": [],
                        "score": 0,
                        "rating": "safe",
                    })
            return {"images": images[:50], "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        url = f"{self.base_url}/random"
        try:
            html = await self.fetch_html(url)
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            images = []
            for thumb in soup.find_all('li')[:count]:
                link = thumb.find('a')
                img = thumb.find('img')
                if link and img:
                    src = img.get('src', '')
                    if src and not src.startswith('http'):
                        src = self.base_url + src if src.startswith('/') else f"{self.base_url}/{src}"
                    images.append({
                        "source_site": self.name,
                        "source_id": link.get('href', '').strip('/').split('/')[-1],
                        "source_url": self.base_url + link.get('href', ''),
                        "file_url": src,
                        "preview_url": src,
                        "sample_url": src,
                        "tags": [],
                        "score": 0,
                        "rating": "safe",
                    })
            return {"images": images[:count], "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        return []
