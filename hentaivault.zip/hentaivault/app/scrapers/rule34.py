"""
Rule34.xxx scraper - uses official API
"""
from typing import Dict, List, Any, Optional
import re
from app.scrapers.base import BaseScraper


class Rule34Scraper(BaseScraper):
    """Rule34.xxx API scraper"""
    
    name = "rule34"
    base_url = "https://api.rule34.xxx/index.php"
    page_url = "https://rule34.xxx/index.php"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Rule34.xxx"""
        
        # Build tags
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        # API parameters
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": " ".join(tags) if tags else "",
            "pid": (page - 1) * 100,  # Rule34 uses offset
            "json": 1,
            "limit": 100
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
        
        if not data:
            data = []
        
        images = [self._parse_image(img) for img in data]
        
        # Rule34 doesn't provide total count in API, estimate based on results
        total = len(images)
        has_more = len(images) == 100
        
        return {
            "images": images,
            "total": total,
            "page": page,
            "has_more": has_more
        }
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response into standard format"""
        tags = []
        if data.get("tags"):
            tags = [t.strip() for t in data["tags"].split() if t.strip()]
        
        # Extract artist and character from tags
        artist = None
        character = None
        for tag in tags:
            if tag.startswith("artist:"):
                artist = tag.split(":", 1)[1]
            elif tag.startswith("character:"):
                character = tag.split(":", 1)[1]
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.page_url}?page=post&s=view&id={data.get('id')}",
            "file_url": data.get("file_url", ""),
            "preview_url": data.get("preview_url", data.get("sample_url", "")),
            "sample_url": data.get("sample_url", ""),
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": None,  # Not provided by API
            "file_ext": data.get("file_url", "").split(".")[-1] if data.get("file_url") else None,
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("score", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get detailed image info"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "id": image_id,
            "json": 1
        }
        
        data = await self.fetch_json(self.base_url, params)
        if isinstance(data, list) and len(data) > 0:
            return self._parse_image(data[0])
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images (Rule34 has limited support)"""
        # Rule34 API doesn't have native popular endpoint
        # Use high-score search as approximation
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": f"score:>=10 order:score",
            "json": 1,
            "limit": 50
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            images = [self._parse_image(img) for img in data[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": "order:random",
            "json": 1,
            "limit": count
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            images = [self._parse_image(img) for img in data[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag autocomplete suggestions"""
        params = {
            "page": "dapi",
            "s": "tag",
            "q": "index",
            "name_pattern": f"{partial}*",
            "order": "count",
            "json": 1
        }
        
        try:
            data = await self.fetch_json(self.base_url, params)
            suggestions = []
            for tag in data[:10]:
                suggestions.append({
                    "tag": tag.get("name", ""),
                    "count": tag.get("count", 0),
                    "type": self._get_tag_type(tag.get("type", 0))
                })
            return suggestions
        except Exception:
            return []
    
    def _get_tag_type(self, type_id: int) -> str:
        """Convert Rule34 tag type ID to name"""
        types = {
            0: "general",
            1: "artist",
            3: "copyright",
            4: "character"
        }
        return types.get(type_id, "general")