"""
Rule34.xxx scraper - prioritizes high-quality images via API and HTML scraping
"""
from typing import Dict, List, Any, Optional
import re
from app.scrapers.base import BaseScraper


class Rule34Scraper(BaseScraper):
    """Rule34.xxx scraper - API with full-quality image fallback"""

    name = "rule34"
    base_url = "https://api.rule34.xxx/index.php"
    page_url = "https://rule34.xxx/index.php"
    site_url = "https://rule34.xxx"

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Rule34.xxx - API first, HTML fallback"""

        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        # Try API first
        api_result = await self._search_api(tags, page)
        if api_result and api_result.get("images"):
            return api_result

        # Fallback to HTML with higher quality URLs
        return await self._search_html(query, page, rating, artist, character)

    async def _search_api(self, tags: List[str], page: int) -> Optional[Dict[str, Any]]:
        """Try the Rule34 JSON API"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": " ".join(tags) if tags else "",
            "pid": (page - 1) * 100,
            "json": 1,
            "limit": 100,
        }

        try:
            data = await self.fetch_json(self.base_url, params)

            # Handle auth errors
            if isinstance(data, (str, bytes)):
                if isinstance(data, bytes):
                    data = data.decode("utf-8", errors="replace")
                if "authentication" in str(data).lower():
                    return None

            if not isinstance(data, list) or len(data) == 0:
                return None

            images = [self._parse_image(img) for img in data]
            has_more = len(images) == 100

            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception:
            return None

    async def _search_html(
        self,
        query: str,
        page: int,
        rating: Optional[str],
        artist: Optional[str],
        character: Optional[str],
    ) -> Dict[str, Any]:
        """HTML scraping with priority for highest-quality URLs"""
        from bs4 import BeautifulSoup

        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")

        tags_str = "+".join(tags) if tags else ""
        url = f"{self.site_url}/index.php?page=post&s=list&tags={tags_str}&pid={(page - 1) * 42}"

        try:
            html = await self.fetch_html(url)
            soup = BeautifulSoup(html, "html.parser")

            images = []
            thumbs = soup.find_all("span", class_="thumb")

            for thumb_elem in thumbs:
                try:
                    link = thumb_elem.find("a")
                    img = thumb_elem.find("img")

                    if not link or not img:
                        continue

                    # Get post ID
                    post_id = link.get("id", "").replace("s", "")
                    if not post_id:
                        href = link.get("href", "")
                        m = re.search(r"id=(\d+)", href)
                        if m:
                            post_id = m.group(1)

                    # Preview URL
                    preview_url = img.get("src", "")
                    if preview_url:
                        if preview_url.startswith("//"):
                            preview_url = "https:" + preview_url
                        elif preview_url.startswith("/"):
                            preview_url = f"{self.site_url}{preview_url}"

                    # === HIGHEST QUALITY URL RESOLUTION ===
                    # Rule34 URL structure:
                    # thumbnail: /thumbnails/{dir}/thumbnail_{id}.jpg
                    # sample:    /samples/{dir}/sample_{id}.jpg
                    # full:      /images/{dir}/{id}.jpg  (or .png/.gif)
                    sample_url = preview_url
                    file_url = preview_url

                    if preview_url and "thumbnails" in preview_url:
                        # Derive sample URL
                        sample_url = preview_url.replace(
                            "/thumbnails/", "/samples/"
                        ).replace("thumbnail_", "sample_")

                        # Derive FULL image URL (highest quality)
                        # thumbnail_{hash}.ext -> {hash}.ext
                        file_url = (
                            preview_url.replace("/thumbnails/", "/images/").replace(
                                "thumbnail_", ""
                            )
                        )
                        # Try to fix extension for full images (could be png even if thumb is jpg)
                        # We'll keep the derived URL and let the downloader handle errors

                    # Tags from title attribute
                    title = img.get("title", "")
                    tags_list = []
                    rating_val = None
                    score_val = 0
                    if title:
                        # Rule34 format: "tag1 tag2 ... rating:explicit score:123"
                        parts = title.split()
                        for p in parts:
                            if p.startswith("rating:"):
                                rating_val = p.split(":", 1)[1]
                            elif p.startswith("score:"):
                                try:
                                    score_val = int(p.split(":", 1)[1])
                                except:
                                    pass
                            elif not p.startswith("id:") and not p.startswith("score:"):
                                tags_list.append(p)

                    # Extract artist/character
                    artist_val = None
                    character_val = None
                    for tag in tags_list:
                        if tag.startswith("artist:"):
                            artist_val = tag.split(":", 1)[1]
                        elif tag.startswith("character:"):
                            character_val = tag.split(":", 1)[1]

                    images.append(
                        {
                            "source_site": self.name,
                            "source_id": post_id,
                            "source_url": f"{self.site_url}/index.php?page=post&s=view&id={post_id}",
                            "file_url": file_url,  # Full resolution!
                            "preview_url": preview_url,
                            "sample_url": sample_url,
                            "width": None,
                            "height": None,
                            "file_size": None,
                            "file_ext": file_url.split(".")[-1].split("?")[0]
                            if file_url
                            else "jpg",
                            "tags": tags_list,
                            "artist": artist_val,
                            "character": character_val,
                            "rating": rating_val,
                            "score": score_val,
                        }
                    )
                except Exception as e:
                    print(f"Rule34 parse error: {e}")
                    continue

            has_more = len(images) == 42
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more,
            }
        except Exception as e:
            print(f"Rule34 HTML error: {e}")
            return {
                "images": [],
                "total": 0,
                "page": page,
                "has_more": False,
                "error": str(e),
            }

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response with priority for highest quality URL"""
        tags = []
        if data.get("tags"):
            tags = [t.strip() for t in data["tags"].split() if t.strip()]

        artist = None
        character = None
        for tag in tags:
            if tag.startswith("artist:"):
                artist = tag.split(":", 1)[1]
            elif tag.startswith("character:"):
                character = tag.split(":", 1)[1]

        # HIGH QUALITY PRIORITY: file_url > sample_url > preview_url
        raw_file_url = data.get("file_url", "")
        sample_url = data.get("sample_url", "")
        preview_url = data.get("preview_url", "")

        # Ensure all URLs are absolute
        if raw_file_url and raw_file_url.startswith("//"):
            raw_file_url = "https:" + raw_file_url
        if sample_url and sample_url.startswith("//"):
            sample_url = "https:" + sample_url
        if preview_url and preview_url.startswith("//"):
            preview_url = "https:" + preview_url

        # file_url is the highest quality
        file_url = raw_file_url or sample_url or preview_url

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.page_url}?page=post&s=view&id={data.get('id')}",
            "file_url": file_url,
            "preview_url": preview_url or file_url,
            "sample_url": sample_url or file_url,
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": None,
            "file_ext": file_url.split(".")[-1].split("?")[0] if file_url else "jpg",
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": data.get("rating"),
            "score": data.get("score", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get full image details, prioritizing highest quality URL"""
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "id": image_id,
            "json": 1,
        }
        try:
            data = await self.fetch_json(self.base_url, params)
            if isinstance(data, list) and len(data) > 0:
                return self._parse_image(data[0])
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        result = await self._search_api(["score:>=10", "order:score"], 1)
        return result or {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        result = await self._search_api(["order:random"], 1)
        return result or {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag autocomplete suggestions from Rule34"""
        # Rule34 has a tag API
        params = {
            "page": "dapi",
            "s": "tag",
            "q": "index",
            "name_pattern": f"{partial}*",
            "orderby": "count",
            "order": "desc",
            "limit": 15,
            "json": 1,
        }
        try:
            data = await self.fetch_json(self.base_url, params)
            suggestions = []
            if isinstance(data, list):
                for tag in data[:15]:
                    suggestions.append(
                        {
                            "tag": tag.get("name", ""),
                            "count": tag.get("count", 0),
                            "type": self._tag_type(
                                int(tag.get("type", 0))
                            ),
                        }
                    )
            elif isinstance(data, dict):
                items = data.get("tag", [])
                if not isinstance(items, list):
                    items = [items]
                for tag in items[:15]:
                    suggestions.append(
                        {
                            "tag": tag.get("name", ""),
                            "count": int(tag.get("count", 0)),
                            "type": self._tag_type(
                                int(tag.get("type", 0))
                            ),
                        }
                    )
            return suggestions
        except Exception:
            pass
        return []

    @staticmethod
    def _tag_type(type_id: int) -> str:
        return {0: "general", 1: "artist", 3: "copyright", 4: "character"}.get(
            type_id, "general"
        )
