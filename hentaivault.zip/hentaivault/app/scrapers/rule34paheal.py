"""
Rule34.paheal.net scraper - uses Shimmie API
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class Rule34PahealScraper(BaseScraper):
    """Rule34.paheal.net API scraper (Shimmie-based)"""
    
    name = "rule34paheal"
    base_url = "https://rule34.paheal.net"
    api_url = f"{base_url}/index.php"
    
    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Rule34.paheal"""
        
        tags = []
        if query:
            tags.append(query)
        if rating:
            rating_map = {"safe": "safe", "questionable": "questionable", "explicit": "explicit"}
            tags.append(f"rating:{rating_map.get(rating, rating)}")
        if artist:
            tags.append(f"artist:{artist}")
        if character:
            tags.append(f"character:{character}")
        
        params = {
            "page": "api",
            "q": "index",
            "tags": " ".join(tags) if tags else "all",
            "start": (page - 1) * 100
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            if not data:
                data = []
            
            images = [self._parse_image(img) for img in data[:100]]
            has_more = len(data) == 100
            
            return {
                "images": images,
                "total": len(images),
                "page": page,
                "has_more": has_more
            }
        except Exception as e:
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}
    
    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse API response"""
        tags = []
        if data.get("tags"):
            tags = [t.strip() for t in data["tags"].split(",") if t.strip()]
        
        artist = None
        character = None
        if data.get("author"):
            artist = data["author"]
        
        for tag in tags:
            if tag.startswith("character:"):
                character = tag.split(":", 1)[1]
        
        extension = data.get("file", "").split(".")[-1] if data.get("file") else None
        
        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/post/view/{data.get('id')}",
            "file_url": data.get("file", ""),
            "preview_url": data.get("preview_url", data.get("thumb", "")),
            "sample_url": data.get("preview_url", ""),
            "width": data.get("width"),
            "height": data.get("height"),
            "file_size": data.get("file_size"),
            "file_ext": extension,
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": None,
            "score": data.get("score", 0)
        }
    
    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get image details by ID"""
        params = {
            "page": "api",
            "q": "index",
            "id": image_id
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            if isinstance(data, list) and len(data) > 0:
                return self._parse_image(data[0])
        except Exception:
            pass
        return None
    
    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        """Get popular images"""
        params = {
            "page": "api",
            "q": "index",
            "tags": "order:score",
            "start": 0
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            images = [self._parse_image(img) for img in data[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        """Get random images"""
        params = {
            "page": "api",
            "q": "index",
            "tags": "order:random",
            "start": 0
        }
        
        try:
            data = await self.fetch_json(self.api_url, params)
            images = [self._parse_image(img) for img in data[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}
    
    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions"""
        params = {
            "page": "tags",
            "q": "list",
            "s": partial
        }
        
        try:
            html = await self.fetch_html(f"{self.base_url}/index.php", params)
            # Parse HTML for tag suggestions
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'lxml')
            suggestions = []
            
            for row in soup.select('table tr')[:10]:
                cols = row.find_all('td')
                if len(cols) >= 2:
                    tag = cols[0].get_text(strip=True)
                    if partial.lower() in tag.lower():
                        suggestions.append({
                            "tag": tag,
                            "count": int(cols[1].get_text(strip=True)) if cols[1].get_text(strip=True).isdigit() else 0,
                            "type": "general"
                        })
            
            return suggestions
        except Exception:
            return []