"""
Rule34.paheal.net scraper - Shimmie-based, optimized for quality
"""
from typing import Dict, List, Any, Optional
import re
from app.scrapers.base import BaseScraper


class Rule34PahealScraper(BaseScraper):
    """Rule34.paheal.net (Shimmie-based) scraper"""

    name = "rule34paheal"
    base_url = "https://rule34.paheal.net"

    def get_headers(self) -> Dict[str, str]:
        headers = super().get_headers()
        headers["Referer"] = self.base_url
        return headers

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Rule34.paheal.net"""
        tags = query or ""
        if rating:
            tags = f"{tags} rating:{rating}" if tags else f"rating:{rating}"
        if artist:
            tags = f"{tags} artist:{artist}" if tags else f"artist:{artist}"
        if character:
            tags = f"{tags} character:{character}" if tags else f"character:{character}"

        # Shimmie search URL
        encoded = tags.replace(" ", "%20")
        url = f"{self.base_url}/post/list/{encoded}/{page}"

        try:
            html = await self.fetch_html(url)
            return self._parse_search(html, page)
        except Exception as e:
            print(f"Paheal error: {e}")
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}

    def _parse_search(self, html: str, page: int) -> Dict[str, Any]:
        """Parse Shimmie-style search results"""
        from bs4 import BeautifulSoup

        try:
            soup = BeautifulSoup(html, "html.parser")
        except Exception:
            return {"images": [], "total": 0, "page": page, "has_more": False}

        images = []

        # Shimmie uses div.thumb or div.shm-thumb
        thumbs = soup.find_all("span", class_="thumb") or soup.find_all("div", class_="shm-thumb")
        if not thumbs:
            thumbs = soup.find_all("a", href=re.compile(r"/post/view/\d+"))

        seen_ids = set()

        for elem in thumbs:
            try:
                link = elem if elem.name == "a" else elem.find("a")
                img = elem.find("img") if elem.name != "a" else elem

                if not link:
                    continue

                href = link.get("href", "")
                pid = ""
                m = re.search(r"/post/view/(\d+)", href)
                if m:
                    pid = m.group(1)
                if not pid:
                    continue
                if pid in seen_ids:
                    continue
                seen_ids.add(pid)

                # Preview URL
                preview_url = ""
                if img and img.name == "img":
                    preview_url = img.get("src", "")
                if preview_url and preview_url.startswith("/"):
                    preview_url = self.base_url + preview_url

                # Get full image URL - Shimmie pattern: /images/{hash}/{id}.{ext}
                # Build full image URL from known patterns
                file_url = preview_url
                if preview_url:
                    # /thumb/{...}  ->  /image/{...}
                    file_url = preview_url.replace("/thumbs/", "/images/").replace("/thumb/", "/images/")

                # Tags from title attribute
                tags_text = (img.get("title", "") if img and img.name == "img" else "")
                tags_list = [t.strip() for t in tags_text.split() if t.strip()] if tags_text else []

                artist = None
                character = None
                rating_val = None
                for tag in tags_list:
                    if tag.startswith("artist:"):
                        artist = tag.split(":", 1)[1]
                    elif tag.startswith("character:"):
                        character = tag.split(":", 1)[1]
                    elif tag.startswith("rating:"):
                        rating_val = tag.split(":", 1)[1]

                images.append({
                    "source_site": self.name,
                    "source_id": pid,
                    "source_url": f"{self.base_url}/post/view/{pid}",
                    "file_url": file_url,
                    "preview_url": preview_url or file_url,
                    "sample_url": file_url,
                    "file_ext": file_url.split(".")[-1].split("?")[0] if file_url else "jpg",
                    "tags": tags_list,
                    "artist": artist,
                    "character": character,
                    "rating": rating_val,
                    "score": 0,
                    "width": None,
                    "height": None,
                })
            except Exception:
                continue

        has_more = len(images) >= 20
        return {"images": images, "total": len(images), "page": page, "has_more": has_more}

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get full image page for download URL"""
        url = f"{self.base_url}/post/view/{image_id}"
        try:
            html = await self.fetch_html(url)
        except Exception:
            return None

        from bs4 import BeautifulSoup
        try:
            soup = BeautifulSoup(html, "html.parser")
        except Exception:
            return None

        # Find the main image
        main_img = soup.find("img", id="main_image") or soup.find("img", class_="shm-main-image")
        if not main_img:
            return None

        src = main_img.get("src", "")
        if src.startswith("/"):
            src = self.base_url + src

        # Tags
        tags_container = soup.find("div", class_="tag_list") or soup.find("div", id="tag_editor")
        tags = []
        if tags_container:
            tag_links = tags_container.find_all("a")
            tags = [t.get_text(strip=True) for t in tag_links if t.get_text(strip=True)]

        return {
            "source_site": self.name,
            "source_id": image_id,
            "source_url": url,
            "file_url": src,
            "preview_url": src,
            "tags": tags,
        }

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        try:
            html = await self.fetch_html(f"{self.base_url}/post/list")
            return self._parse_search(html, 1)
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        try:
            html = await self.fetch_html(f"{self.base_url}/post/list/random/1")
            return self._parse_search(html, 1)
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions from paheal"""
        # Shimmie has an autocomplete API
        url = f"{self.base_url}/api/internal/autocomplete"
        params = {"s": partial}
        try:
            data = await self.fetch_json(url, params)
            suggestions = []
            if isinstance(data, list):
                for item in data[:15]:
                    if isinstance(item, dict):
                        tag = item.get("value", "") or item.get("label", "")
                        count = item.get("count") or item.get("post_count", 0)
                        if tag:
                            suggestions.append({"tag": tag, "count": count, "type": "general"})
                    elif isinstance(item, str):
                        suggestions.append({"tag": item, "count": 0, "type": "general"})
            return suggestions
        except Exception:
            pass

        # Fallback: search page for tags
        try:
            html = await self.fetch_html(f"{self.base_url}/post/list/{partial}/1")
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            tag_links = soup.find_all("a", href=re.compile(r"/post/list/"))
            seen = set()
            suggestions = []
            for link in tag_links:
                tag = link.get_text(strip=True)
                if tag and tag.lower().startswith(partial.lower()) and tag not in seen:
                    seen.add(tag)
                    suggestions.append({"tag": tag, "count": 0, "type": "general"})
            return suggestions[:15]
        except Exception:
            pass
        return []
