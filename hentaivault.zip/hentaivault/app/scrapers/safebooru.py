"""
Safebooru.org scraper - XML API with no auth required
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class SafebooruScraper(BaseScraper):
    """Safebooru.org API scraper (XML-based)"""

    name = "safebooru"
    base_url = "https://safebooru.org"
    api_url = f"{base_url}/index.php"

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search Safebooru using XML API"""
        tags = []
        if query:
            tags.append(query)
        if rating:
            tags.append(f"rating:{rating}")
        if artist:
            tags.append(artist)
        if character:
            tags.append(character)

        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": " ".join(tags) if tags else "",
            "pid": (page - 1) * 100,
            "limit": 100,
        }

        try:
            import xml.etree.ElementTree as ET
            response = await self.fetch(self.api_url, params)
            text = response.text

            root = ET.fromstring(text)
            posts = root.findall("post")

            if not posts:
                return {"images": [], "total": 0, "page": page, "has_more": False}

            images = [self._parse_image(post) for post in posts]
            has_more = len(images) == 100
            return {"images": images, "total": len(images), "page": page, "has_more": has_more}
        except Exception as e:
            print(f"Safebooru error: {e}")
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}

    def _parse_image(self, post) -> Dict[str, Any]:
        """Parse XML post element"""
        tags_str = post.get("tags", "")
        tags = [t.strip() for t in tags_str.split() if t.strip()] if tags_str else []

        artist = None
        character = None
        for tag in tags:
            if tag.startswith("artist:"):
                artist = tag.split(":", 1)[1]
            elif tag.startswith("character:"):
                character = tag.split(":", 1)[1]

        # Safebooru serves full images directly
        directory = post.get("directory", "")
        image_name = post.get("image", "")
        post_id = post.get("id", "")

        # Build URLs
        # Full: https://safebooru.org/images/{dir}/{image}
        # Sample: https://safebooru.org/samples/{dir}/sample_{image}
        # Preview: https://safebooru.org/thumbnails/{dir}/thumbnail_{image}

        file_url = ""
        preview_url = ""
        sample_url = ""

        if directory and image_name:
            file_url = f"{self.base_url}/images/{directory}/{image_name}"
            sample_url = f"{self.base_url}/samples/{directory}/sample_{image_name}"
            preview_url = f"{self.base_url}/thumbnails/{directory}/thumbnail_{image_name}"

        # Alternative: use direct URL from API if available
        if not file_url:
            file_url = post.get("file_url", "") or post.get("image_url", "")
        if not preview_url:
            preview_url = post.get("preview_url", "")

        # Best quality
        best_url = file_url or sample_url or preview_url

        return {
            "source_site": self.name,
            "source_id": str(post_id),
            "source_url": f"{self.base_url}/index.php?page=post&s=view&id={post_id}",
            "file_url": best_url,
            "preview_url": preview_url or best_url,
            "sample_url": sample_url or best_url,
            "width": self._parse_int(post.get("width")),
            "height": self._parse_int(post.get("height")),
            "file_size": None,
            "file_ext": image_name.split(".")[-1] if image_name else "jpg",
            "tags": tags,
            "artist": artist,
            "character": character,
            "rating": post.get("rating", "safe"),
            "score": self._parse_int(post.get("score", 0)),
        }

    @staticmethod
    def _parse_int(value) -> Optional[int]:
        try:
            return int(value) if value else None
        except (ValueError, TypeError):
            return None

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "id": image_id,
        }
        try:
            import xml.etree.ElementTree as ET
            response = await self.fetch(self.api_url, params)
            text = response.text
            root = ET.fromstring(text)
            posts = root.findall("post")
            if posts:
                return self._parse_image(posts[0])
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        # Safebooru has no popularity API - use score sort
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": "score:>=10",
            "limit": 50,
        }
        try:
            import xml.etree.ElementTree as ET
            response = await self.fetch(self.api_url, params)
            text = response.text
            root = ET.fromstring(text)
            posts = root.findall("post")
            images = [self._parse_image(p) for p in posts[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        params = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "tags": "order:random",
            "limit": min(count, 100),
        }
        try:
            import xml.etree.ElementTree as ET
            response = await self.fetch(self.api_url, params)
            text = response.text
            root = ET.fromstring(text)
            posts = root.findall("post")
            images = [self._parse_image(p) for p in posts[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Safebooru tag autocomplete"""
        params = {
            "page": "dapi",
            "s": "tag",
            "q": "index",
            "name_pattern": f"{partial}*",
            "orderby": "count",
            "order": "desc",
            "limit": 15,
        }
        try:
            response = await self.fetch(self.api_url, params)
            text = response.text

            import xml.etree.ElementTree as ET
            root = ET.fromstring(text)
            tags = root.findall("tag")
            suggestions = []
            for tag in tags[:15]:
                type_id = int(tag.get("type", 0))
                tag_type = {0: "general", 1: "artist", 3: "copyright", 4: "character"}.get(type_id, "general")
                suggestions.append({
                    "tag": tag.get("name", ""),
                    "count": int(tag.get("count", 0)),
                    "type": tag_type,
                })
            return suggestions
        except Exception:
            pass
        return []
