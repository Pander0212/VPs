"""
e926.net scraper - SFW e621 mirror
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class E926Scraper(BaseScraper):
    """e926.net API scraper (SFW e621)"""

    name = "e926"
    base_url = "https://e926.net"
    api_url = f"{base_url}/posts.json"

    def get_headers(self) -> Dict[str, str]:
        headers = super().get_headers()
        headers["User-Agent"] = "HentaiVault/3.0 (by username on e926)"
        return headers

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search e926.net"""
        tags = []
        if query:
            tags.append(query)
        if artist:
            tags.append(artist)
        if character:
            tags.append(character)
        # e926 only shows safe content, but still supports rating filter
        if rating and rating == "safe":
            tags.append("rating:safe")

        params = {
            "tags": " ".join(tags) if tags else "",
            "page": page,
            "limit": 200,
        }

        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            images = [self._parse_image(img) for img in posts]

            if not images and isinstance(data, dict) and not data.get("posts"):
                return {"images": [], "total": 0, "page": page, "has_more": False}

            has_more = len(images) == 200
            return {"images": images, "total": len(images), "page": page, "has_more": has_more}
        except Exception as e:
            print(f"e926 error: {e}")
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}

    def _parse_image(self, data: Dict) -> Dict[str, Any]:
        """Parse e926 API response - same API as e621"""

        tags_general = data.get("tags", {}).get("general", [])
        tags_species = data.get("tags", {}).get("species", [])
        tags_meta = data.get("tags", {}).get("meta", [])

        all_tags = []
        artist = None
        character = None

        artist_tags = data.get("tags", {}).get("artist", [])
        if artist_tags:
            artist = artist_tags[0]

        char_tags = data.get("tags", {}).get("character", [])
        if char_tags:
            character = char_tags[0]

        copyright_tags = data.get("tags", {}).get("copyright", [])

        all_tags.extend(tags_general)
        all_tags.extend(tags_species)
        all_tags.extend(tags_meta)
        all_tags.extend(f"artist:{a}" for a in artist_tags)
        all_tags.extend(f"character:{c}" for c in char_tags)
        all_tags.extend(f"copyright:{c}" for c in copyright_tags)

        # URL hierarchy: file_url (full) > sample_url > preview_url
        file_url = data.get("file", {}).get("url", "")
        sample_url = data.get("sample", {}).get("url", "")
        preview_url = data.get("preview", {}).get("url", "")

        best_url = file_url or sample_url or preview_url
        file_ext = data.get("file", {}).get("ext", "jpg")

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/posts/{data.get('id')}",
            "file_url": best_url,
            "preview_url": preview_url or best_url,
            "sample_url": sample_url or best_url,
            "width": data.get("file", {}).get("width"),
            "height": data.get("file", {}).get("height"),
            "file_size": data.get("file", {}).get("size"),
            "file_ext": file_ext,
            "tags": all_tags,
            "artist": artist,
            "character": character,
            "rating": "safe",
            "score": data.get("score", {}).get("total", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        url = f"{self.api_url}?tags=id:{image_id}"
        try:
            data = await self.fetch_json(url)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            if posts:
                return self._parse_image(posts[0])
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        params = {"tags": "order:score", "limit": 50}
        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            images = [self._parse_image(img) for img in posts[:50]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        params = {"tags": "order:random", "limit": count}
        try:
            data = await self.fetch_json(self.api_url, params)
            posts = data.get("posts", []) if isinstance(data, dict) else []
            images = [self._parse_image(img) for img in posts[:count]]
            return {"images": images, "total": len(images), "page": 1, "has_more": False}
        except Exception:
            return {"images": [], "total": 0, "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        url = f"{self.base_url}/tags/autocomplete.json"
        params = {"search[name_matches]": f"{partial}*", "search[order]": "count", "limit": 15}
        try:
            data = await self.fetch_json(url, params)
            suggestions = []
            if isinstance(data, list):
                for tag in data[:15]:
                    cat = tag.get("category", 0)
                    tag_type = {1: "artist", 4: "character", 3: "copyright", 5: "species"}.get(cat, "general")
                    suggestions.append({
                        "tag": tag.get("name", ""),
                        "count": tag.get("post_count", 0),
                        "type": tag_type,
                    })
            return suggestions
        except Exception:
            pass
        return []
