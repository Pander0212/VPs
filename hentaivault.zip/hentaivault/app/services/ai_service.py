"""
AI service for SillyTavern LocalImage integration
"""
import json
import httpx
import re
from typing import List, Dict, Optional
from pathlib import Path

from app.config import settings
from app.database import async_session
from app.models import Image, Setting
from app.schemas import AISettings, SillyTavernMetadata


class AIService:
    """Service for AI-powered metadata generation"""
    
    DEFAULT_SYSTEM_PROMPT = """You are an expert at creating concise, memorable names and descriptions for images used in SillyTavern's LocalImage extension.

Your task is to analyze image tags and generate:

1. A SHORT NAME (kebab-case or snake_case, 1-3 words):
   - Must be memorable and easy to type
   - Examples: bedroom_night, red_dress_outfit, enchanted_sword, forest_clearing, cozy_cafe
   - Perfect for SillyTavern syntax like ::img CharacterName bedroom_night::

2. A SHORT DESCRIPTION (1-2 sentences):
   - Briefly describe the scene, setting, or subject
   - Keep it concise but evocative
   - Example: "A cozy bedroom scene at night with soft lighting. Perfect for intimate conversations."

Rules:
- Names should be generic enough to reuse across characters but specific enough to be useful
- Avoid overly long or complex names
- Focus on the setting, mood, or key visual elements
- The name will be used with ::img syntax, so keep it simple

Respond in this exact format:
NAME: <your_kebab_case_name>
DESCRIPTION: <your description here>"""
    
    def __init__(self):
        self.settings_cache = None
    
    async def get_settings(self) -> AISettings:
        """Get AI settings from database"""
        async with async_session() as session:
            from sqlalchemy import select
            result = await session.execute(
                select(Setting).where(Setting.key == "ai_settings")
            )
            setting = result.scalar_one_or_none()
            
            if setting and setting.value:
                return AISettings(**setting.value)
            
            return AISettings(
                enabled=settings.ai_api_enabled,
                base_url=settings.ai_api_base_url or "",
                api_key=settings.ai_api_key or "",
                model=settings.ai_api_model,
                system_prompt=self.DEFAULT_SYSTEM_PROMPT
            )
    
    async def save_settings(self, ai_settings: AISettings) -> bool:
        """Save AI settings to database"""
        async with async_session() as session:
            from sqlalchemy import select
            result = await session.execute(
                select(Setting).where(Setting.key == "ai_settings")
            )
            setting = result.scalar_one_or_none()
            
            if setting:
                setting.value = ai_settings.model_dump()
            else:
                setting = Setting(
                    key="ai_settings",
                    value=ai_settings.model_dump()
                )
                session.add(setting)
            
            await session.commit()
            self.settings_cache = ai_settings
            return True
    
    async def test_connection(self, ai_settings: AISettings) -> Dict:
        """Test AI API connection"""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                headers = {
                    "Authorization": f"Bearer {ai_settings.api_key}",
                    "Content-Type": "application/json"
                }
                
                response = await client.post(
                    f"{ai_settings.base_url}/chat/completions",
                    headers=headers,
                    json={
                        "model": ai_settings.model,
                        "messages": [
                            {"role": "user", "content": "Hello"}
                        ],
                        "max_tokens": 10
                    }
                )
                
                if response.status_code == 200:
                    return {"success": True, "message": "Connection successful"}
                else:
                    return {
                        "success": False,
                        "message": f"API returned status {response.status_code}",
                        "details": response.text
                    }
                    
        except Exception as e:
            return {"success": False, "message": str(e)}
    
    async def generate_metadata(
        self,
        image_ids: List[int],
        image_urls: List[str] = None,
        use_vision: bool = False,
        tags: List[str] = None
    ) -> List[Dict]:
        """Generate SillyTavern metadata for images"""
        ai_settings = await self.get_settings()
        
        if not ai_settings.enabled or not ai_settings.api_key:
            raise ValueError("AI API not configured")
        
        results = []
        
        async with async_session() as session:
            for image_id in image_ids:
                image = await session.get(Image, image_id)
                if not image:
                    continue
                
                image_tags = image.tags or []
                if tags:
                    image_tags.extend(tags)
                
                prompt = self._build_prompt(image_tags, image.artist, image.character)
                
                metadata = await self._call_ai_api(ai_settings, prompt)
                
                if metadata:
                    image.st_name = metadata.name
                    image.st_description = metadata.description
                    await session.commit()
                    
                    await self._update_sidecar(image, metadata)
                    
                    results.append({
                        "image_id": image_id,
                        "name": metadata.name,
                        "description": metadata.description
                    })
        
        return results
    
    async def generate_metadata_batch(
        self,
        image_ids: List[int],
        use_vision: bool = False
    ) -> List[Dict]:
        """Generate metadata for multiple images in batch"""
        return await self.generate_metadata(image_ids, use_vision=use_vision)
    
    def _build_prompt(
        self,
        tags: List[str],
        artist: Optional[str] = None,
        character: Optional[str] = None
    ) -> str:
        """Build prompt for AI from image metadata"""
        parts = []
        
        if artist:
            parts.append(f"Artist: {artist}")
        if character:
            parts.append(f"Character: {character}")
        
        if tags:
            parts.append(f"Tags: {', '.join(tags[:20])}")
        
        return "\n".join(parts)
    
    async def _call_ai_api(
        self,
        ai_settings: AISettings,
        prompt: str
    ) -> Optional[SillyTavernMetadata]:
        """Call AI API to generate metadata"""
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                headers = {
                    "Authorization": f"Bearer {ai_settings.api_key}",
                    "Content-Type": "application/json"
                }
                
                system_prompt = ai_settings.system_prompt or self.DEFAULT_SYSTEM_PROMPT
                
                response = await client.post(
                    f"{ai_settings.base_url}/chat/completions",
                    headers=headers,
                    json={
                        "model": ai_settings.model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": 0.7,
                        "max_tokens": 200
                    }
                )
                
                if response.status_code == 200:
                    data = response.json()
                    content = data["choices"][0]["message"]["content"]
                    return self._parse_response(content)
                else:
                    print(f"AI API error: {response.status_code} - {response.text}")
                    return None
                    
        except Exception as e:
            print(f"AI API call error: {e}")
            return None
    
    def _parse_response(self, content: str) -> Optional[SillyTavernMetadata]:
        """Parse AI response into metadata"""
        try:
            name = None
            description = None
            
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('NAME:'):
                    name = line.replace('NAME:', '').strip()
                elif line.startswith('DESCRIPTION:'):
                    description = line.replace('DESCRIPTION:', '').strip()
            
            if name and description:
                name = re.sub(r'[^\w\s-]', '', name)
                name = re.sub(r'[-\s]+', '_', name).lower()
                name = name[:50]
                
                return SillyTavernMetadata(name=name, description=description)
            
            return None
            
        except Exception as e:
            print(f"Parse error: {e}")
            return None
    
    async def _update_sidecar(self, image: Image, metadata: SillyTavernMetadata):
        """Update JSON sidecar file with SillyTavern metadata"""
        try:
            if not image.local_path:
                return
            
            file_path = Path(image.local_path)
            sidecar_path = file_path.with_suffix('.json')
            
            existing = {}
            if sidecar_path.exists():
                with open(sidecar_path, 'r') as f:
                    existing = json.load(f)
            
            existing['sillytavern'] = {
                'name': metadata.name,
                'description': metadata.description
            }
            
            with open(sidecar_path, 'w') as f:
                json.dump(existing, f, indent=2)
                
        except Exception as e:
            print(f"Sidecar update error: {e}")