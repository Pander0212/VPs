"""
AI service for SillyTavern LocalImage integration
"""
import json
import base64
import httpx
import re
from typing import List, Dict, Optional
from pathlib import Path

from app.config import settings
from app.database import async_session
from app.models import Image, Setting
from app.schemas import AISettings, SillyTavernMetadata, VisionNamingRequest, VisionNamingResponse


class AIService:
    """Service for AI-powered metadata generation"""
    
    DEFAULT_SYSTEM_PROMPT = """You are an expert at creating SillyTavern LocalImage names. LocalImage lets users display images in chat using ::img CharacterName imagename:: syntax.

Generate a SHORT, MEMORABLE name and brief description:

1. NAME (snake_case, 1-3 words, max 30 chars):
   - Focus on: setting, outfit, pose, mood, or action
   - Examples: bedroom_night, red_dress, battle_stance, shy_smile, hot_spring, school_rooftop, armor, swimsuit, cooking, sleeping
   - Keep it simple and easy to type!

2. DESCRIPTION (1 short sentence):
   - Briefly describe what the image shows
   - Example: "Character relaxing in a hot spring at night"

Rules:
- NO character names in the NAME
- Prioritize scene/setting/outfit over character identity
- Names should work across different characters

Respond EXACTLY in this format:
NAME: your_name_here
DESCRIPTION: Your description here"""
    
    DEFAULT_VISION_SYSTEM_PROMPT = """You are an expert at creating SillyTavern LocalImage names by analyzing actual images.

You will see an image. Generate a short, memorable name based on what you ACTUALLY see:

1. NAME (snake_case, 1-3 words, max 30 chars):
   - Focus on the most distinctive visual element
   - Setting: bedroom_night, beach_sunset, school_hallway, forest_clearing
   - Outfit: red_dress, armor, swimsuit, casual_outfit, lingerie
   - Pose/Action: sitting_window, battle_stance, cooking, sleeping, waving
   - Mood: shy_blush, angry_glare, happy_smile, surprised
   - Combine: beach_bikini, bedroom_lingerie, rain_umbrella

2. DESCRIPTION (1 short sentence):
   - Describe what you actually see

Rules:
- Look at the ACTUAL image content
- NO character names in the NAME
- Prioritize scene/outfit/pose over character identity
- Keep names simple and easy to type

Respond EXACTLY in this format:
NAME: your_name_here
DESCRIPTION: Your description here"""

    def __init__(self):
        self.settings_cache = None
    
    async def get_settings(self) -> AISettings:
        """Get AI settings from database"""
        async with async_session() as session:
            from sqlalchemy import select
            result = await session.execute(
                select(Setting).where(Setting.key == "ai_settings")
            )
            setting = result.scalar_one_or_none()
            
            if setting and setting.value:
                return AISettings(**setting.value)
            
            return AISettings(
                enabled=settings.ai_api_enabled,
                base_url=settings.ai_api_base_url or "",
                api_key=settings.ai_api_key or "",
                model=settings.ai_api_model,
                system_prompt=self.DEFAULT_SYSTEM_PROMPT
            )
    
    async def save_settings(self, ai_settings: AISettings) -> bool:
        """Save AI settings to database"""
        async with async_session() as session:
            from sqlalchemy import select
            result = await session.execute(
                select(Setting).where(Setting.key == "ai_settings")
            )
            setting = result.scalar_one_or_none()
            
            if setting:
                setting.value = ai_settings.model_dump()
            else:
                setting = Setting(
                    key="ai_settings",
                    value=ai_settings.model_dump()
                )
                session.add(setting)
            
            await session.commit()
            self.settings_cache = ai_settings
            return True
    
    async def test_connection(self, ai_settings: AISettings) -> Dict:
        """Test AI API connection"""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                headers = {
                    "Authorization": f"Bearer {ai_settings.api_key}",
                    "Content-Type": "application/json"
                }
                
                response = await client.post(
                    f"{ai_settings.base_url}/chat/completions",
                    headers=headers,
                    json={
                        "model": ai_settings.model,
                        "messages": [
                            {"role": "user", "content": "Hello"}
                        ],
                        "max_tokens": 10
                    }
                )
                
                if response.status_code == 200:
                    return {"success": True, "message": "Connection successful"}
                else:
                    return {
                        "success": False,
                        "message": f"API returned status {response.status_code}",
                        "details": response.text
                    }
                    
        except Exception as e:
            return {"success": False, "message": str(e)}
    
    async def generate_metadata(
        self,
        image_ids: List[int] = None,
        image_urls: List[str] = None,
        use_vision: bool = False,
        tags: List[str] = None
    ) -> List[Dict]:
        """Generate SillyTavern metadata for images"""
        ai_settings = await self.get_settings()
        
        if not ai_settings.enabled:
            raise ValueError("AI API not enabled. Please enable AI in Settings.")
        
        if not ai_settings.api_key:
            raise ValueError("AI API key not configured. Please set your API key in Settings.")
        
        if not ai_settings.base_url:
            raise ValueError("AI API base URL not configured. Please set the base URL in Settings.")
        
        results = []
        
        # Handle direct tag-based generation (for images not in database)
        if tags and not image_ids:
            # Filter out empty tags
            tags = [t for t in tags if t and t.strip()]
            if not tags:
                raise ValueError("No valid tags provided for name generation.")
            
            prompt = self._build_prompt(tags)
            metadata = await self._call_ai_api(ai_settings, prompt)
            
            if metadata:
                results.append({
                    "name": metadata.name,
                    "description": metadata.description
                })
            else:
                raise ValueError("AI returned no valid response. Check your API settings and model.")
            return results
        
        # If no tags and no image_ids, fail clearly
        if not image_ids and not tags:
            raise ValueError("No tags or image IDs provided. Cannot generate name.")
        
        # Handle database images
        async with async_session() as session:
            for image_id in (image_ids or []):
                image = await session.get(Image, image_id)
                if not image:
                    continue
                
                image_tags = image.tags or []
                if tags:
                    image_tags.extend(tags)
                
                # If still no tags, use source info as fallback
                if not image_tags:
                    image_tags = [image.source_site, f"id:{image.source_id}"]
                    if image.rating:
                        image_tags.append(image.rating)
                
                prompt = self._build_prompt(image_tags, image.artist, image.character)
                
                metadata = await self._call_ai_api(ai_settings, prompt)
                
                if metadata:
                    image.st_name = metadata.name
                    image.st_description = metadata.description
                    await session.commit()
                    
                    await self._update_sidecar(image, metadata)
                    
                    results.append({
                        "image_id": image_id,
                        "name": metadata.name,
                        "description": metadata.description
                    })
        
        return results
    
    async def generate_metadata_batch(
        self,
        image_ids: List[int],
        use_vision: bool = False
    ) -> List[Dict]:
        """Generate metadata for multiple images in batch"""
        return await self.generate_metadata(image_ids, use_vision=use_vision)
    
    async def generate_name_from_image(self, image_id: int) -> Dict:
        """Generate a name for an image by analyzing the actual image content via vision model.
        
        Reads the image file, converts to base64, and sends to the AI vision model.
        """
        ai_settings = await self.get_settings()
        
        if not ai_settings.enabled or not ai_settings.api_key:
            raise ValueError("AI API not configured. Enable AI and set API key in Settings.")
        
        async with async_session() as session:
            image = await session.get(Image, image_id)
            if not image:
                raise ValueError(f"Image {image_id} not found")
            
            # Resolve the actual file path
            file_path = Path(image.local_path) if image.local_path else None
            if not file_path or not file_path.exists():
                raise ValueError(f"Image file not found on disk for image {image_id}")
            
            # Read and base64-encode the image
            with open(file_path, 'rb') as f:
                image_data = f.read()
            
            b64 = base64.b64encode(image_data).decode('utf-8')
            
            # Determine MIME type from extension
            ext = file_path.suffix.lower()
            mime_map = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
                '.bmp': 'image/bmp',
            }
            mime_type = mime_map.get(ext, 'image/jpeg')
            
            # Build vision prompt with image
            vision_url = f"data:{mime_type};base64,{b64}"
            
            # Use vision system prompt
            system_prompt = ai_settings.system_prompt or self.DEFAULT_VISION_SYSTEM_PROMPT
            
            # Build user message with image + any available tags
            user_content = [
                {
                    "type": "image_url",
                    "image_url": {"url": vision_url}
                },
                {
                    "type": "text",
                    "text": "Analyze this image and generate a short, memorable name and description."
                }
            ]
            
            # Add tag context if available
            if image.tags:
                tag_text = f"\nAvailable tags for reference: {', '.join(image.tags[:15])}"
                user_content[1]["text"] += tag_text
            
            # Call the AI API with vision content
            metadata = await self._call_ai_vision_api(ai_settings, system_prompt, user_content)
            
            if metadata:
                # Update the image in the database
                image.st_name = metadata.name
                image.st_description = metadata.description
                await session.commit()
                
                # Update sidecar
                await self._update_sidecar(image, metadata)
                
                return {
                    "image_id": image_id,
                    "name": metadata.name,
                    "description": metadata.description
                }
            
            raise ValueError("AI failed to generate a name from the image")
    
    def _build_prompt(
        self,
        tags: List[str],
        artist: Optional[str] = None,
        character: Optional[str] = None
    ) -> str:
        """Build prompt for AI from image metadata"""
        parts = []
        
        if artist:
            parts.append(f"Artist: {artist}")
        if character:
            parts.append(f"Character: {character}")
        
        if tags:
            parts.append(f"Tags: {', '.join(tags[:20])}")
        
        return "\n".join(parts)
    
    async def _call_ai_api(
        self,
        ai_settings: AISettings,
        prompt: str
    ) -> Optional[SillyTavernMetadata]:
        """Call AI API to generate metadata"""
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                headers = {
                    "Authorization": f"Bearer {ai_settings.api_key}",
                    "Content-Type": "application/json"
                }
                
                system_prompt = ai_settings.system_prompt or self.DEFAULT_SYSTEM_PROMPT
                
                response = await client.post(
                    f"{ai_settings.base_url}/chat/completions",
                    headers=headers,
                    json={
                        "model": ai_settings.model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": 0.7,
                        "max_tokens": 200
                    }
                )
                
                if response.status_code == 200:
                    data = response.json()
                    content = data["choices"][0]["message"]["content"]
                    return self._parse_response(content)
                else:
                    print(f"AI API error: {response.status_code} - {response.text}")
                    return None
                    
        except Exception as e:
            print(f"AI API call error: {e}")
            return None
    
    async def _call_ai_vision_api(
        self,
        ai_settings: AISettings,
        system_prompt: str,
        user_content: List[Dict]
    ) -> Optional[SillyTavernMetadata]:
        """Call AI API with vision content to generate metadata"""
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                headers = {
                    "Authorization": f"Bearer {ai_settings.api_key}",
                    "Content-Type": "application/json"
                }
                
                response = await client.post(
                    f"{ai_settings.base_url}/chat/completions",
                    headers=headers,
                    json={
                        "model": ai_settings.model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_content}
                        ],
                        "temperature": 0.7,
                        "max_tokens": 300
                    }
                )
                
                if response.status_code == 200:
                    data = response.json()
                    content = data["choices"][0]["message"]["content"]
                    return self._parse_response(content)
                else:
                    print(f"AI Vision API error: {response.status_code} - {response.text}")
                    return None
                    
        except Exception as e:
            print(f"AI Vision API call error: {e}")
            return None

    def _parse_response(self, content: str) -> Optional[SillyTavernMetadata]:
        """Parse AI response into metadata"""
        try:
            name = None
            description = None
            
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('NAME:'):
                    name = line.replace('NAME:', '').strip()
                elif line.startswith('DESCRIPTION:'):
                    description = line.replace('DESCRIPTION:', '').strip()
            
            if name and description:
                name = re.sub(r'[^\w\s-]', '', name)
                name = re.sub(r'[-\s]+', '_', name).lower()
                name = name[:50]
                
                return SillyTavernMetadata(name=name, description=description)
            
            return None
            
        except Exception as e:
            print(f"Parse error: {e}")
            return None
    
    async def _update_sidecar(self, image: Image, metadata: SillyTavernMetadata):
        """Update JSON sidecar file with SillyTavern metadata"""
        try:
            if not image.local_path:
                return
            
            file_path = Path(image.local_path)
            sidecar_path = file_path.with_suffix('.json')
            
            existing = {}
            if sidecar_path.exists():
                with open(sidecar_path, 'r') as f:
                    existing = json.load(f)
            
            existing['sillytavern'] = {
                'name': metadata.name,
                'description': metadata.description
            }
            
            with open(sidecar_path, 'w') as f:
                json.dump(existing, f, indent=2)
                
        except Exception as e:
            print(f"Sidecar update error: {e}")