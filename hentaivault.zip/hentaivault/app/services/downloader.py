"""
Download service for managing image downloads
"""
import os
import json
import asyncio
import aiofiles
from pathlib import Path
from datetime import datetime
from typing import List, Optional
from slugify import slugify
import httpx

from app.config import settings
from app.database import async_session
from app.models import Image, DownloadJob
from app.schemas import ImageResult


class DownloadService:
    """Service for downloading images"""
    
    def __init__(self):
        self.downloads_dir = settings.downloads_dir
        self.downloads_dir.mkdir(parents=True, exist_ok=True)
        self.semaphore = asyncio.Semaphore(settings.max_concurrent_downloads)
    
    async def queue_download(
        self,
        images: List[ImageResult],
        create_zip: bool = False
    ) -> int:
        """Queue images for download"""
        async with async_session() as session:
            # Create download job
            job = DownloadJob(
                urls=[img.file_url for img in images],
                total=len(images),
                status="pending"
            )
            session.add(job)
            await session.commit()
            job_id = job.id
        
        # Start download in background - use asyncio.create_task with proper event loop
        # This ensures the task runs independently of the request lifecycle
        loop = asyncio.get_event_loop()
        loop.create_task(self._process_download(job_id, images, create_zip))
        
        return job_id
    
    async def _process_download(
        self,
        job_id: int,
        images: List[ImageResult],
        create_zip: bool
    ):
        """Process download job"""
        try:
            async with async_session() as session:
                job = await session.get(DownloadJob, job_id)
                if not job:
                    print(f"Job {job_id} not found")
                    return
                
                job.status = "downloading"
                job.started_at = datetime.utcnow()
                await session.commit()
                await session.refresh(job)
            
            downloaded_paths = []
            
            for i, img in enumerate(images):
                try:
                    async with self.semaphore:
                        path = await self._download_image(img)
                        if path:
                            downloaded_paths.append(path)
                            
                            # Save to database
                            await self._save_image_metadata(session, img, path)
                    
                    # Update progress
                    job.progress = int((i + 1) / len(images) * 100)
                    await session.commit()
                    await session.refresh(job)
                    
                except Exception as e:
                    print(f"Error downloading {img.file_url}: {e}")
                    continue
            
            # Create ZIP if requested
            if create_zip and downloaded_paths:
                zip_path = await self._create_zip(downloaded_paths, job_id)
                job.result_path = str(zip_path)
            
            job.status = "complete"
            job.completed_at = datetime.utcnow()
            await session.commit()
            await session.refresh(job)
        except Exception as e:
            print(f"Error processing download job {job_id}: {e}")
            # Update job status to failed
            async with async_session() as session:
                job = await session.get(DownloadJob, job_id)
                if job:
                    job.status = "failed"
                    job.error_message = str(e)
                    job.completed_at = datetime.utcnow()
                    await session.commit()
    
    async def _download_image(self, image: ImageResult) -> Optional[Path]:
        """Download a single image"""
        try:
            # Generate filename
            filename = self._generate_filename(image)
            file_path = self.downloads_dir / filename
            
            # Skip if already exists
            if file_path.exists():
                print(f"File already exists: {file_path}")
                return file_path
            
            # Ensure file_url is valid
            if not image.file_url:
                print(f"No file URL for image {image.source_id}")
                return None
            
            # Download file
            print(f"Downloading {image.file_url} to {file_path}")
            async with httpx.AsyncClient(timeout=settings.request_timeout) as client:
                response = await client.get(
                    image.file_url,
                    headers={"User-Agent": settings.user_agent}
                )
                response.raise_for_status()
                
                async with aiofiles.open(file_path, 'wb') as f:
                    await f.write(response.content)
            
            print(f"Downloaded successfully: {file_path}")
            return file_path
            
        except Exception as e:
            print(f"Download error for {image.file_url}: {e}")
            return None
    
    def _generate_filename(self, image: ImageResult) -> str:
        """Generate clean filename from image metadata"""
        parts = []
        
        if image.artist:
            parts.append(slugify(image.artist)[:30])
        if image.character:
            parts.append(slugify(image.character)[:30])
        
        # Add some tags
        if image.tags:
            tag_str = "_".join([slugify(t)[:15] for t in image.tags[:3]])
            parts.append(tag_str)
        
        if image.score:
            parts.append(f"score{image.score}")
        
        if not parts:
            parts.append(f"image_{image.source_id}")
        
        filename = "_".join(parts)
        
        # Add extension
        ext = image.file_ext or "jpg"
        return f"{filename}.{ext}"
    
    async def _save_image_metadata(
        self,
        session,
        image: ImageResult,
        file_path: Path
    ):
        """Save image metadata to database"""
        db_image = Image(
            source_site=image.source_site,
            source_id=image.source_id,
            source_url=image.source_url,
            file_url=image.file_url,
            preview_url=image.preview_url,
            sample_url=image.sample_url,
            width=image.width,
            height=image.height,
            file_ext=image.file_ext,
            tags=image.tags,
            artist=image.artist,
            character=image.character,
            rating=image.rating,
            score=image.score,
            local_filename=file_path.name,
            local_path=str(file_path)
        )
        session.add(db_image)
        await session.commit()
        
        # Save JSON sidecar
        sidecar_path = file_path.with_suffix('.json')
        metadata = {
            "source_site": image.source_site,
            "source_id": image.source_id,
            "source_url": image.source_url,
            "tags": image.tags,
            "artist": image.artist,
            "character": image.character,
            "rating": image.rating,
            "score": image.score,
            "downloaded_at": datetime.utcnow().isoformat()
        }
        async with aiofiles.open(sidecar_path, 'w') as f:
            await f.write(json.dumps(metadata, indent=2))
    
    async def _create_zip(self, paths: List[Path], job_id: int) -> Path:
        """Create ZIP archive of downloaded images"""
        import zipfile
        
        zip_path = self.downloads_dir / f"batch_{job_id}.zip"
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for path in paths:
                zf.write(path, path.name)
                # Also include sidecar if exists
                sidecar = path.with_suffix('.json')
                if sidecar.exists():
                    zf.write(sidecar, sidecar.name)
        
        return zip_path
    
    async def get_status(self, job_id: int) -> Optional[dict]:
        """Get download job status"""
        async with async_session() as session:
            job = await session.get(DownloadJob, job_id)
            if job:
                return job.to_dict()
            return None
    
    async def get_active_jobs(self) -> List[dict]:
        """Get list of active download jobs"""
        from sqlalchemy import select
        
        async with async_session() as session:
            result = await session.execute(
                select(DownloadJob).where(
                    DownloadJob.status.in_(['pending', 'downloading'])
                ).order_by(DownloadJob.created_at.desc())
            )
            jobs = result.scalars().all()
            return [job.to_dict() for job in jobs]
    
    async def cancel_job(self, job_id: int) -> bool:
        """Cancel a download job"""
        async with async_session() as session:
            job = await session.get(DownloadJob, job_id)
            if job and job.status in ['pending', 'downloading']:
                job.status = 'cancelled'
                job.completed_at = datetime.utcnow()
                await session.commit()
                return True
            return False