"""
Library service for managing downloaded images
"""
from typing import List, Optional
from pathlib import Path
from sqlalchemy import select, func, and_, or_

from app.database import async_session
from app.models import Image
from app.schemas import LibraryFilter, LibraryResponse, LibraryImage
from app.config import settings


class LibraryService:
    """Service for managing local image library"""
    
    def __init__(self):
        self.downloads_dir = settings.downloads_dir
    
    async def search(self, filters: LibraryFilter) -> LibraryResponse:
        """Search local library with filters"""
        async with async_session() as session:
            query = select(Image)
            
            # Apply filters
            if filters.query:
                search_term = f"%{filters.query}%"
                # Use JSON containment for tags (PostgreSQL-style) or filter in Python
                # For SQLite, we need to handle tags differently
                query = query.where(
                    or_(
                        Image.artist.ilike(search_term),
                        Image.character.ilike(search_term),
                        Image.source_site.ilike(search_term)
                    )
                )
            
            if filters.site:
                query = query.where(Image.source_site == filters.site)
            
            if filters.artist:
                query = query.where(Image.artist.ilike(f"%{filters.artist}%"))
            
            if filters.character:
                query = query.where(Image.character.ilike(f"%{filters.character}%"))
            
            if filters.rating:
                query = query.where(Image.rating == filters.rating)
            
            if filters.has_st_metadata is not None:
                if filters.has_st_metadata:
                    query = query.where(Image.st_name.isnot(None))
                else:
                    query = query.where(Image.st_name.is_(None))
            
            # Get total count
            count_query = select(func.count()).select_from(query.subquery())
            total_result = await session.execute(count_query)
            total = total_result.scalar()
            
            # Apply pagination
            offset = (filters.page - 1) * filters.per_page
            query = query.offset(offset).limit(filters.per_page)
            query = query.order_by(Image.downloaded_at.desc())
            
            result = await session.execute(query)
            images = result.scalars().all()
            
            # Convert to response format
            library_images = []
            for img in images:
                library_images.append(LibraryImage(
                    id=img.id,
                    source_site=img.source_site,
                    source_id=img.source_id,
                    local_filename=img.local_filename or "",
                    local_url=f"/downloads/{img.local_filename}" if img.local_filename else "",
                    file_url=img.file_url,
                    preview_url=img.preview_url,
                    width=img.width,
                    height=img.height,
                    file_ext=img.file_ext or "jpg",
                    tags=img.tags or [],
                    artist=img.artist,
                    character=img.character,
                    rating=img.rating,
                    score=img.score or 0,
                    st_name=img.st_name,
                    st_description=img.st_description,
                    downloaded_at=img.downloaded_at
                ))
            
            # Check if there are more pages: current page * per_page < total
            has_more = (filters.page * filters.per_page) < total
            
            return LibraryResponse(
                images=library_images,
                total=total,
                page=filters.page,
                per_page=filters.per_page,
                has_more=has_more
            )
    
    async def get_image(self, image_id: int) -> Optional[LibraryImage]:
        """Get single image by ID"""
        async with async_session() as session:
            img = await session.get(Image, image_id)
            if not img:
                return None
            
            return LibraryImage(
                id=img.id,
                source_site=img.source_site,
                source_id=img.source_id,
                local_filename=img.local_filename or "",
                local_url=f"/downloads/{img.local_filename}" if img.local_filename else "",
                file_url=img.file_url,
                preview_url=img.preview_url,
                width=img.width,
                height=img.height,
                file_ext=img.file_ext or "jpg",
                tags=img.tags or [],
                artist=img.artist,
                character=img.character,
                rating=img.rating,
                score=img.score or 0,
                st_name=img.st_name,
                st_description=img.st_description,
                downloaded_at=img.downloaded_at
            )
    
    async def delete_image(self, image_id: int) -> bool:
        """Delete image from library"""
        async with async_session() as session:
            img = await session.get(Image, image_id)
            if not img:
                return False
            
            # Delete file if exists
            if img.local_path:
                try:
                    file_path = Path(img.local_path)
                    if file_path.exists():
                        file_path.unlink()
                    
                    # Delete sidecar
                    sidecar = file_path.with_suffix('.json')
                    if sidecar.exists():
                        sidecar.unlink()
                except Exception as e:
                    print(f"Error deleting file: {e}")
            
            await session.delete(img)
            await session.commit()
            return True
    
    async def get_stats(self) -> dict:
        """Get library statistics"""
        async with async_session() as session:
            # Total images
            total_result = await session.execute(select(func.count()).select_from(Image))
            total = total_result.scalar()
            
            # Images by site
            site_result = await session.execute(
                select(Image.source_site, func.count())
                .group_by(Image.source_site)
            )
            by_site = {row[0]: row[1] for row in site_result.all()}
            
            # Images with SillyTavern metadata
            st_result = await session.execute(
                select(func.count()).select_from(Image).where(Image.st_name.isnot(None))
            )
            with_st = st_result.scalar()
            
            return {
                "total_images": total,
                "by_site": by_site,
                "with_sillytavern_metadata": with_st
            }
    
    async def get_all_tags(self) -> List[str]:
        """Get all unique tags in library"""
        async with async_session() as session:
            result = await session.execute(select(Image.tags))
            all_tags = set()
            
            for row in result.scalars():
                if row:
                    all_tags.update(row)
            
            return sorted(list(all_tags))