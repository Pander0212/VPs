"""
Character folder routes for organizing images
"""
import os
import zipfile
import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select

from app.database import async_session
from app.models import CharacterFolder, Image, FolderImage

router = APIRouter()


class FolderCreate(BaseModel):
    name: str
    description: Optional[str] = None


class FolderUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class AddImageToFolder(BaseModel):
    image_id: int
    custom_name: Optional[str] = None


@router.get("/list")
async def list_folders():
    """List all character folders"""
    async with async_session() as session:
        result = await session.execute(
            select(CharacterFolder).order_by(CharacterFolder.name)
        )
        folders = result.scalars().all()
        return {"folders": [f.to_dict() for f in folders]}


@router.post("")
async def create_folder(folder: FolderCreate):
    """Create a new character folder"""
    async with async_session() as session:
        # Check if folder name already exists
        result = await session.execute(
            select(CharacterFolder).where(CharacterFolder.name == folder.name)
        )
        if result.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Folder with this name already exists")
        
        new_folder = CharacterFolder(
            name=folder.name,
            description=folder.description
        )
        session.add(new_folder)
        await session.commit()
        await session.refresh(new_folder)
        
        return {"success": True, "folder": new_folder.to_dict()}


@router.get("/{folder_id}")
async def get_folder(folder_id: int):
    """Get folder details with images"""
    async with async_session() as session:
        folder = await session.get(CharacterFolder, folder_id)
        if not folder:
            raise HTTPException(status_code=404, detail="Folder not found")
        
        # Get images with custom names
        result = await session.execute(
            select(Image, FolderImage.custom_name)
            .join(FolderImage, Image.id == FolderImage.image_id)
            .where(FolderImage.folder_id == folder_id)
        )
        
        images = []
        for img, custom_name in result.all():
            img_dict = img.to_dict()
            img_dict["custom_name"] = custom_name
            images.append(img_dict)
        
        return {
            "folder": folder.to_dict(),
            "images": images
        }


@router.put("/{folder_id}")
async def update_folder(folder_id: int, folder_update: FolderUpdate):
    """Update folder details"""
    async with async_session() as session:
        folder = await session.get(CharacterFolder, folder_id)
        if not folder:
            raise HTTPException(status_code=404, detail="Folder not found")
        
        if folder_update.name:
            folder.name = folder_update.name
        if folder_update.description is not None:
            folder.description = folder_update.description
        
        await session.commit()
        return {"success": True, "folder": folder.to_dict()}


@router.delete("/{folder_id}")
async def delete_folder(folder_id: int):
    """Delete a folder (images remain in library)"""
    async with async_session() as session:
        folder = await session.get(CharacterFolder, folder_id)
        if not folder:
            raise HTTPException(status_code=404, detail="Folder not found")
        
        await session.delete(folder)
        await session.commit()
        
        return {"success": True, "message": "Folder deleted"}


@router.post("/{folder_id}/images")
async def add_image_to_folder(folder_id: int, data: AddImageToFolder):
    """Add an image to a folder"""
    async with async_session() as session:
        folder = await session.get(CharacterFolder, folder_id)
        if not folder:
            raise HTTPException(status_code=404, detail="Folder not found")
        
        image = await session.get(Image, data.image_id)
        if not image:
            raise HTTPException(status_code=404, detail="Image not found")
        
        # Check if already in folder
        result = await session.execute(
            select(FolderImage).where(
                FolderImage.folder_id == folder_id,
                FolderImage.image_id == data.image_id
            )
        )
        if result.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Image already in folder")
        
        folder_image = FolderImage(
            folder_id=folder_id,
            image_id=data.image_id,
            custom_name=data.custom_name
        )
        session.add(folder_image)
        await session.commit()
        
        return {"success": True, "message": "Image added to folder"}


@router.delete("/{folder_id}/images/{image_id}")
async def remove_image_from_folder(folder_id: int, image_id: int):
    """Remove an image from a folder"""
    async with async_session() as session:
        result = await session.execute(
            select(FolderImage).where(
                FolderImage.folder_id == folder_id,
                FolderImage.image_id == image_id
            )
        )
        folder_image = result.scalar_one_or_none()
        
        if not folder_image:
            raise HTTPException(status_code=404, detail="Image not found in folder")
        
        await session.delete(folder_image)
        await session.commit()
        
        return {"success": True, "message": "Image removed from folder"}


@router.post("/{folder_id}/export")
async def export_folder(
    folder_id: int,
    use_custom_names: bool = Query(True, description="Use custom names if available"),
    use_st_names: bool = Query(True, description="Use SillyTavern names if available")
):
    """Export folder as ZIP with SillyTavern-compatible naming"""
    async with async_session() as session:
        folder = await session.get(CharacterFolder, folder_id)
        if not folder:
            raise HTTPException(status_code=404, detail="Folder not found")
        
        # Get images with custom names
        result = await session.execute(
            select(Image, FolderImage.custom_name)
            .join(FolderImage, Image.id == FolderImage.image_id)
            .where(FolderImage.folder_id == folder_id)
        )
        
        images_data = result.all()
        if not images_data:
            raise HTTPException(status_code=400, detail="Folder is empty")
        
        # Create export directory
        from app.config import settings
        export_dir = settings.downloads_dir / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        
        zip_path = export_dir / f"{folder.name}_sillytavern.zip"
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            manifest = {
                "folder_name": folder.name,
                "export_date": str(datetime.utcnow()),
                "images": []
            }
            
            for idx, (image, custom_name) in enumerate(images_data, 1):
                if not image.local_path:
                    continue
                
                img_path = Path(image.local_path)
                if not img_path.exists():
                    continue
                
                # Determine filename
                if use_custom_names and custom_name:
                    base_name = custom_name
                elif use_st_names and image.st_name:
                    base_name = image.st_name
                else:
                    base_name = f"{folder.name}_{idx:03d}"
                
                # Clean filename
                base_name = "".join(c for c in base_name if c.isalnum() or c in '_-').strip()
                if not base_name:
                    base_name = f"{folder.name}_{idx:03d}"
                
                ext = img_path.suffix
                filename = f"{base_name}{ext}"
                
                # Add image to ZIP
                zf.write(img_path, filename)
                
                # Create SillyTavern JSON sidecar
                st_metadata = {
                    "name": base_name,
                    "description": image.st_description or f"Image from {image.source_site}",
                    "source": image.source_url,
                    "tags": image.tags or []
                }
                zf.writestr(f"{base_name}.json", json.dumps(st_metadata, indent=2))
                
                manifest["images"].append({
                    "filename": filename,
                    "name": base_name,
                    "source": image.source_url
                })
            
            # Add manifest
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        
        return {
            "success": True,
            "download_url": f"/api/folders/{folder_id}/download",
            "filename": zip_path.name,
            "path": str(zip_path)
        }


@router.get("/{folder_id}/download")
async def download_export(folder_id: int):
    """Download exported ZIP file"""
    from fastapi.responses import FileResponse
    from app.config import settings
    
    async with async_session() as session:
        folder = await session.get(CharacterFolder, folder_id)
        if not folder:
            raise HTTPException(status_code=404, detail="Folder not found")
        
        export_dir = settings.downloads_dir / "exports"
        zip_path = export_dir / f"{folder.name}_sillytavern.zip"
        
        if not zip_path.exists():
            raise HTTPException(status_code=404, detail="Export not found. Please export first.")
        
        return FileResponse(
            zip_path,
            filename=f"{folder.name}_sillytavern.zip",
            media_type="application/zip"
        )

