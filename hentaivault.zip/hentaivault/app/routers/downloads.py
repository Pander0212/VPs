"""
Download router - handles image downloads with highest quality
"""
from typing import List, Optional
import os
import json
import aiofiles
import httpx
import asyncio
from pathlib import Path
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

from app.config import settings
from app.database import async_session
from app.models import Image
from app.scrapers import get_scraper, SCRAPERS, apply_auth_to_scrapers
from sqlalchemy import select

router = APIRouter()


class DownloadRequest(BaseModel):
    """Request to download one or more images"""
    images: List[dict]
    folder: Optional[str] = None  # Character/folder name
    site: Optional[str] = None


class AIRequest(BaseModel):
    """Request to generate AI filename"""
    image_id: Optional[str] = None
    local_filename: Optional[str] = None
    tags: Optional[List[str]] = None
    character: Optional[str] = None
    artist: Optional[str] = None
    base_url: str
    api_key: str
    model: str


# Active downloads tracking
active_downloads: dict = {}
download_lock = asyncio.Lock()


DOWNLOAD_DIR = Path(settings.downloads_dir)
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)


async def download_single_image(image_data: dict, scraper, folder: str = None) -> dict:
    """
    Download a single image with highest quality URL resolution.
    Priority: file_url > sample_url > preview_url
    """
    site = image_data.get("source_site", "unknown")
    source_id = image_data.get("source_id", "")

    # Resolve best URL
    # Strategy: Try to get full details first (gives highest quality), then fall back
    best_url = ""
    try:
        # Try to get detailed image info for better URL resolution
        if scraper and source_id:
            details = await scraper.get_image_details(source_id)
            if details:
                # Merge details into image_data, preserving existing fields
                for key in ("file_url", "sample_url", "preview_url", "width", "height",
                            "file_size", "file_ext", "tags", "artist", "character"):
                    if key in details and details[key]:
                        image_data[key] = details[key]
    except Exception as e:
        print(f"Could not get details for {site}/{source_id}: {e}")

    # URL priority for download
    file_url = image_data.get("file_url", "")
    sample_url = image_data.get("sample_url", "")
    # file_url from booru APIs is typically the full original
    download_url = file_url or sample_url

    if not download_url:
        print(f"No download URL for {site}/{source_id}")
        return {"success": False, "error": "No download URL available", "image": image_data}

    # Determine filename
    file_ext = image_data.get("file_ext", "")
    if not file_ext:
        file_ext = download_url.split(".")[-1].split("?")[0].lower()
        if file_ext not in ("jpg", "jpeg", "png", "gif", "webp", "bmp", "mp4", "webm"):
            file_ext = "jpg"

    filename = f"{site}_{source_id}.{file_ext}"

    # Get appropriate headers
    headers = {}
    if hasattr(scraper, "get_headers"):
        headers = scraper.get_headers()
    if not headers:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
            "Referer": getattr(scraper, "base_url", "") if scraper else "",
        }

    # Build download path
    if folder:
        safe_folder = "".join(c if c.isalnum() or c in "-_" else "_" for c in folder)[:64]
        target_dir = DOWNLOAD_DIR / safe_folder
    else:
        target_dir = DOWNLOAD_DIR

    target_dir.mkdir(parents=True, exist_ok=True)
    filepath = target_dir / filename

    try:
        # Download with retry
        max_retries = 3
        last_error = None
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
                    response = await client.get(download_url, headers=headers)
                    response.raise_for_status()
                    content = response.content

                    # Verify we got image data
                    content_type = response.headers.get("content-type", "")
                    content_length = len(content)
                    if content_length < 100:
                        last_error = f"Response too small ({content_length} bytes)"
                        continue

                    # Save image
                    async with aiofiles.open(filepath, "wb") as f:
                        await f.write(content)

                    # Save metadata sidecar
                    metadata = {
                        "source_site": site,
                        "source_id": source_id,
                        "source_url": image_data.get("source_url", ""),
                        "download_url": download_url,
                        "tags": image_data.get("tags", []),
                        "artist": image_data.get("artist"),
                        "character": image_data.get("character"),
                        "rating": image_data.get("rating"),
                        "score": image_data.get("score", 0),
                        "width": image_data.get("width"),
                        "height": image_data.get("height"),
                        "file_size": content_length,
                        "file_ext": file_ext,
                        "folder": folder,
                        "downloaded_at": datetime.now(timezone.utc).isoformat(),
                        "st_name": "",
                        "st_description": "",
                    }
                    meta_path = filepath.with_suffix(filepath.suffix + ".json")
                    async with aiofiles.open(meta_path, "w") as f:
                        await f.write(json.dumps(metadata, indent=2, ensure_ascii=False))

                    # Update database (non-critical)
                    try:
                        async with async_session() as db:
                            stmt = select(Image).where(Image.source_site == site, Image.source_id == source_id)
                            result = await db.execute(stmt)
                            existing = result.scalar_one_or_none()
                    except Exception:
                        # Non-critical - can exist without DB
                        pass

                    return {
                        "success": True,
                        "filename": str(filepath.relative_to(DOWNLOAD_DIR)),
                        "filepath": str(filepath),
                        "file_size": content_length,
                        "metadata": metadata,
                        "image": image_data,
                    }
            except httpx.HTTPStatusError as e:
                last_error = f"HTTP {e.response.status_code}"
                if e.response.status_code in (403, 401, 404, 410):
                    # Don't retry on forbidden/not found
                    break
            except httpx.RequestError as e:
                last_error = str(e)
            except httpx.TimeoutException as e:
                last_error = f"Timeout after 60s"
                # Try alternative URL on retry
                if attempt < max_retries - 1:
                    # Try sample URL next
                    if download_url == file_url and sample_url:
                        download_url = sample_url
                    else:
                        download_url = image_data.get("preview_url", download_url)
                continue

            await asyncio.sleep(1 * (attempt + 1))  # Exponential-ish backoff

        return {
            "success": False,
            "error": last_error or "Download failed",
            "image": image_data,
        }
    except Exception as e:
        print(f"Download error: {e}")
        return {
            "success": False,
            "error": str(e),
            "image": image_data,
        }


@router.post("/download")
async def download_images(request: DownloadRequest, background_tasks: BackgroundTasks):
    """Download multiple images"""
    images = request.images
    folder = request.folder
    site_id = request.site

    if not images:
        raise HTTPException(status_code=400, detail="No images to download")

    # Get scraper
    scraper = None
    if site_id and site_id in SCRAPERS:
        scraper = get_scraper(site_id)

    # Create download job
    import uuid
    job_id = str(uuid.uuid4())
    total = len(images)

    active_downloads[job_id] = {
        "status": "queued",
        "total": total,
        "completed": 0,
        "failed": 0,
        "results": [],
        "folder": folder,
    }

    # Start downloads in background
    async def do_downloads():
        try:
            active_downloads[job_id]["status"] = "downloading"

            for i, image in enumerate(images):
                result = await download_single_image(image, scraper, folder)

                async with download_lock:
                    active_downloads[job_id]["results"].append(result)
                    if result.get("success"):
                        active_downloads[job_id]["completed"] += 1
                    else:
                        active_downloads[job_id]["failed"] += 1

                # Small delay between downloads for rate limiting
                if i < total - 1:
                    await asyncio.sleep(0.5)

            active_downloads[job_id]["status"] = "completed"
        except Exception as e:
            active_downloads[job_id]["status"] = "failed"
            active_downloads[job_id]["error"] = str(e)
            print(f"Download batch error: {e}")

    background_tasks.add_task(do_downloads)

    return {
        "job_id": job_id,
        "status": "queued",
        "total": total,
        "message": f"Downloading {total} images{f' to {folder}' if folder else ''}",
    }


@router.get("/download/status/{job_id}")
async def get_download_status(job_id: str):
    """Get download job status"""
    if job_id not in active_downloads:
        raise HTTPException(status_code=404, detail="Job not found")
    return active_downloads[job_id]


@router.get("/download/jobs")
async def get_active_jobs():
    """Get all active download jobs"""
    return {"jobs": active_downloads}


@router.post("/ai/generate-name")
async def ai_generate_name(request: AIRequest):
    """Call AI API to generate a filename based on tags"""
    if not request.base_url or not request.api_key:
        raise HTTPException(status_code=400, detail="AI API not configured")

    # Build user message from tags/context
    tags_str = ", ".join(request.tags) if request.tags else "unknown"
    context_parts = []
    if request.character:
        context_parts.append(f"Character: {request.character}")
    if request.artist:
        context_parts.append(f"Artist: {request.artist}")
    if request.image_id:
        context_parts.append(f"Image ID: {request.image_id}")

    context = " | ".join(context_parts) if context_parts else tags_str

    system_prompt = """You are a SillyTavern image naming assistant. Your ONLY job is to generate a clean, memorable filename based on the given image tags and context.

RULES:
- Output ONLY the filename - no explanations, no markdown, no quotes
- Use kebab-case or snake_case format (e.g., red_evening_gown, battle-pose-armor)
- 2-5 words maximum, descriptive but concise
- Use English words only
- Focus on the most distinctive visual elements: outfit, pose, scene, expression
- If character name provided, incorporate it naturally or focus on the scene instead
- Keep it memorable and unique - not generic like "image_1"
- No numbers unless essential
- No NSFW/explicit words, keep it tasteful

Examples:
Tags: red dress, long hair, standing, night scene, detailed → crimson_gown_night
Tags: sword, armor, battle, warrior, dramatic pose → battle_sword_stance
Tags: beach, swimsuit, sunset, smile → beachfront_sunset_smile"""

    user_msg = f"Tags: {tags_str}\nContext: {context}\n\nGenerate a filename (2-5 words, kebab-case or snake_case):"

    # OpenAI-compatible API call
    try:
        base_url = request.base_url.rstrip("/")
        # Ensure the URL ends with the chat completions endpoint
        if not base_url.endswith("/chat/completions"):
            base_url = f"{base_url}/chat/completions"

        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                base_url,
                headers={
                    "Authorization": f"Bearer {request.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": request.model or "gpt-3.5-turbo",
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_msg},
                    ],
                    "temperature": 0.8,
                    "max_tokens": 30,
                    "stop": ["\n", ".", "。", "Explanation", "Filename:", "file name:"],
                },
            )

            if response.status_code == 200:
                data = response.json()
                generated_name = data["choices"][0]["message"]["content"].strip().lower()

                # Clean up the response
                generated_name = generated_name.replace(" ", "_").replace("-", "_")
                # Remove any remaining special characters
                import re
                generated_name = re.sub(r"[^a-z0-9_]", "", generated_name)[:64]

                if not generated_name:
                    generated_name = "untitled"

                # If a local filename was provided, rename the file
                rename_result = {}
                if request.local_filename:
                    result = await rename_image_file(request.local_filename, generated_name)
                    rename_result = result or {}

                return {
                    "success": True,
                    "generated_name": generated_name,
                    "tags": request.tags,
                    "rename": rename_result,
                }
            elif response.status_code == 401:
                raise HTTPException(status_code=401, detail="AI API key invalid or unauthorized")
            elif response.status_code == 404:
                raise HTTPException(status_code=404, detail="AI API endpoint not found. Check your Base URL")
            else:
                error_data = response.text[:200]
                raise HTTPException(
                    status_code=502,
                    detail=f"AI API returned {response.status_code}: {error_data}"
                )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="AI API request timed out")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Cannot connect to AI API. Check your Base URL")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI API error: {str(e)}")


async def rename_image_file(local_filename: str, new_name: str) -> dict:
    """Rename an image file and its metadata sidecar"""
    filepath = DOWNLOAD_DIR / local_filename
    if not filepath.exists():
        return {"success": False, "error": "File not found on disk"}

    # Determine new full filename (preserve extension)
    ext = filepath.suffix  # .jpg, .png etc
    new_filename = f"{new_name}{ext}"
    new_filepath = filepath.parent / new_filename

    # Don't overwrite existing files
    counter = 1
    while new_filepath.exists():
        new_filename = f"{new_name}_{counter}{ext}"
        new_filepath = filepath.parent / new_filename
        counter += 1

    try:
        # Rename main file
        filepath.rename(new_filepath)

        # Rename metadata sidecar
        meta_path = filepath.with_suffix(filepath.suffix + ".json")
        new_meta_path = new_filepath.with_suffix(new_filepath.suffix + ".json")
        if meta_path.exists():
            meta_path.rename(new_meta_path)

        return {
            "success": True,
            "old_name": str(filepath.relative_to(DOWNLOAD_DIR)),
            "new_name": str(new_filepath.relative_to(DOWNLOAD_DIR)),
            "new_path": str(new_filepath),
        }
    except Exception as e:
        return {"success": False, "error": str(e)}
