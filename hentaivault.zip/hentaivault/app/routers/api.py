"""
API routes for search and data operations
"""
from typing import List, Optional
from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel
import asyncio

from app.scrapers import get_scraper, SCRAPERS
from app.scrapers.base import BaseScraper
from app.schemas import SearchRequest, SearchResult, MultiSearchResult, TagSuggestion
import json
from pathlib import Path

router = APIRouter()


# Source configuration storage
SOURCE_CONFIG_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "source_config.json"


def load_source_configs() -> dict:
    """Load source configurations from file"""
    if SOURCE_CONFIG_FILE.exists():
        try:
            with open(SOURCE_CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {"sources": {}}


def save_source_config(config: dict) -> bool:
    """Save source configuration to file"""
    try:
        SOURCE_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(SOURCE_CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        return True
    except Exception:
        return False


class SourceConfigRequest(BaseModel):
    """Source configuration request"""
    source_id: str
    auth_type: str  # 'login' or 'apikey'
    api_key: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None


@router.get("/sources/config")
async def get_source_configs():
    """Get all source configurations"""
    return load_source_configs()


@router.post("/sources/config")
async def save_source_config_endpoint(config: SourceConfigRequest):
    """Save a source configuration"""
    configs = load_source_configs()
    
    # Store the config (but not the password - just mark as configured)
    configs["sources"][config.source_id] = {
        "enabled": True,
        "auth_type": config.auth_type,
        "api_key": config.api_key if config.api_key else "",
        "username": config.username if config.username else ""
    }
    
    if save_source_config(configs):
        return {"success": True, "message": f"Configuration saved for {config.source_id}"}
    else:
        raise HTTPException(status_code=500, detail="Failed to save configuration")


@router.get("/search")
async def search_images(
    query: Optional[str] = Query(None, min_length=1, description="Search query"),
    q: Optional[str] = Query(None, min_length=1, description="Search query (alias)"),
    sites: str = Query("rule34", description="Comma-separated list of sites"),
    page: int = Query(1, ge=1),
    rating: Optional[str] = Query(None, description="safe, questionable, explicit"),
    artist: Optional[str] = Query(None),
    character: Optional[str] = Query(None)
):
    # Accept both 'query' and 'q' parameters for backwards compatibility
    search_query = query or q or ""
    
    if not search_query:
        raise HTTPException(status_code=400, detail="Search query is required")
    
    """Search images across multiple sites"""
    site_list = [s.strip() for s in sites.split(",") if s.strip()]
    
    # Validate sites
    invalid_sites = [s for s in site_list if s not in SCRAPERS]
    if invalid_sites:
        raise HTTPException(status_code=400, detail=f"Invalid sites: {', '.join(invalid_sites)}")
    
    # Search all sites concurrently
    tasks = []
    for site_name in site_list:
        scraper = get_scraper(site_name)
        task = scraper.search(
            query=search_query,
            page=page,
            rating=rating,
            artist=artist,
            character=character
        )
        tasks.append((site_name, task))
    
    results = {}
    total_images = 0
    
    for site_name, task in tasks:
        try:
            result = await task
            results[site_name] = SearchResult(
                images=result.get("images", []),
                total=result.get("total", 0),
                page=result.get("page", page),
                has_more=result.get("has_more", False),
                site=site_name
            )
            total_images += len(result.get("images", []))
        except Exception as e:
            results[site_name] = SearchResult(
                images=[],
                total=0,
                page=page,
                has_more=False,
                site=site_name
            )
    
    return MultiSearchResult(
        results=results,
        total_images=total_images
    )


@router.get("/sites")
async def get_available_sites():
    """Get list of available sites with auth info"""
    from app.scrapers import SITE_META
    configs = load_source_configs()
    sources_cfg = configs.get("sources", {})
    
    sites = []
    for site_id in SCRAPERS.keys():
        meta = SITE_META.get(site_id, {})
        has_auth_configured = bool(sources_cfg.get(site_id))
        sites.append({
            "id": site_id,
            "name": meta.get("name", site_id.title()),
            "needs_auth": meta.get("needs_auth", False),
            "auth_type": meta.get("auth_type"),
            "quality": meta.get("quality", "Unknown"),
            "description": meta.get("description", ""),
            "auth_configured": has_auth_configured,
            "enabled": not meta.get("needs_auth", False) or has_auth_configured
        })
    
    # Group: free first, then auth-required
    free = [s for s in sites if not s["needs_auth"]]
    auth = [s for s in sites if s["needs_auth"]]
    
    return {
        "sites": sites,
        "free_sites": free,
        "auth_sites": auth
    }


@router.get("/tags/suggest")
async def suggest_tags(
    partial: str = Query(..., min_length=1),
    site: str = Query("rule34", description="Comma-separated site IDs")
):
    """Get tag autocomplete suggestions from one or more sites"""
    sites = [s.strip() for s in site.split(",") if s.strip()]
    invalid = [s for s in sites if s not in SCRAPERS]
    if invalid:
        raise HTTPException(status_code=400, detail=f"Invalid sites: {', '.join(invalid)}")
    
    # Fetch suggestions from all sites concurrently
    merged = {}  # tag_name -> {count, types set}
    
    for site_id in sites:
        try:
            scraper = get_scraper(site_id)
            suggestions = await scraper.get_tag_suggestions(partial)
            for s in suggestions:
                tag = s.get("tag", "")
                if not tag:
                    continue
                if tag in merged:
                    merged[tag]["count"] += s.get("count", 0)
                    merged[tag]["types"].add(s.get("type", "general"))
                else:
                    merged[tag] = {
                        "count": s.get("count", 0),
                        "types": {s.get("type", "general")}
                    }
        except Exception:
            pass
    
    # Convert to sorted list
    results = []
    for tag, data in merged.items():
        types = data["types"]
        primary_type = ("artist" if "artist" in types 
                        else "character" if "character" in types
                        else "copyright" if "copyright" in types
                        else "general")
        results.append({
            "tag": tag,
            "count": data["count"],
            "type": primary_type
        })
    
    results.sort(key=lambda x: x["count"], reverse=True)
    
    return {"suggestions": results[:20]}


@router.get("/popular")
async def get_popular(
    site: str = Query("rule34"),
    timeframe: str = Query("week", description="day, week, month")
):
    """Get popular images from a site"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")
    
    scraper = get_scraper(site)
    try:
        result = await scraper.get_popular(timeframe)
        return SearchResult(
            images=result.get("images", []),
            total=result.get("total", 0),
            page=1,
            has_more=False,
            site=site
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/random")
async def get_random(
    site: str = Query("rule34"),
    count: int = Query(20, ge=1, le=100)
):
    """Get random images from a site"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")
    
    scraper = get_scraper(site)
    try:
        result = await scraper.get_random(count)
        return SearchResult(
            images=result.get("images", []),
            total=result.get("total", 0),
            page=1,
            has_more=False,
            site=site
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))