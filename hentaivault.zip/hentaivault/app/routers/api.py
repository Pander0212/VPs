"""
API routes for search and data operations
"""
from typing import List, Optional
from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel
import asyncio
import json
from pathlib import Path

from app.scrapers import get_scraper, SCRAPERS, apply_auth_to_scrapers, SITE_META
from app.scrapers.base import BaseScraper
from app.schemas import SearchRequest, SearchResult, MultiSearchResult, TagSuggestion

router = APIRouter()

# Source configuration storage
SOURCE_CONFIG_FILE = (
    Path(__file__).resolve().parent.parent.parent / "data" / "source_config.json"
)


def load_source_configs() -> dict:
    """Load source configurations from file"""
    if SOURCE_CONFIG_FILE.exists():
        try:
            with open(SOURCE_CONFIG_FILE, "r") as f:
                config = json.load(f)
                # Apply auth to scrapers on load
                apply_auth_to_scrapers(config.get("sources", {}))
                return config
        except Exception:
            pass
    return {"sources": {}}


def save_source_config(config: dict) -> bool:
    """Save source configuration to file"""
    try:
        SOURCE_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(SOURCE_CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        # Apply auth after saving
        apply_auth_to_scrapers(config.get("sources", {}))
        return True
    except Exception:
        return False


# Load configs on module import
load_source_configs()


class SourceConfigRequest(BaseModel):
    """Source configuration request"""

    source_id: str
    api_key: Optional[str] = None
    user_id: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    login: Optional[str] = None
    access_token: Optional[str] = None


@router.get("/sources/config")
async def get_source_configs():
    """Get all source configurations (without exposing secrets fully)"""
    configs = load_source_configs()
    sources_cfg = configs.get("sources", {})

    # Return masked configs - show which sites have auth configured
    result = {}
    for site_id, cfg in sources_cfg.items():
        masked = {"configured": True}
        # Show which fields are configured
        if cfg.get("api_key"):
            masked["has_api_key"] = True
        if cfg.get("username") or cfg.get("login"):
            masked["has_username"] = True
        if cfg.get("password"):
            masked["has_password"] = True
        result[site_id] = masked

    return {"sources": result}


@router.post("/sources/config")
async def save_source_config_endpoint(config: SourceConfigRequest):
    """Save a source configuration"""
    configs = load_source_configs()

    # Build config dict
    cfg = {}
    if config.api_key:
        cfg["api_key"] = config.api_key
    if config.user_id:
        cfg["user_id"] = config.user_id
    if config.username:
        cfg["username"] = config.username
    if config.password:
        cfg["password"] = config.password
    if config.login:
        cfg["login"] = config.login
    if config.access_token:
        cfg["access_token"] = config.access_token

    if not cfg:
        raise HTTPException(status_code=400, detail="No configuration provided")

    configs["sources"][config.source_id] = cfg

    if save_source_config(configs):
        return {"success": True, "message": f"Configuration saved for {config.source_id}"}
    else:
        raise HTTPException(status_code=500, detail="Failed to save configuration")


@router.get("/search")
async def search_images(
    query: Optional[str] = Query(None, min_length=1, description="Search query"),
    q: Optional[str] = Query(None, min_length=1, description="Search query (alias)"),
    sites: str = Query("rule34", description="Comma-separated list of sites"),
    page: int = Query(1, ge=1),
    rating: Optional[str] = Query(None, description="safe, questionable, explicit"),
    artist: Optional[str] = Query(None),
    character: Optional[str] = Query(None),
):
    # Accept both 'query' and 'q' parameters for backwards compatibility
    search_query = query or q or ""

    if not search_query:
        raise HTTPException(status_code=400, detail="Search query is required")

    """Search images across multiple sites"""
    site_list = [s.strip() for s in sites.split(",") if s.strip()]

    # Validate sites
    invalid_sites = [s for s in site_list if s not in SCRAPERS]
    if invalid_sites:
        raise HTTPException(
            status_code=400, detail=f"Invalid sites: {', '.join(invalid_sites)}"
        )

    # Ensure auth is applied
    configs = load_source_configs()
    apply_auth_to_scrapers(configs.get("sources", {}))

    # Search all sites concurrently
    tasks = []
    for site_name in site_list:
        scraper = get_scraper(site_name)
        task = scraper.search(
            query=search_query,
            page=page,
            rating=rating,
            artist=artist,
            character=character,
        )
        tasks.append((site_name, task))

    results = {}
    total_images = 0

    for site_name, task in tasks:
        try:
            result = await task
            results[site_name] = SearchResult(
                images=result.get("images", []),
                total=result.get("total", 0),
                page=result.get("page", page),
                has_more=result.get("has_more", False),
                site=site_name,
            )
            total_images += len(result.get("images", []))
        except Exception as e:
            print(f"Search error for {site_name}: {e}")
            results[site_name] = SearchResult(
                images=[], total=0, page=page, has_more=False, site=site_name
            )

    return MultiSearchResult(results=results, total_images=total_images)


@router.get("/sites")
async def get_available_sites():
    """Get list of available sites with auth info"""
    configs = load_source_configs()
    sources_cfg = configs.get("sources", {})

    sites = []
    for site_id in SCRAPERS.keys():
        meta = SITE_META.get(site_id, {})
        has_auth_configured = bool(sources_cfg.get(site_id))
        sites.append(
            {
                "id": site_id,
                "name": meta.get("name", site_id.title()),
                "needs_auth": meta.get("needs_auth", False),
                "auth_type": meta.get("auth_type"),
                "quality": meta.get("quality", "Unknown"),
                "description": meta.get("description", ""),
                "auth_configured": has_auth_configured,
                "enabled": not meta.get("needs_auth", False) or has_auth_configured,
                "auth_fields": meta.get("auth_fields"),
                "auth_hint": meta.get("auth_hint"),
            }
        )

    # Group: free first, then auth-configurable
    free = [s for s in sites if not s["needs_auth"] and not s.get("auth_fields")]
    configurable = [s for s in sites if s.get("auth_fields") or s["needs_auth"]]

    return {"sites": sites, "free_sites": free, "auth_sites": configurable}


@router.get("/tags/suggest")
async def suggest_tags(
    partial: str = Query(..., min_length=1),
    site: str = Query("rule34", description="Comma-separated site IDs"),
):
    """Get tag autocomplete suggestions from one or more sites"""
    sites = [s.strip() for s in site.split(",") if s.strip()]
    invalid = [s for s in sites if s not in SCRAPERS]
    if invalid:
        raise HTTPException(
            status_code=400, detail=f"Invalid sites: {', '.join(invalid)}"
        )

    # Apply auth
    configs = load_source_configs()
    apply_auth_to_scrapers(configs.get("sources", {}))

    # Fetch suggestions from all sites concurrently
    merged = {}  # tag_name -> {count, types set}

    for site_id in sites:
        try:
            scraper = get_scraper(site_id)
            suggestions = await scraper.get_tag_suggestions(partial)
            for s in suggestions:
                tag = s.get("tag", "")
                if not tag:
                    continue
                if tag in merged:
                    merged[tag]["count"] += s.get("count", 0)
                    merged[tag]["types"].add(s.get("type", "general"))
                else:
                    merged[tag] = {
                        "count": s.get("count", 0),
                        "types": {s.get("type", "general")},
                    }
        except Exception as e:
            print(f"Tag suggest error for {site_id}: {e}")

    # Convert to sorted list
    results = []
    for tag, data in merged.items():
        types = data["types"]
        primary_type = (
            "artist"
            if "artist" in types
            else "character"
            if "character" in types
            else "copyright"
            if "copyright" in types
            else "general"
        )
        results.append(
            {"tag": tag, "count": data["count"], "type": primary_type}
        )

    results.sort(key=lambda x: x["count"], reverse=True)

    return {"suggestions": results[:20]}


@router.get("/popular")
async def get_popular(
    site: str = Query("rule34"), timeframe: str = Query("week", description="day, week, month")
):
    """Get popular images from a site"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")

    configs = load_source_configs()
    apply_auth_to_scrapers(configs.get("sources", {}))

    scraper = get_scraper(site)
    try:
        result = await scraper.get_popular(timeframe)
        return SearchResult(
            images=result.get("images", []),
            total=result.get("total", 0),
            page=1,
            has_more=False,
            site=site,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/random")
async def get_random(site: str = Query("rule34"), count: int = Query(20, ge=1, le=100)):
    """Get random images from a site"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")

    configs = load_source_configs()
    apply_auth_to_scrapers(configs.get("sources", {}))

    scraper = get_scraper(site)
    try:
        result = await scraper.get_random(count)
        return SearchResult(
            images=result.get("images", []),
            total=result.get("total", 0),
            page=1,
            has_more=False,
            site=site,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
