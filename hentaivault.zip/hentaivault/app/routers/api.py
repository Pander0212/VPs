"""
API routes for search and data operations
"""
from typing import List, Optional
from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel
import asyncio

from app.scrapers import get_scraper, SCRAPERS
from app.scrapers.base import BaseScraper
from app.schemas import SearchRequest, SearchResult, MultiSearchResult, TagSuggestion

router = APIRouter()


@router.get("/search")
async def search_images(
    query: str = Query(..., min_length=1),
    sites: str = Query("rule34", description="Comma-separated list of sites"),
    page: int = Query(1, ge=1),
    rating: Optional[str] = Query(None, description="safe, questionable, explicit"),
    artist: Optional[str] = Query(None),
    character: Optional[str] = Query(None)
):
    """Search images across multiple sites"""
    site_list = [s.strip() for s in sites.split(",") if s.strip()]
    
    # Validate sites
    invalid_sites = [s for s in site_list if s not in SCRAPERS]
    if invalid_sites:
        raise HTTPException(status_code=400, detail=f"Invalid sites: {', '.join(invalid_sites)}")
    
    # Search all sites concurrently
    tasks = []
    for site_name in site_list:
        scraper = get_scraper(site_name)
        task = scraper.search(
            query=query,
            page=page,
            rating=rating,
            artist=artist,
            character=character
        )
        tasks.append((site_name, task))
    
    results = {}
    total_images = 0
    
    for site_name, task in tasks:
        try:
            result = await task
            results[site_name] = SearchResult(
                images=result.get("images", []),
                total=result.get("total", 0),
                page=result.get("page", page),
                has_more=result.get("has_more", False),
                site=site_name
            )
            total_images += len(result.get("images", []))
        except Exception as e:
            results[site_name] = SearchResult(
                images=[],
                total=0,
                page=page,
                has_more=False,
                site=site_name
            )
    
    return MultiSearchResult(
        results=results,
        total_images=total_images
    )


@router.get("/sites")
async def get_available_sites():
    """Get list of available sites"""
    return {
        "sites": [
            {
                "id": name,
                "name": name.replace("rule34", "Rule34").replace("paheal", " Paheal").title(),
                "enabled": True
            }
            for name in SCRAPERS.keys()
        ]
    }


@router.get("/tags/suggest")
async def suggest_tags(
    partial: str = Query(..., min_length=1),
    site: str = Query("rule34")
):
    """Get tag autocomplete suggestions"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")
    
    scraper = get_scraper(site)
    try:
        suggestions = await scraper.get_tag_suggestions(partial)
        return {"suggestions": suggestions}
    except Exception as e:
        return {"suggestions": [], "error": str(e)}


@router.get("/popular")
async def get_popular(
    site: str = Query("rule34"),
    timeframe: str = Query("week", description="day, week, month")
):
    """Get popular images from a site"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")
    
    scraper = get_scraper(site)
    try:
        result = await scraper.get_popular(timeframe)
        return SearchResult(
            images=result.get("images", []),
            total=result.get("total", 0),
            page=1,
            has_more=False,
            site=site
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/random")
async def get_random(
    site: str = Query("rule34"),
    count: int = Query(20, ge=1, le=100)
):
    """Get random images from a site"""
    if site not in SCRAPERS:
        raise HTTPException(status_code=400, detail=f"Invalid site: {site}")
    
    scraper = get_scraper(site)
    try:
        result = await scraper.get_random(count)
        return SearchResult(
            images=result.get("images", []),
            total=result.get("total", 0),
            page=1,
            has_more=False,
            site=site
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))