"""
Library routes for local image management
"""
from typing import Optional, List
from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel

from app.services.library import LibraryService
from app.schemas import LibraryFilter, LibraryResponse

router = APIRouter()
library_service = LibraryService()


@router.get("/images")
async def get_library_images(
    query: Optional[str] = Query(None),
    site: Optional[str] = Query(None),
    artist: Optional[str] = Query(None),
    character: Optional[str] = Query(None),
    tags: Optional[str] = Query(None, description="Comma-separated tags"),
    rating: Optional[str] = Query(None),
    has_st_metadata: Optional[bool] = Query(None, description="Filter by SillyTavern metadata"),
    folder_id: Optional[int] = Query(None, description="Filter by folder ID"),
    page: int = Query(1, ge=1),
    per_page: int = Query(50, ge=1, le=200)
):
    """Get images from local library"""
    try:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
        
        filter_params = LibraryFilter(
            query=query,
            site=site,
            artist=artist,
            character=character,
            tags=tag_list,
            rating=rating,
            has_st_metadata=has_st_metadata,
            page=page,
            per_page=per_page
        )
        
        result = await library_service.search(filter_params, folder_id=folder_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/image/{image_id}")
async def get_image_details(image_id: int):
    """Get details of a specific library image"""
    try:
        image = await library_service.get_image(image_id)
        if not image:
            raise HTTPException(status_code=404, detail="Image not found")
        return image
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/image/{image_id}")
async def delete_image(image_id: int):
    """Delete an image from the library"""
    try:
        success = await library_service.delete_image(image_id)
        if not success:
            raise HTTPException(status_code=404, detail="Image not found")
        return {"message": "Image deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/stats")
async def get_library_stats():
    """Get library statistics"""
    try:
        stats = await library_service.get_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/tags")
async def get_library_tags():
    """Get all unique tags in library"""
    try:
        tags = await library_service.get_all_tags()
        return {"tags": tags}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))