"""
Web routes for HTML pages
"""
from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from pathlib import Path

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
TEMPLATE_DIR = BASE_DIR / "templates"
templates = Jinja2Templates(directory=str(TEMPLATE_DIR))


@router.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Homepage"""
    return templates.TemplateResponse("index.html", {"request": request})


@router.get("/gallery", response_class=HTMLResponse)
async def gallery(request: Request):
    """Gallery page"""
    return templates.TemplateResponse("gallery.html", {"request": request})


@router.get("/library", response_class=HTMLResponse)
async def library_page(request: Request):
    """Local library page"""
    return templates.TemplateResponse("library.html", {"request": request})


@router.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    """Settings page"""
    return templates.TemplateResponse("settings.html", {"request": request})


@router.get("/about", response_class=HTMLResponse)
async def about_page(request: Request):
    """About page"""
    return templates.TemplateResponse("about.html", {"request": request})


@router.get("/folders", response_class=HTMLResponse)
async def folders_page(request: Request):
    """Character folders page"""
    return templates.TemplateResponse("folders.html", {"request": request})