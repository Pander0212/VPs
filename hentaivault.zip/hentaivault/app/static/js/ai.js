/**
 * HentaiVault - AI Integration JavaScript
 * generateAIName, batch generate, vision naming
 */

/**
 * Generate an AI name for an image using the /api/downloads/ai/generate-name endpoint.
 *
 * Usage from Alpine:
 *   <button @click="generateAIName(imageData, localFilename)">Generate AI Name</button>
 *
 * @param {object} imageData - Image data with tags, character, artist
 * @param {string} localFilename - Relative path to the local file (optional, for renaming)
 * @returns {Promise<object>} { success, generated_name, ... }
 */
async function generateAIName(imageData, localFilename) {
  // Get AI settings from store or inline config
  let aiConfig;
  try {
    aiConfig = await fetchJSON('/api/ai/settings');
  } catch (e) {
    throw new Error('Cannot load AI settings. Please configure AI in Settings first.');
  }

  if (!aiConfig.base_url || !aiConfig.api_key) {
    throw new Error('AI API not configured. Please set Base URL and API Key in AI Settings.');
  }

  const payload = {
    tags: Array.isArray(imageData?.tags) ? imageData.tags : [],
    character: imageData?.character || null,
    artist: imageData?.artist || null,
    local_filename: localFilename || imageData?.local_filename || null,
    base_url: aiConfig.base_url,
    api_key: aiConfig.api_key,
    model: aiConfig.model || 'gpt-4o'
  };

  if (imageData?.id) {
    payload.image_id = imageData.id;
  }

  try {
    const result = await postJSON('/api/downloads/ai/generate-name', payload);
    return result;
  } catch (e) {
    throw new Error('AI name generation failed: ' + (e.message || 'Unknown error'));
  }
}

/**
 * Generate metadata for multiple image IDs via /api/ai/generate/batch
 *
 * @param {string[]} imageIds - Array of image database IDs
 * @param {Function} onProgress - Optional callback (completed, total)
 * @returns {Promise<object>} { success, results }
 */
async function generateBatchAI(imageIds, onProgress) {
  try {
    const result = await postJSON('/api/ai/generate/batch', {
      image_ids: imageIds,
      use_vision: false
    });
    if (onProgress) onProgress(imageIds.length, imageIds.length);
    return result;
  } catch (e) {
    throw new Error('Batch AI generation failed: ' + e.message);
  }
}

/**
 * Use AI vision to name a single image based on its visual content.
 * Image must already be downloaded (has a local file).
 *
 * @param {string} imageId - Database image ID
 * @returns {Promise<object>} { success, name, description }
 */
async function visionNameImage(imageId) {
  try {
    return await postJSON('/api/ai/vision-name', { image_id: imageId });
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * Batch vision naming for multiple images
 *
 * @param {string[]} imageIds
 * @param {Function} onProgress - (done, total)
 * @returns {Promise<object[]>} Array of { id, success, name, description, error }
 */
async function visionNameBatch(imageIds, onProgress) {
  const results = [];
  for (let i = 0; i < imageIds.length; i++) {
    try {
      const r = await visionNameImage(imageIds[i]);
      results.push({ id: imageIds[i], ...r });
    } catch (e) {
      results.push({ id: imageIds[i], success: false, error: e.message });
    }
    if (onProgress) onProgress(i + 1, imageIds.length);
    // Rate limit delay
    if (i < imageIds.length - 1) {
      await new Promise(r => setTimeout(r, 800));
    }
  }
  return results;
}

console.log('🤖 AI module loaded');
