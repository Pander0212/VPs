/**
 * HentaiVault - Gallery JavaScript
 * Gallery page: search results, image grid, selection, downloads
 * Uses globalMixin from app.js for shared AI modal / image modal / toast functionality.
 */

function galleryApp() {
  return {
    ...globalMixin,

    // ====== State ======
    images: [],
    selectedImages: [],
    searchQuery: '',
    selectedSite: '',
    rating: '',
    page: 1,
    perPage: 40,
    hasMore: false,
    loading: false,
    totalImages: 0,
    availableSites: [],
   舞蹈生成状态: null,

    // View mode: 'grid' | 'list'
    viewMode: 'grid',

    // ====== Init ======
    init() {
      this.loadSites();
      this.parseUrlParams();
      // Auto-load AI settings
      this.loadAISettings();
    },

    async loadSites() {
      try {
        const data = await fetchJSON('/api/sites');
        this.availableSites = data.sites || [];
      } catch (e) {
        showToast('error', 'Failed to load sites: ' + e.message);
      }
    },

    parseUrlParams() {
      const params = new URLSearchParams(window.location.search);
      this.searchQuery = params.get('q') || '';
      this.selectedSite = params.get('site') || '';
      this.rating = params.get('rating') || '';

      const type = params.get('type');
      if (type === 'popular') {
        this.loadPopular();
      } else if (type === 'random') {
        this.loadRandom();
      } else if (this.searchQuery) {
        this.search();
      }
    },

    // ====== Search ======
    async search() {
      this.loading = true;
      this.page = 1;
      this.images = [];
      this.selectedImages = [];

      try {
        const site = this.selectedSite || 'rule34';
        const url = `/api/search?query=${encodeURIComponent(this.searchQuery)}&sites=${site}&page=${this.page}&per_page=${this.perPage}&rating=${this.rating}`;
        const data = await fetchJSON(url);
        this.processResults(data);
      } catch (e) {
        showToast('error', 'Search failed: ' + e.message);
      } finally {
        this.loading = false;
      }
    },

    async loadPopular() {
      this.loading = true;
      try {
        const site = this.selectedSite || 'rule34';
        const data = await fetchJSON(`/api/popular?site=${site}&count=50`);
        this.images = data.images || [];
        this.totalImages = data.total || this.images.length;
        this.hasMore = !!data.has_more;
      } catch (e) {
        showToast('error', 'Failed to load popular: ' + e.message);
      } finally {
        this.loading = false;
      }
    },

    async loadRandom() {
      this.loading = true;
      try {
        const site = this.selectedSite || 'rule34';
        const data = await fetchJSON(`/api/random?site=${site}&count=50`);
        this.images = data.images || [];
        this.totalImages = data.total || this.images.length;
        this.hasMore = !!data.has_more;
      } catch (e) {
        showToast('error', 'Failed to load random: ' + e.message);
      } finally {
        this.loading = false;
      }
    },

    processResults(data) {
      const all = [];
      for (const [site, result] of Object.entries(data.results || {})) {
        if (result.images) {
          all.push(...result.images.map(img => ({ ...img, source_site: site })));
        }
      }
      this.images = all;
      this.totalImages = data.total_images || all.length;
      this.hasMore = Object.values(data.results || {}).some(r => r.has_more);
    },

    async loadMore() {
      if (this.loading || !this.hasMore) return;
      this.page++;
      this.loading = true;
      try {
        const site = this.selectedSite || 'rule34';
        const url = `/api/search?query=${encodeURIComponent(this.searchQuery)}&sites=${site}&page=${this.page}&per_page=${this.perPage}&rating=${this.rating}`;
        const data = await fetchJSON(url);
        const more = [];
        for (const [site, result] of Object.entries(data.results || {})) {
          if (result.images) {
            more.push(...result.images.map(img => ({ ...img, source_site: site })));
          }
        }
        this.images.push(...more);
        this.hasMore = Object.values(data.results || {}).some(r => r.has_more);
      } catch (e) {
        showToast('error', 'Failed to load more: ' + e.message);
      } finally {
        this.loading = false;
      }
    },

    // ====== Selection ======
    toggleSelection(img) {
      const idx = this.selectedImages.findIndex(i => i.source_id === img.source_id && i.source_site === img.source_site);
      if (idx > -1) {
        this.selectedImages.splice(idx, 1);
      } else {
        this.selectedImages.push(img);
      }
    },

    isSelected(img) {
      return this.selectedImages.some(i => i.source_id === img.source_id && i.source_site === img.source_site);
    },

    selectAll() {
      this.selectedImages = [...this.images];
    },

    clearSelection() {
      this.selectedImages = [];
    },

    // ====== Downloads ======
    async downloadSelected() {
      if (!this.selectedImages.length) {
        showToast('warning', 'No images selected');
        return;
      }
      try {
        const data = await postJSON('/api/downloads/download', {
          images: this.selectedImages,
          site: this.selectedSite || this.selectedImages[0]?.source_site
        });
        if (data.job_id) {
          this.downloadJobs = [...this.downloadJobs, {
            job_id: data.job_id,
            status: 'queued',
            total: data.total || this.selectedImages.length,
            completed: 0,
            failed: 0
          }];
          showToast('success', `Download started · ${data.total || this.selectedImages.length} images`);
        }
        this.clearSelection();
      } catch (e) {
        showToast('error', 'Download failed: ' + e.message);
      }
    },

    // ====== Helpers ======
    get thumbnail() {
      return (img) => img?.local_url || img?.preview_url || img?.sample_url || img?.file_url || '';
    },

    get siteBadge() {
      return (site) => {
        const s = (site || '').toLowerCase();
        if (s === 'rule34' || s === 'rule34.xxx') return 'rule34';
        if (s === 'e621') return 'e621';
        if (s === 'gelbooru') return 'gelbooru';
        return s;
      };
    },

    tagList(img) {
      return (img?.tags || []).slice(0, 6);
    },

    showRatingClass(img) {
      return img?.rating || 'unknown';
    }
  };
}
