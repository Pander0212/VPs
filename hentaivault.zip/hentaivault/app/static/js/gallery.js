/**
 * HentaiVault - Gallery Page Logic
 * Search, display, selection, and download of booru images.
 * 
 * This is the single source of truth for the gallery component.
 * Do NOT define galleryApp() elsewhere.
 */
document.addEventListener('alpine:init', () => {
  Alpine.data('galleryApp', () => ({
    // ===== State =====
    images: [],
    selectedImages: [],
    searchQuery: '',
    selectedSite: '',
    rating: '',
    page: 1,
    hasMore: false,
    loading: false,
    totalImages: 0,
    searched: false,
    searchError: null,
    availableSites: [],

    // Tag autocomplete
    tagSuggestions: [],
    showSuggestions: false,
    selectedSuggestionIndex: -1,
    loadingSuggestions: false,
    suggestionTimeout: null,

    // Image modal (using globalMixin pattern from app.js)
    modalOpen: false,
    selectedImage: null,

    // ===== Computed helpers =====
    get siteLabel() {
      if (!this.selectedSite) return '';
      const s = this.availableSites.find(x => x.id === this.selectedSite);
      return s ? ` on ${s.name}` : '';
    },

    // ===== Init =====
    init() {
      this.loadSites();
      this.parseUrlParams();

      // Listen for global toast events
      window.addEventListener('show-toast', (e) => {
        // Toast is handled by the global toast component in base.html
      });
    },

    // ===== Load sites =====
    async loadSites() {
      try {
        const data = await fetchJSON('/api/sites');
        this.availableSites = data.sites || [];
      } catch (e) {
        console.error('[Gallery] Failed to load sites:', e.message);
      }
    },

    // ===== URL params =====
    parseUrlParams() {
      const params = new URLSearchParams(window.location.search);
      this.searchQuery = params.get('q') || '';
      this.selectedSite = params.get('site') || '';
      this.rating = params.get('rating') || '';

      const type = params.get('type');
      if (type === 'popular') {
        this.loadPopular();
      } else if (type === 'random') {
        this.loadRandom();
      } else if (this.searchQuery) {
        this.search();
      }
    },

    // ===== SEARCH =====
    async search() {
      const query = this.searchQuery.trim();
      if (!query) return;

      this.loading = true;
      this.page = 1;
      this.images = [];
      this.selectedImages = [];
      this.totalImages = 0;
      this.hasMore = false;
      this.searched = false;
      this.searchError = null;

      const site = this.selectedSite || 'rule34';
      console.log(`[Gallery] Searching for "${query}" on ${site}, page 1`);

      try {
        let url = `/api/search?query=${encodeURIComponent(query)}&sites=${encodeURIComponent(site)}&page=1`;
        if (this.rating) url += `&rating=${encodeURIComponent(this.rating)}`;

        const data = await fetchJSON(url);
        console.log('[Gallery] Search response:', data);

        this.processResults(data);
        this.searched = true;

        if (this.images.length === 0) {
          console.warn('[Gallery] No images returned from API');
        } else {
          console.log(`[Gallery] Loaded ${this.images.length} images, total: ${this.totalImages}`);
        }
      } catch (e) {
        console.error('[Gallery] Search failed:', e.message);
        this.searchError = `Search failed: ${e.message}`;
        showToast('error', `Search failed: ${e.message}`);
      } finally {
        this.loading = false;
      }
    },

    // ===== Load more (infinite scroll) =====
    async loadMore() {
      if (this.loading || !this.hasMore) return;

      this.page++;
      this.loading = true;

      const query = this.searchQuery.trim();
      const site = this.selectedSite || 'rule34';

      console.log(`[Gallery] Loading page ${this.page} for "${query}" on ${site}`);

      try {
        let url = `/api/search?query=${encodeURIComponent(query)}&sites=${encodeURIComponent(site)}&page=${this.page}`;
        if (this.rating) url += `&rating=${encodeURIComponent(this.rating)}`;

        const data = await fetchJSON(url);
        const newImages = this.extractImages(data);
        this.images.push(...newImages);
        this.updateHasMore(data);
        console.log(`[Gallery] Loaded ${newImages.length} more images, total now: ${this.images.length}`);
      } catch (e) {
        console.error('[Gallery] Load more failed:', e.message);
        this.page--; // revert page increment
        showToast('error', `Failed to load more: ${e.message}`);
      } finally {
        this.loading = false;
      }
    },

    // ===== Popular / Random =====
    async loadPopular() {
      this.loading = true;
      this.searched = false;
      const site = this.selectedSite || 'rule34';
      console.log(`[Gallery] Loading popular from ${site}`);
      try {
        const data = await fetchJSON(`/api/popular?site=${site}&count=50`);
        this.images = this.extractImages(data);
        this.totalImages = data.total || this.images.length;
        this.hasMore = false;
        this.searched = true;
        console.log(`[Gallery] Loaded ${this.images.length} popular images`);
      } catch (e) {
        console.error('[Gallery] Popular failed:', e.message);
        showToast('error', `Failed to load popular: ${e.message}`);
      } finally {
        this.loading = false;
      }
    },

    async loadRandom() {
      this.loading = true;
      this.searched = false;
      const site = this.selectedSite || 'rule34';
      console.log(`[Gallery] Loading random from ${site}`);
      try {
        const data = await fetchJSON(`/api/random?site=${site}&count=50`);
        this.images = this.extractImages(data);
        this.totalImages = data.total || this.images.length;
        this.hasMore = false;
        this.searched = true;
        console.log(`[Gallery] Loaded ${this.images.length} random images`);
      } catch (e) {
        console.error('[Gallery] Random failed:', e.message);
        showToast('error', `Failed to load random: ${e.message}`);
      } finally {
        this.loading = false;
      }
    },

    // ===== Process API response =====
    processResults(data) {
      this.images = this.extractImages(data);
      this.totalImages = data.total_images || this.images.length;
      this.updateHasMore(data);
    },

    extractImages(data) {
      const all = [];

      // Multi-site format: { results: { siteName: { images: [...] } } }
      if (data.results && typeof data.results === 'object') {
        for (const [siteName, result] of Object.entries(data.results)) {
          if (result && result.images) {
            for (const img of result.images) {
              all.push({
                ...img,
                source_site: img.source_site || siteName,
              });
            }
          }
        }
      }

      // Single-site format: { images: [...], total: N }
      if (data.images && Array.isArray(data.images)) {
        all.push(...data.images);
      }

      // Deduplicate by source_id + source_site
      const seen = new Set();
      return all.filter(img => {
        const key = `${img.source_site || ''}__${img.source_id || ''}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    },

    updateHasMore(data) {
      if (data.results && typeof data.results === 'object') {
        this.hasMore = Object.values(data.results).some(r => r && r.has_more);
      } else {
        this.hasMore = !!data.has_more;
      }
    },

    // ===== Selection =====
    isSelected(img) {
      return this.selectedImages.some(
        s => s.source_id === img.source_id && s.source_site === img.source_site
      );
    },

    toggleSelection(img) {
      const idx = this.selectedImages.findIndex(
        s => s.source_id === img.source_id && s.source_site === img.source_site
      );
      if (idx > -1) {
        this.selectedImages.splice(idx, 1);
      } else {
        this.selectedImages.push(img);
      }
    },

    selectAll() {
      this.selectedImages = [...this.images];
    },

    clearSelection() {
      this.selectedImages = [];
    },

    // ===== Downloads =====
    async downloadSelected() {
      if (!this.selectedImages.length) {
        showToast('warning', 'No images selected');
        return;
      }
      try {
        const data = await postJSON('/api/downloads/download', {
          images: this.selectedImages,
          site: this.selectedSite || this.selectedImages[0]?.source_site || ''
        });
        if (data.job_id) {
          showToast('success', `Download started · ${data.total || this.selectedImages.length} images`);
        }
        this.selectedImages = [];
      } catch (e) {
        console.error('[Gallery] Download failed:', e.message);
        showToast('error', `Download failed: ${e.message}`);
      }
    },

    async quickDownload(img) {
      try {
        const data = await postJSON('/api/downloads/download', {
          images: [img],
          site: img.source_site || this.selectedSite || ''
        });
        if (data.job_id) {
          showToast('success', 'Download queued!');
        }
      } catch (e) {
        console.error('[Gallery] Quick download failed:', e.message);
        showToast('error', `Download failed: ${e.message}`);
      }
    },

    // ===== Image helpers =====
    getThumbSrc(img) {
      return img.preview_url || img.sample_url || img.file_url || '';
    },

    handleImageError(event, img) {
      const currentSrc = event.target.src;
      // Try fallback chain
      if (img.sample_url && currentSrc !== img.sample_url) {
        event.target.src = img.sample_url;
      } else if (img.file_url && currentSrc !== img.file_url) {
        event.target.src = img.file_url;
      } else {
        // Show placeholder SVG
        event.target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Crect fill='%23333' width='200' height='200'/%3E%3Ctext fill='%23666' x='100' y='100' text-anchor='middle' dominant-baseline='middle' font-size='14'%3EImage Error%3C/text%3E%3C/svg%3E";
      }
    },

    // ===== Tag autocomplete =====
    onSearchInput(event) {
      const value = event.target.value;
      const lastTag = value.split(/\s+/).pop();

      if (this.suggestionTimeout) clearTimeout(this.suggestionTimeout);

      if (!lastTag || lastTag.length < 2) {
        this.closeSuggestions();
        return;
      }

      this.suggestionTimeout = setTimeout(() => {
        this.fetchTagSuggestions(lastTag);
      }, 300);
    },

    async fetchTagSuggestions(partial) {
      if (!partial || partial.length < 2) return;

      this.loadingSuggestions = true;
      const site = this.selectedSite || 'rule34';

      try {
        const data = await fetchJSON(`/api/tags/suggest?partial=${encodeURIComponent(partial)}&site=${encodeURIComponent(site)}`);
        this.tagSuggestions = data.suggestions || [];
        this.showSuggestions = this.tagSuggestions.length > 0;
        this.selectedSuggestionIndex = -1;
      } catch (e) {
        console.warn('[Gallery] Tag suggestions failed:', e.message);
        this.tagSuggestions = [];
        this.showSuggestions = false;
      } finally {
        this.loadingSuggestions = false;
      }
    },

    onSearchKeydown(event) {
      if (!this.showSuggestions || this.tagSuggestions.length === 0) return;

      switch (event.key) {
        case 'ArrowDown':
          event.preventDefault();
          this.selectedSuggestionIndex = (this.selectedSuggestionIndex + 1) % this.tagSuggestions.length;
          break;
        case 'ArrowUp':
          event.preventDefault();
          this.selectedSuggestionIndex = this.selectedSuggestionIndex <= 0
            ? this.tagSuggestions.length - 1
            : this.selectedSuggestionIndex - 1;
          break;
        case 'Enter':
          if (this.selectedSuggestionIndex >= 0) {
            event.preventDefault();
            this.selectTag(this.tagSuggestions[this.selectedSuggestionIndex].tag);
          }
          break;
        case 'Escape':
          this.closeSuggestions();
          break;
      }
    },

    selectTag(tag) {
      const tags = this.searchQuery.trim().split(/\s+/);
      tags.pop();
      tags.push(tag);
      this.searchQuery = tags.join(' ') + ' ';
      this.closeSuggestions();
      this.$refs.searchInput.focus();
    },

    closeSuggestions() {
      this.showSuggestions = false;
      this.tagSuggestions = [];
      this.selectedSuggestionIndex = -1;
    },

    formatCount(count) {
      if (!count) return '';
      if (count >= 1000000) return (count / 1000000).toFixed(1) + 'M';
      if (count >= 1000) return (count / 1000).toFixed(1) + 'k';
      return count.toString();
    },

    // ===== Modal =====
    modalOpen: false,
    selectedImage: null,
    generatingAI: false,
    stCopied: false,

    openModal(img) {
      this.selectedImage = img;
      this.modalOpen = true;
    },

    closeModal() {
      this.modalOpen = false;
      this.selectedImage = null;
    },

    // ===== AI Name Generation =====
    async generateAIName(img) {
      if (!img || this.generatingAI) return;
      this.generatingAI = true;
      try {
        const data = await postJSON('/api/ai/generate-name', {
          image_id: img.source_id,
          tags: img.tags || [],
          source_site: img.source_site,
        });
        if (data.name) {
          img.st_name = data.name;
          img.st_description = data.description || '';
          showToast('success', `AI Name: ${data.name}`);
        }
      } catch (e) {
        console.error('[Gallery] AI name generation failed:', e.message);
        showToast('error', `AI generation failed: ${e.message}`);
      } finally {
        this.generatingAI = false;
      }
    },

    // ===== Download from modal =====
    async downloadImage(img) {
      if (!img) return;
      try {
        const data = await postJSON('/api/downloads/download', {
          images: [img],
          site: img.source_site || this.selectedSite || '',
        });
        if (data.job_id) {
          showToast('success', 'Download queued!');
        }
      } catch (e) {
        showToast('error', `Download failed: ${e.message}`);
      }
    },

    // ===== Copy SillyTavern Embed =====
    async copySTEmbed(img) {
      if (!img) return;
      const localUrl = img.local_url || img.file_url || img.sample_url || '';
      const name = img.st_name || img.source_id || 'image';
      const embedCode = `![${name}](${localUrl})`;
      try {
        await navigator.clipboard.writeText(embedCode);
        this.stCopied = true;
        setTimeout(() => { this.stCopied = false; }, 2000);
      } catch (e) {
        showToast('error', 'Failed to copy to clipboard');
      }
    },

    formatFileSize(bytes) {
      if (!bytes) return '';
      if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(1) + ' GB';
      if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB';
      if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
      return bytes + ' B';
    },
  }));
});
