/**
 * HentaiVault - Shared JavaScript Utilities
 * Toast notification system, API helpers, global Alpine store for AI settings
 */

// ====== Toast Notification System ======
window.showToast = function(type, message, duration) {
  window.dispatchEvent(new CustomEvent('show-toast', {
    detail: { type, message, duration: duration || 5000 }
  }));
};

// ====== API Helper Functions (GLOBAL) ======
window.fetchJSON = async function(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    let detail = text;
    try {
      const j = JSON.parse(text);
      detail = j.detail || j.message || text;
    } catch (_) {}
    throw new Error(detail || `HTTP ${res.status}`);
  }
  return res.json();
};

window.postJSON = async function(url, data) {
  return window.fetchJSON(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
};

window.putJSON = async function(url, data) {
  return window.fetchJSON(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
};

// ====== Formatting Utilities ======
window.formatFileSize = function(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
};

window.formatDate = function(dateString) {
  if (!dateString) return '';
  const d = new Date(dateString);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

// ====== DOM Utilities ======
window.copyToClipboard = async function(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  }
};

// ====== Alpine.js Global Initialization ======
document.addEventListener('alpine:init', () => {

  // ====== Toast handler component ======
  Alpine.data('toast', () => ({
    toasts: [],
    add(msg) {
      const id = Date.now() + Math.random();
      const colors = {
        success: 'bg-green-800/95 border-green-600/50 text-green-100',
        error:   'bg-red-800/95 border-red-600/50 text-red-100',
        warning: 'bg-yellow-800/95 border-yellow-600/50 text-yellow-100',
        info:    'bg-blue-800/95 border-blue-600/50 text-blue-100'
      };
      const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
      this.toasts.push({
        id,
        color: colors[msg.type] || colors.info,
        icon: icons[msg.type] || 'ℹ️',
        message: msg.message,
        duration: msg.duration || 5000
      });
      setTimeout(() => {
        this.toasts = this.toasts.filter(t => t.id !== id);
      }, msg.duration || 5000);
    }
  }));

  // ---- Global AI Settings Store ----
  Alpine.store('aiSettings', {
    base_url: '',
    api_key: '',
    model: 'gpt-4o',

    async load() {
      try {
        const data = await window.fetchJSON('/api/ai/settings');
        this.base_url = data.base_url || '';
        this.api_key = data.api_key || '';
        this.model = data.model || 'gpt-4o';
      } catch (e) {
        console.warn('Could not load AI settings:', e.message);
      }
    },

    async save() {
      await window.postJSON('/api/ai/settings', {
        base_url: this.base_url,
        api_key: this.api_key,
        model: this.model
      });
      window.showToast('success', 'AI settings saved');
    },

    get configured() {
      return !!(this.base_url && this.api_key);
    },

    toObject() {
      return {
        base_url: this.base_url,
        api_key: this.api_key,
        model: this.model
      };
    }
  });

});

// ====== Global Helper Mixin ======
window.globalMixin = {
  // AI Settings Modal
  aiModalOpen: false,
  aiSettings: { base_url: '', api_key: '', model: 'gpt-4o' },
  savingAI: false,
  testingAI: false,
  testResult: null,

  // Image Modal
  modalOpen: false,
  selectedImage: null,
  generatingAI: false,
  stCopied: false,

  // Download tracking
  downloadJobs: [],

  async loadAISettings() {
    try {
      const data = await window.fetchJSON('/api/ai/settings');
      this.aiSettings = {
        base_url: data.base_url || '',
        api_key: data.api_key || '',
        model: data.model || 'gpt-4o'
      };
    } catch (e) {
      console.warn('Could not load AI settings:', e.message);
    }
  },

  async saveAISettings() {
    this.savingAI = true;
    this.testResult = null;
    try {
      await window.postJSON('/api/ai/settings', this.aiSettings);
      const store = Alpine.store('aiSettings');
      store.base_url = this.aiSettings.base_url;
      store.api_key = this.aiSettings.api_key;
      store.model = this.aiSettings.model;
      this.aiModalOpen = false;
      window.showToast('success', 'AI settings saved');
    } catch (e) {
      window.showToast('error', 'Failed to save: ' + e.message);
    } finally {
      this.savingAI = false;
    }
  },

  async testAIConnection() {
    this.testingAI = true;
    this.testResult = null;
    try {
      const data = await window.postJSON('/api/ai/test', this.aiSettings);
      this.testResult = {
        success: data.success !== false,
        message: data.message || data.detail || (data.success !== false ? 'Connected!' : 'Failed')
      };
      if (this.testResult.success) {
        window.showToast('success', 'AI connection test passed');
      }
    } catch (e) {
      this.testResult = { success: false, message: e.message || 'Connection failed' };
      window.showToast('error', 'Connection test failed: ' + e.message);
    } finally {
      this.testingAI = false;
    }
  },

  openModal(image) {
    this.selectedImage = image;
    this.modalOpen = true;
  },

  async downloadImage(img) {
    try {
      const data = await window.postJSON('/api/downloads/download', {
        images: [img],
        site: img?.source_site || img?.site
      });
      if (data.job_id) {
        this.downloadJobs = [...this.downloadJobs.filter(j => j.job_id !== data.job_id), {
          job_id: data.job_id,
          status: 'queued',
          total: data.total || 1,
          completed: 0,
          failed: 0
        }];
        window.showToast('success', `Download queued (${data.total || 1} image${data.total === 1 ? '' : 's'})`);
      }
    } catch (e) {
      window.showToast('error', 'Download failed: ' + e.message);
    }
  },

  async generateAIName(img) {
    if (!img) return;
    this.generatingAI = true;

    if (!this.aiSettings.base_url || !this.aiSettings.api_key) {
      await this.loadAISettings();
      if (!this.aiSettings.base_url || !this.aiSettings.api_key) {
        this.generatingAI = false;
        this.aiModalOpen = true;
        window.showToast('warning', 'Please configure AI settings first');
        return;
      }
    }

    try {
      const payload = {
        tags: img?.tags || [],
        character: img?.character || null,
        artist: img?.artist || null,
        local_filename: img?.local_filename || img?.local_url || null,
        base_url: this.aiSettings.base_url,
        api_key: this.aiSettings.api_key,
        model: this.aiSettings.model
      };
      if (img?.id) payload.image_id = img.id;

      const data = await window.postJSON('/api/downloads/ai/generate-name', payload);
      if (data.success && data.generated_name) {
        img.st_name = data.generated_name;
        if (this.selectedImage === img) {
          this.selectedImage = { ...img, st_name: data.generated_name };
        }
        window.showToast('success', 'AI Name: ' + data.generated_name);
      } else {
        window.showToast('error', 'Failed to generate name');
      }
    } catch (e) {
      window.showToast('error', 'AI generation failed: ' + e.message);
    } finally {
      this.generatingAI = false;
    }
  },

  async copySTEmbed(img) {
    const name = img?.st_name || img?.source_id || 'image';
    const code = `::img ${name}::`;
    const ok = await window.copyToClipboard(code);
    if (ok) {
      window.showToast('success', 'SillyTavern embed code copied!');
    } else {
      prompt('Copy this code:', code);
    }
  }
};

// ====== Keyboard Shortcuts ======
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('[x-data]').forEach(el => {
      const stack = el._x_dataStack;
      if (stack && stack.length) {
        const data = stack[0];
        if (data.modalOpen) data.modalOpen = false;
        if (data.aiModalOpen) data.aiModalOpen = false;
      }
    });
  }

  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    const input = document.querySelector('input[type="text"][placeholder*="earch"], input[type="search"], input[name="q"]');
    if (input) input.focus();
  }
});

console.log('🎨 HentaiVault · v1.1');
