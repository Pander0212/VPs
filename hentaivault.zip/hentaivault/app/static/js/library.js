// Library-specific JavaScript

function libraryApp() {
    return {
        images: [],
        selectedImages: [],
        filters: {
            query: '',
            site: '',
            rating: '',
            has_st_metadata: ''
        },
        page: 1,
        perPage: 50,
        hasMore: false,
        loading: false,
        stats: {},
        modalOpen: false,
        selectedImage: null,
        
        init() {
            this.loadStats();
            this.search();
        },
        
        async loadStats() {
            try {
                const response = await fetch('/api/library/stats');
                this.stats = await response.json();
            } catch (error) {
                console.error('Failed to load stats:', error);
            }
        },
        
        async search() {
            this.loading = true;
            this.page = 1;
            
            try {
                const params = new URLSearchParams({
                    page: this.page,
                    per_page: this.perPage,
                    query: this.filters.query,
                    site: this.filters.site,
                    rating: this.filters.rating,
                    has_st_metadata: this.filters.has_st_metadata
                });
                
                const response = await fetch(`/api/library/images?${params.toString()}`);
                const data = await response.json();
                
                this.images = data.images || [];
                this.hasMore = data.has_more;
            } catch (error) {
                console.error('Search failed:', error);
            } finally {
                this.loading = false;
            }
        },
        
        async loadMore() {
            this.page++;
            this.loading = true;
            
            try {
                const params = new URLSearchParams({
                    page: this.page,
                    per_page: this.perPage,
                    query: this.filters.query,
                    site: this.filters.site,
                    rating: this.filters.rating
                });
                
                const response = await fetch(`/api/library/images?${params.toString()}`);
                const data = await response.json();
                
                this.images.push(...(data.images || []));
                this.hasMore = data.has_more;
            } catch (error) {
                console.error('Failed to load more:', error);
            } finally {
                this.loading = false;
            }
        },
        
        toggleSelection(img) {
            const index = this.selectedImages.indexOf(img);
            if (index > -1) {
                this.selectedImages.splice(index, 1);
            } else {
                this.selectedImages.push(img);
            }
        },
        
        selectAll() {
            this.selectedImages = [...this.images];
        },
        
        clearSelection() {
            this.selectedImages = [];
        },
        
        openModal(img) {
            this.selectedImage = img;
            this.modalOpen = true;
        },
        
        async generateSingleST(img) {
            try {
                const response = await fetch('/api/ai/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image_ids: [img.id] })
                });
                const data = await response.json();
                
                if (data.success && data.results.length > 0) {
                    img.st_name = data.results[0].name;
                    img.st_description = data.results[0].description;
                    alert(`Generated name: ${data.results[0].name}`);
                } else {
                    alert('Failed to generate metadata: ' + (data.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Generation failed:', error);
                alert('Failed to generate metadata');
            }
        },
        
        async generateSTMetadata() {
            const ids = this.selectedImages.map(img => img.id);
            
            try {
                const response = await fetch('/api/ai/generate/batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image_ids: ids })
                });
                const data = await response.json();
                
                if (data.success) {
                    alert(`Generated metadata for ${data.results.length} images`);
                    this.search();
                } else {
                    alert('Failed: ' + (data.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Batch generation failed:', error);
                alert('Failed to generate metadata');
            }
        },
        
        async deleteImage(img) {
            if (!confirm('Are you sure you want to delete this image?')) return;
            
            try {
                const response = await fetch(`/api/library/image/${img.id}`, {
                    method: 'DELETE'
                });
                
                if (response.ok) {
                    this.images = this.images.filter(i => i.id !== img.id);
                    this.selectedImages = this.selectedImages.filter(i => i.id !== img.id);
                }
            } catch (error) {
                console.error('Delete failed:', error);
                alert('Failed to delete image');
            }
        },
        
        async deleteSelected() {
            if (!confirm(`Are you sure you want to delete ${this.selectedImages.length} images?`)) return;
            
            for (const img of this.selectedImages) {
                await this.deleteImage(img);
            }
            this.selectedImages = [];
        }
    };
}