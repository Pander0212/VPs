// Library-specific JavaScript

function libraryApp() {
    return {
        images: [],
        selectedImages: [],
        filters: {
            query: '',
            site: '',
            rating: '',
            has_st_metadata: ''
        },
        page: 1,
        perPage: 50,
        hasMore: false,
        loading: false,
        stats: {},
        modalOpen: false,
        selectedImage: null,
        generatingST: false,
        generatingVision: false,
        showAddToFolderModal: false,
        folders: [],
        selectedFolderId: '',
        customName: '',
        addingToFolder: false,
        
        init() {
            this.loadStats();
            this.search();
            this.loadFolders();
        },
        
        async loadFolders() {
            try {
                const response = await fetch('/api/folders/list');
                const data = await response.json();
                this.folders = data.folders || [];
            } catch (error) {
                console.error('Failed to load folders:', error);
            }
        },
        
        async addToFolder() {
            if (!this.selectedFolderId) return;
            
            this.addingToFolder = true;
            let added = 0;
            let failed = 0;
            
            for (const img of this.selectedImages) {
                try {
                    const response = await fetch(`/api/folders/${this.selectedFolderId}/images`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            image_id: img.id,
                            custom_name: this.customName || null
                        })
                    });
                    
                    if (response.ok) {
                        added++;
                    } else {
                        failed++;
                    }
                } catch (error) {
                    console.error('Failed to add image:', error);
                    failed++;
                }
            }
            
            this.addingToFolder = false;
            this.showAddToFolderModal = false;
            this.selectedImages = [];
            this.selectedFolderId = '';
            this.customName = '';
            
            alert(`Added ${added} images to folder${failed > 0 ? ` (${failed} failed)` : ''}`);
        },
        
        async loadStats() {
            try {
                const response = await fetch('/api/library/stats');
                this.stats = await response.json();
            } catch (error) {
                console.error('Failed to load stats:', error);
            }
        },
        
        async search() {
            this.loading = true;
            this.page = 1;
            
            try {
                const params = new URLSearchParams();
                params.set('page', this.page);
                params.set('per_page', this.perPage);
                if (this.filters.query) params.set('query', this.filters.query);
                if (this.filters.site) params.set('site', this.filters.site);
                if (this.filters.rating) params.set('rating', this.filters.rating);
                if (this.filters.has_st_metadata) params.set('has_st_metadata', this.filters.has_st_metadata);
                
                const response = await fetch(`/api/library/images?${params.toString()}`);
                const data = await response.json();
                
                this.images = data.images || [];
                this.hasMore = data.has_more;
            } catch (error) {
                console.error('Search failed:', error);
            } finally {
                this.loading = false;
            }
        },
        
        async loadMore() {
            this.page++;
            this.loading = true;
            
            try {
                const params = new URLSearchParams();
                params.set('page', this.page);
                params.set('per_page', this.perPage);
                if (this.filters.query) params.set('query', this.filters.query);
                if (this.filters.site) params.set('site', this.filters.site);
                if (this.filters.rating) params.set('rating', this.filters.rating);
                
                const response = await fetch(`/api/library/images?${params.toString()}`);
                const data = await response.json();
                
                this.images.push(...(data.images || []));
                this.hasMore = data.has_more;
            } catch (error) {
                console.error('Failed to load more:', error);
            } finally {
                this.loading = false;
            }
        },
        
        toggleSelection(img) {
            const index = this.selectedImages.indexOf(img);
            if (index > -1) {
                this.selectedImages.splice(index, 1);
            } else {
                this.selectedImages.push(img);
            }
        },
        
        selectAll() {
            this.selectedImages = [...this.images];
        },
        
        clearSelection() {
            this.selectedImages = [];
        },
        
        openModal(img) {
            this.selectedImage = img;
            this.modalOpen = true;
        },
        
        async generateSingleST(img) {
            try {
                const response = await fetch('/api/ai/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image_ids: [img.id] })
                });
                const data = await response.json();
                
                if (data.success && data.results.length > 0) {
                    img.st_name = data.results[0].name;
                    img.st_description = data.results[0].description;
                    alert(`Generated name: ${data.results[0].name}`);
                } else {
                    alert('Failed to generate metadata: ' + (data.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Generation failed:', error);
                alert('Failed to generate metadata');
            }
        },
        
        async visionNameSingle(img) {
            if (img._visionLoading) return;
            img._visionLoading = true;
            
            try {
                const result = await visionNameImage(img.id);
                
                if (result.success) {
                    img.st_name = result.name;
                    img.st_description = result.description;
                    alert(`Generated name: ${result.name}`);
                } else {
                    alert('Vision naming failed: ' + result.error);
                }
            } catch (error) {
                console.error('Vision naming failed:', error);
                alert('Vision naming failed');
            } finally {
                img._visionLoading = false;
            }
        },
        
        async generateVisionForModal(image) {
            if (!image || !image.id) {
                alert('Image must be downloaded first to use vision naming.');
                return;
            }
            this.generatingVision = true;
            
            try {
                const response = await fetch('/api/ai/vision-name', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image_id: image.id })
                });
                const data = await response.json();
                
                if (data.success && data.name) {
                    image.st_name = data.name;
                    image.st_description = data.description;
                    alert('Generated name: ' + data.name);
                } else if (data.error) {
                    alert('Vision Error: ' + data.error);
                } else {
                    alert('Could not generate name from image.');
                }
            } catch (error) {
                console.error('Vision generation failed:', error);
                alert('Failed to connect to AI. Check your AI API settings.');
            } finally {
                this.generatingVision = false;
            }
        },
        
        async generateSTForModal(image) {
            if (!image) return;
            this.generatingST = true;
            
            try {
                const response = await fetch('/api/ai/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image_ids: [image.id] })
                });
                const data = await response.json();
                
                if (data.success && data.results.length > 0) {
                    image.st_name = data.results[0].name;
                    image.st_description = data.results[0].description;
                    alert('Generated name: ' + data.results[0].name);
                } else if (data.error) {
                    alert('AI Error: ' + data.error);
                } else {
                    alert('Could not generate name. Check AI settings.');
                }
            } catch (error) {
                console.error('Generation failed:', error);
                alert('Failed to connect to AI. Check your AI API settings.');
            } finally {
                this.generatingST = false;
            }
        },
        
        async visionNameSelected() {
            if (this.selectedImages.length === 0) return;
            
            const ids = this.selectedImages.map(img => img.id);
            const total = ids.length;
            let completed = 0;
            
            if (!confirm(`Use AI vision to name ${total} selected image(s)? This may take a while.`)) return;
            
            try {
                const results = await visionNameBatch(ids, (done, total) => {
                    completed = done;
                    // Could update a progress indicator here
                });
                
                const succeeded = results.filter(r => r.success).length;
                alert(`Vision naming complete: ${succeeded}/${total} images named successfully.`);
                this.search(); // Refresh to show updated names
            } catch (error) {
                console.error('Batch vision naming failed:', error);
                alert('Batch vision naming failed');
            }
        },
        
        async generateSTMetadata() {
            const ids = this.selectedImages.map(img => img.id);
            
            try {
                const response = await fetch('/api/ai/generate/batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image_ids: ids })
                });
                const data = await response.json();
                
                if (data.success) {
                    alert(`Generated metadata for ${data.results.length} images`);
                    this.search();
                } else {
                    alert('Failed: ' + (data.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Batch generation failed:', error);
                alert('Failed to generate metadata');
            }
        },
        
        async deleteImage(img) {
            if (!confirm('Are you sure you want to delete this image?')) return;
            
            try {
                const response = await fetch(`/api/library/image/${img.id}`, {
                    method: 'DELETE'
                });
                
                if (response.ok) {
                    this.images = this.images.filter(i => i.id !== img.id);
                    this.selectedImages = this.selectedImages.filter(i => i.id !== img.id);
                }
            } catch (error) {
                console.error('Delete failed:', error);
                alert('Failed to delete image');
            }
        },
        
        async deleteSelected() {
            if (!confirm(`Are you sure you want to delete ${this.selectedImages.length} images?`)) return;
            
            for (const img of this.selectedImages) {
                await this.deleteImage(img);
            }
            this.selectedImages = [];
        }
    };
}