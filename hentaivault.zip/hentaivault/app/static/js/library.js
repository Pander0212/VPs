/**
 * HentaiVault - Library JavaScript
 * Library page: local images, search/filter, folders tree, bulk actions
 * Uses globalMixin from app.js for shared AI modal / image modal / toast functionality.
 */

function libraryApp() {
  return {
    ...globalMixin,

    // ====== State ======
    images: [],
    selectedImages: [],
    folders: [],
    stats: {},

    // Filters
    filters: {
      query: '',
      site: '',
      rating: '',
      folder: '',
      has_st_metadata: ''
    },

    // Pagination
    page: 1,
    perPage: 50,
    hasMore: false,
    loading: false,

    // Folder add modal
    showFolderModal: false,
    folderModalImages: [],
    selectedFolderId: '',
    customName: '',
    addingToFolder: false,

    // Delete confirm
    deleteConfirmOpen: false,
    deleteTarget: null,

    // ====== Init ======
    init() {
      this.loadFolders();
      this.loadStats();
      this.search();
      this.loadAISettings();
    },

    // ====== Folders ======
    async loadFolders() {
      try {
        const data = await fetchJSON('/api/folders/list');
        this.folders = data.folders || [];
      } catch (e) {
        console.warn('Could not load folders:', e.message);
      }
    },

    async loadStats() {
      try {
        this.stats = await fetchJSON('/api/library/stats');
      } catch (e) {
        console.warn('Could not load stats:', e.message);
      }
    },

    // ====== Search ======
    async search() {
      this.loading = true;
      this.page = 1;

      try {
        const params = new URLSearchParams({
          page: this.page,
          per_page: this.perPage
        });
        if (this.filters.query) params.set('query', this.filters.query);
        if (this.filters.site) params.set('site', this.filters.site);
        if (this.filters.rating) params.set('rating', this.filters.rating);
        if (this.filters.folder) params.set('folder', this.filters.folder);
        if (this.filters.has_st_metadata) params.set('has_st_metadata', this.filters.has_st_metadata);

        const data = await fetchJSON(`/api/library/images?${params}`);
        this.images = data.images || [];
        this.hasMore = !!data.has_more;
      } catch (e) {
        showToast('error', 'Failed to load library: ' + e.message);
      } finally {
        this.loading = false;
      }
    },

    async loadMore() {
      if (this.loading || !this.hasMore) return;
      this.page++;
      this.loading = true;
      try {
        const params = new URLSearchParams({
          page: this.page,
          per_page: this.perPage
        });
        if (this.filters.query) params.set('query', this.filters.query);
        if (this.filters.site) params.set('site', this.filters.site);
        if (this.filters.rating) params.set('rating', this.filters.rating);
        if (this.filters.folder) params.set('folder', this.filters.folder);

        const data = await fetchJSON(`/api/library/images?${params}`);
        this.images.push(...(data.images || []));
        this.hasMore = !!data.has_more;
      } catch (e) {
        showToast('error', 'Failed to load more: ' + e.message);
      } finally {
        this.loading = false;
      }
    },

    // Apply a filter from the folder tree
    selectFolder(folder) {
      this.filters.folder = folder || '';
      this.search();
    },

    // ====== Selection ======
    toggleSelection(img) {
      const idx = this.selectedImages.findIndex(i => i.id === img.id || (i.source_id === img.source_id && i.source_site === img.source_site));
      if (idx > -1) {
        this.selectedImages.splice(idx, 1);
      } else {
        this.selectedImages.push(img);
      }
    },

    isSelected(img) {
      return this.selectedImages.some(i => i.id === img.id || (i.source_id === img.source_id && i.source_site === img.source_site));
    },

    selectAll() {
      this.selectedImages = [...this.images];
    },

    clearSelection() {
      this.selectedImages = [];
    },

    // ====== Folder Add ======
    openFolderModal(images) {
      this.folderModalImages = images && images.length ? images : this.selectedImages.slice();
      if (!this.folderModalImages.length) {
        showToast('warning', 'No images selected');
        return;
      }
      this.selectedFolderId = '';
      this.customName = '';
      this.showFolderModal = true;
      this.loadFolders();
    },

    async addToFolder() {
      if (!this.selectedFolderId) {
        showToast('warning', 'Please select a folder');
        return;
      }
      this.addingToFolder = true;
      let added = 0, failed = 0;

      for (const img of this.folderModalImages) {
        try {
          const imageId = img.id || img.source_id;
          if (!imageId) { failed++; continue; }
          await postJSON(`/api/folders/${this.selectedFolderId}/images`, {
            image_id: imageId,
            custom_name: this.customName || null
          });
          added++;
        } catch (e) {
          failed++;
        }
      }

      this.showFolderModal = false;
      showToast('success', `Added ${added}/${added + failed} images to folder`);
      this.addingToFolder = false;
      this.clearSelection();
      this.loadFolders();
    },

    // ====== Delete ======
    confirmDelete(img) {
      this.deleteTarget = img;
      this.deleteConfirmOpen = true;
    },

    async executeDelete() {
      if (!this.deleteTarget) return;
      try {
        const id = this.deleteTarget.id;
        await fetchJSON(`/api/library/image/${id}`, { method: 'DELETE' });
        this.images = this.images.filter(i => i.id !== id);
        this.selectedImages = this.selectedImages.filter(i => i.id !== id);
        showToast('success', 'Image deleted');
      } catch (e) {
        showToast('error', 'Delete failed: ' + e.message);
      }
      this.deleteConfirmOpen = false;
      this.deleteTarget = null;
    },

    async deleteSelected() {
      const count = this.selectedImages.length;
      if (!count) { showToast('warning', 'No images selected'); return; }
      if (!confirm(`Delete ${count} image${count === 1 ? '' : 's'}?`)) return;

      let deleted = 0;
      for (const img of [...this.selectedImages]) {
        try {
          const id = img.id;
          await fetchJSON(`/api/library/image/${id}`, { method: 'DELETE' });
          this.images = this.images.filter(i => i.id !== id);
          deleted++;
        } catch (e) { /* skip */ }
      }
      this.selectedImages = [];
      showToast('success', `Deleted ${deleted} image${deleted === 1 ? '' : 's'}`);
    },

    // ====== AI Batch ======
    async generateBatchAI() {
      if (!this.selectedImages.length) {
        showToast('warning', 'No images selected');
        return;
      }
      const ids = this.selectedImages.map(img => img.id).filter(Boolean);
      if (!ids.length) {
        showToast('warning', 'Selected images have no IDs');
        return;
      }

      if (!this.aiSettings.base_url || !this.aiSettings.api_key) {
        await this.loadAISettings();
        if (!this.aiSettings.base_url) {
          this.aiModalOpen = true;
          return;
        }
      }

      try {
        const result = await postJSON('/api/ai/generate/batch', {
          image_ids: ids,
          use_vision: false
        });
        if (result.success) {
          showToast('success', `Generated metadata for ${result.results?.length || ids.length} images`);
          this.search(); // Refresh
          this.clearSelection();
        } else {
          showToast('error', result.error || 'Batch generation failed');
        }
      } catch (e) {
        showToast('error', 'Batch generation failed: ' + e.message);
      }
    },

    // ====== Helpers ======
    get imageSrc() {
      return (img) => {
        // Library images use local_url from /downloads/
        return img?.local_url || img?.preview_url || img?.sample_url || img?.file_url || '';
      };
    },

    showRatingClass(img) {
      return img?.rating || 'unknown';
    },

    tagList(img) {
      return (img?.tags || []).slice(0, 5);
    }
  };
}
