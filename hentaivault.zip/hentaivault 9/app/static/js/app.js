/**
 * HentaiVault - Shared JavaScript Utilities
 * Toast notification system, API helpers, global Alpine store for AI settings
 */

// ====== Toast Notification System ======

/**
 * Show a toast notification
 * @param {'success'|'error'|'warning'|'info'} type
 * @param {string} message
 * @param {number} [duration=5000] - milliseconds before auto-dismiss
 */
function showToast(type, message, duration) {
  window.dispatchEvent(new CustomEvent('show-toast', {
    detail: { type, message, duration: duration || 5000 }
  }));
}

// ====== API Helper Functions ======

/**
 * Fetch JSON with built-in error handling
 * @param {string} url
 * @param {RequestInit} [options]
 * @returns {Promise<any>}
 */
async function fetchJSON(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    let detail = text;
    try {
      const j = JSON.parse(text);
      detail = j.detail || j.message || text;
    } catch (_) {}
    throw new Error(detail || `HTTP ${res.status}`);
  }
  return res.json();
}

/**
 * POST JSON to an endpoint
 * @param {string} url
 * @param {any} data
 * @returns {Promise<any>}
 */
async function postJSON(url, data) {
  return fetchJSON(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
}

/**
 * PUT JSON to an endpoint
 */
async function putJSON(url, data) {
  return fetchJSON(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
}

// ====== Formatting Utilities ======

/**
 * Format bytes into human-readable string
 * @param {number} bytes
 * @returns {string}
 */
function formatFileSize(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/**
 * Format a date string
 * @param {string} dateString
 * @returns {string}
 */
function formatDate(dateString) {
  if (!dateString) return '';
  const d = new Date(dateString);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// ====== DOM Utilities ======

/**
 * Debounce a function
 * @param {Function} fn
 * @param {number} wait - milliseconds
 * @returns {Function}
 */
function debounce(fn, wait) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

/**
 * Copy text to clipboard
 * @param {string} text
 * @returns {Promise<boolean>}
 */
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) {
    // Fallback for older browsers
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  }
}

// ====== Alpine.js Global Initialization ======

document.addEventListener('alpine:init', () => {

  // ---- Global AI Settings Store ----
  Alpine.store('aiSettings', {
    base_url: '',
    api_key: '',
    model: 'gpt-4o',

    async load() {
      try {
        const data = await fetchJSON('/api/ai/settings');
        this.base_url = data.base_url || '';
        this.api_key = data.api_key || '';
        this.model = data.model || 'gpt-4o';
      } catch (e) {
        console.warn('Could not load AI settings:', e.message);
      }
    },

    async save() {
      await postJSON('/api/ai/settings', {
        base_url: this.base_url,
        api_key: this.api_key,
        model: this.model
      });
      showToast('success', 'AI settings saved');
    },

    get configured() {
      return !!(this.base_url && this.api_key);
    },

    toObject() {
      return {
        base_url: this.base_url,
        api_key: this.api_key,
        model: this.model
      };
    }
  });

});

// ====== Global Alpine Component Mixin ======
// Provides shared AI modal state & methods for any page that includes the modals.

// This is a plain object used by page-level Alpine components via Object.assign.
// Pages can do: return { ...mixin, /* page-specific stuff */ }
const globalMixin = {
  // AI Settings Modal
  aiModalOpen: false,
  aiSettings: { base_url: '', api_key: '', model: 'gpt-4o' },
  savingAI: false,
  testingAI: false,
  testResult: null,

  // Image Modal
  modalOpen: false,
  selectedImage: null,
  generatingAI: false,
  stCopied: false,

  // Download tracking
  downloadJobs: [],

  async loadAISettings() {
    try {
      const data = await fetchJSON('/api/ai/settings');
      this.aiSettings = {
        base_url: data.base_url || '',
        api_key: data.api_key || '',
        model: data.model || 'gpt-4o'
      };
    } catch (e) {
      console.warn('Could not load AI settings:', e.message);
    }
  },

  async saveAISettings() {
    this.savingAI = true;
    this.testResult = null;
    try {
      await postJSON('/api/ai/settings', this.aiSettings);
      // Also sync to store
      const store = Alpine.store('aiSettings');
      store.base_url = this.aiSettings.base_url;
      store.api_key = this.aiSettings.api_key;
      store.model = this.aiSettings.model;
      this.aiModalOpen = false;
      showToast('success', 'AI settings saved ✓');
    } catch (e) {
      showToast('error', 'Failed to save: ' + e.message);
    } finally {
      this.savingAI = false;
    }
  },

  async testAIConnection() {
    this.testingAI = true;
    this.testResult = null;
    try {
      const data = await postJSON('/api/ai/test', this.aiSettings);
      this.testResult = {
        success: data.success !== false,
        message: data.message || data.detail || (data.success !== false ? 'Connected!' : 'Failed')
      };
      if (this.testResult.success) {
        showToast('success', 'AI connection test passed ✓');
      }
    } catch (e) {
      this.testResult = { success: false, message: e.message || 'Connection failed' };
      showToast('error', 'Connection test failed: ' + e.message);
    } finally {
      this.testingAI = false;
    }
  },

  // Open image detail modal
  openModal(image) {
    this.selectedImage = image;
    this.modalOpen = true;
  },

  // Download an image
  async downloadImage(img) {
    try {
      const data = await postJSON('/api/downloads/download', {
        images: [img],
        site: img?.source_site || img?.site
      });
      if (data.job_id) {
        this.downloadJobs = [...this.downloadJobs.filter(j => j.job_id !== data.job_id), {
          job_id: data.job_id,
          status: 'queued',
          total: data.total || 1,
          completed: 0,
          failed: 0
        }];
        showToast('success', `Download queued (${data.total || 1} image${data.total === 1 ? '' : 's'})`);
      }
    } catch (e) {
      showToast('error', 'Download failed: ' + e.message);
    }
  },

  // Generate AI Name for an image
  async generateAIName(img) {
    if (!img) return;
    this.generatingAI = true;

    // Ensure AI settings are loaded
    if (!this.aiSettings.base_url || !this.aiSettings.api_key) {
      await this.loadAISettings();
      if (!this.aiSettings.base_url || !this.aiSettings.api_key) {
        this.generatingAI = false;
        this.aiModalOpen = true;
        showToast('warning', 'Please configure AI settings first');
        return;
      }
    }

    try {
      const payload = {
        tags: img?.tags || [],
        character: img?.character || null,
        artist: img?.artist || null,
        local_filename: img?.local_filename || img?.local_url || null,
        base_url: this.aiSettings.base_url,
        api_key: this.aiSettings.api_key,
        model: this.aiSettings.model
      };

      // Include image_id if it exists (from DB)
      if (img?.id) payload.image_id = img.id;

      const data = await postJSON('/api/downloads/ai/generate-name', payload);

      if (data.success && data.generated_name) {
        // Update the image object in place
        img.st_name = data.generated_name;
        if (this.selectedImage === img) {
          this.selectedImage = { ...img, st_name: data.generated_name };
        }
        showToast('success', 'AI Name: ' + data.generated_name);
      } else {
        showToast('error', 'Failed to generate name');
      }
    } catch (e) {
      showToast('error', 'AI generation failed: ' + e.message);
    } finally {
      this.generatingAI = false;
    }
  },

  // Copy SillyTavern embed code
  async copySTEmbed(img) {
    const name = img?.st_name || img?.source_id || 'image';
    const code = `::img ${name}::`;
    const ok = await copyToClipboard(code);
    if (ok) {
      showToast('success', 'SillyTavern embed code copied!');
    } else {
      // Manual fallback
      prompt('Copy this code:', code);
    }
  }
};

// ====== Keyboard Shortcuts ======
document.addEventListener('keydown', (e) => {
  // Escape closes modals
  if (e.key === 'Escape') {
    // Alpine will handle x-show via x-trap / Alpine internals,
    // but we manually close for safety
    document.querySelectorAll('[x-data]').forEach(el => {
      const stack = el._x_dataStack;
      if (stack && stack.length) {
        const data = stack[0];
        if (data.modalOpen) data.modalOpen = false;
        if (data.aiModalOpen) data.aiModalOpen = false;
      }
    });
  }

  // Ctrl+K / Cmd+K → focus search input
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    const input = document.querySelector('input[type="text"][placeholder*="earch"], input[type="search"], input[name="q"]');
    if (input) input.focus();
  }
});

console.log('🎨 HentaiVault · v1.0');
