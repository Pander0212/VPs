"""
nHentai.net scraper - doujinshi/gallery site, HTML-based with gallery download
"""
from typing import Dict, List, Any, Optional
from app.scrapers.base import BaseScraper


class NhentaiScraper(BaseScraper):
    """nHentai.net scraper"""

    name = "nhentai"
    base_url = "https://nhentai.net"
    api_url = f"{base_url}/api/galleries"

    def get_headers(self) -> Dict[str, str]:
        headers = super().get_headers()
        headers["Referer"] = self.base_url
        return headers

    async def search(
        self,
        query: str,
        page: int = 1,
        rating: Optional[str] = None,
        artist: Optional[str] = None,
        character: Optional[str] = None,
        **filters
    ) -> Dict[str, Any]:
        """Search nHentai"""

        # Try API first
        api_result = await self._search_api(query, page, artist, character)
        if api_result and api_result.get("images"):
            return api_result

        # Fallback to HTML
        return await self._search_html(query, page, artist, character)

    async def _search_api(
        self,
        query: str,
        page: int,
        artist: Optional[str],
        character: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        """Search using nHentai JSON API"""
        params = {
            "query": query or "",
            "page": page,
            "per_page": 25,
        }

        try:
            data = await self.fetch_json(f"{self.base_url}/api/galleries/search", params)

            results = data.get("result", []) if isinstance(data, dict) else []
            if not results:
                return None

            images = []
            for gallery in results[:25]:
                images.append(self._parse_gallery(gallery))

            has_more = len(results) == 25
            return {"images": images, "total": len(images), "page": page, "has_more": has_more}
        except Exception as e:
            print(f"nHentai API error: {e}")
            return None

    async def _search_html(
        self,
        query: str,
        page: int,
        artist: Optional[str],
        character: Optional[str],
    ) -> Dict[str, Any]:
        """HTML scraping fallback"""
        from bs4 import BeautifulSoup

        search = query or ""
        if artist:
            search = f"{search} artist:{artist}" if search else f"artist:{artist}"
        if character:
            search = f"{search} character:{character}" if search else f"character:{character}"

        params = {"q": search.replace(" ", "+"), "page": page} if search else {"page": page}
        try:
            html = await self.fetch_html(f"{self.base_url}/search/", params)
            soup = BeautifulSoup(html, "html.parser")

            images = []
            containers = soup.find_all("div", class_="gallery")
            if not containers:
                containers = soup.find_all("a", class_="cover")

            for container in containers[:25]:
                try:
                    link = container.find("a") or (container if container.name == "a" else None)
                    if not link:
                        continue

                    href = link.get("href", "")
                    gid = href.split("/g/")[-1].rstrip("/") if "/g/" in href else ""
                    if not gid:
                        continue

                    # Cover image
                    img = link.find("img") if link.name != "img" else link
                    if not img and link.name != "img":
                        img = container.find("img")

                    preview_url = ""
                    if img:
                        src = img.get("src", "") or img.get("data-src", "")
                        if src:
                            preview_url = src if src.startswith("http") else f"{self.base_url}{src}"

                    # Title
                    caption = container.find("div", class_="caption") or container.find("span", class_="title")
                    title = caption.get_text(strip=True) if caption else ""

                    # Tags from container
                    tags_elem = container.find_all(["a", "span"], class_="tag")
                    tags = [t.get_text(strip=True) for t in tags_elem]

                    images.append({
                        "source_site": self.name,
                        "source_id": gid,
                        "source_url": f"{self.base_url}/g/{gid}",
                        "file_url": preview_url,
                        "preview_url": preview_url,
                        "sample_url": preview_url,
                        "width": None,
                        "height": None,
                        "file_ext": preview_url.split(".")[-1].split("?")[0] if preview_url else "jpg",
                        "tags": tags,
                        "artist": artist,
                        "character": character,
                        "rating": "explicit",
                        "score": 0,
                        "title": title,
                    })
                except Exception:
                    continue

            has_more = len(images) >= 25
            return {"images": images, "total": len(images), "page": page, "has_more": has_more}
        except Exception as e:
            print(f"nHentai HTML error: {e}")
            return {"images": [], "total": 0, "page": page, "has_more": False, "error": str(e)}

    def _parse_gallery(self, data: Dict) -> Dict[str, Any]:
        """Parse nHentai gallery data"""
        tags = []

        # Build tags from gallery tags
        for tag_data in data.get("tags", []):
            if isinstance(tag_data, dict):
                tag_type = tag_data.get("type", "")
                tag_name = tag_data.get("name", "")
                if tag_type and tag_name:
                    tags.append(f"{tag_type}:{tag_name}")
                elif tag_name:
                    tags.append(tag_name)

        # Cover image
        cover = data.get("images", {}).get("cover", {})
        cover_types = ["t", "w", "h", "l"]  # thumbnail, preview sizes
        preview_url = ""
        for ct in cover_types:
            cover_url = cover.get(ct, "")
            if cover_url:
                preview_url = cover_url
                break

        # Title
        title = data.get("title", {}).get("english", "") or data.get("title", {}).get("pretty", "")

        # Media ID
        media_id = data.get("media_id", "")

        return {
            "source_site": self.name,
            "source_id": str(data.get("id", "")),
            "source_url": f"{self.base_url}/g/{data.get('id')}",
            "file_url": preview_url,
            "preview_url": preview_url,
            "sample_url": preview_url,
            "width": None,
            "height": None,
            "file_ext": preview_url.split(".")[-1].split("?")[0] if preview_url else "jpg",
            "tags": tags,
            "artist": None,
            "character": None,
            "rating": "explicit",
            "score": data.get("num_favorites", 0),
            "title": title,
            "media_id": media_id,
            "num_pages": data.get("num_pages", 0),
        }

    async def get_image_details(self, image_id: str) -> Dict[str, Any]:
        """Get full gallery details with all page URLs"""
        try:
            data = await self.fetch_json(f"{self.base_url}/api/gallery/{image_id}")
            if data:
                return self._parse_gallery(data)
        except Exception:
            pass
        return None

    async def get_popular(self, timeframe: str = "week") -> Dict[str, Any]:
        data = await self.fetch_json(f"{self.base_url}/api/galleries/search", {"sort": "popular", "page": 1})
        results = data.get("result", []) if isinstance(data, dict) else []
        images = [self._parse_gallery(g) for g in results[:50]]
        return {"images": images, "total": len(images), "page": 1, "has_more": False}

    async def get_random(self, count: int = 20) -> Dict[str, Any]:
        try:
            data = await self.fetch_json(f"{self.base_url}/api/galleries/search", {"sort": "random", "page": 1})
        except Exception:
            data = None
        results = data.get("result", []) if isinstance(data, dict) and data else []
        images = [self._parse_gallery(g) for g in results[:count]]
        return {"images": images, "total": len(images), "page": 1, "has_more": False}

    async def get_tag_suggestions(self, partial: str) -> List[Dict[str, Any]]:
        """Get tag suggestions from nHentai"""
        try:
            data = await self.fetch_json(
                f"{self.base_url}/api/galleries/tagged", {"tag_id": partial, "page": 1}
            )
        except Exception:
            data = None

        suggestions = []
        if isinstance(data, dict):
            results = data.get("result", [])
            for g in results[:15]:
                for tag in g.get("tags", []):
                    if isinstance(tag, dict):
                        tag_name = tag.get("name", "")
                        if tag_name.lower().startswith(partial.lower()):
                            suggestions.append({
                                "tag": tag_name,
                                "count": tag.get("count", 0),
                                "type": tag.get("type", "general"),
                            })
        return suggestions[:15]
