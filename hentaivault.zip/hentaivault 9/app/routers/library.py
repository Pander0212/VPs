"""
Library router - scan, search, and manage local image library
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone
from fastapi import APIRouter, Query, HTTPException

from app.config import settings

router = APIRouter()

DOWNLOAD_DIR = Path(settings.downloads_dir)


@router.get("/library/images")
async def list_library_images(
    folder: str = Query(None, description="Filter by folder name"),
    search: str = Query(None, description="Search in tags/filename"),
    char: str = Query(None, description="Filter by character"),
    artist: str = Query(None, description="Filter by artist"),
    rating: str = Query(None, description="Filter by rating"),
    sort: str = Query("newest", description="Sort order: newest, oldest, name, score"),
    page: int = Query(1, ge=1),
    per_page: int = Query(50, ge=1, le=500),
):
    """
    Scan the /downloads directory (including subfolders), 
    load images with metadata, support search/filter.
    """
    all_images = []
    errors = []

    if not DOWNLOAD_DIR.exists():
        return {
            "images": [],
            "total": 0,
            "page": page,
            "per_page": per_page,
            "folders": [],
            "errors": ["Download directory does not exist"],
        }

    # Scan recursively
    for root, dirs, files in os.walk(DOWNLOAD_DIR):
        root_path = Path(root)
        rel_path = root_path.relative_to(DOWNLOAD_DIR)
        current_folder = str(rel_path) if str(rel_path) != "." else None

        for f in files:
            if f.endswith(".json"):
                continue  # Skip metadata files, process them alongside images

            filepath = root_path / f
            ext = filepath.suffix.lower()

            if ext not in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".mp4", ".webm"):
                continue

            try:
                stat = filepath.stat()
                file_size = stat.st_size
                modified = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)

                # Load metadata sidecar if exists
                meta = {}
                meta_path = filepath.with_suffix(filepath.suffix + ".json")
                if meta_path.exists():
                    try:
                        with open(meta_path, "r") as mf:
                            meta = json.load(mf)
                    except Exception:
                        pass

                # Build image entry
                entry = {
                    "filename": f,
                    "path": str(filepath.relative_to(DOWNLOAD_DIR)),
                    "full_path": str(filepath),
                    "folder": current_folder,
                    "file_size": file_size,
                    "file_ext": ext.lstrip("."),
                    "modified": modified.isoformat(),
                    # From metadata
                    "source_site": meta.get("source_site", ""),
                    "source_id": meta.get("source_id", ""),
                    "source_url": meta.get("source_url", ""),
                    "tags": meta.get("tags", []),
                    "artist": meta.get("artist"),
                    "character": meta.get("character"),
                    "rating": meta.get("rating"),
                    "score": meta.get("score", 0),
                    "width": meta.get("width"),
                    "height": meta.get("height"),
                    "st_name": meta.get("st_name", ""),  # SillyTavern generated name
                    "st_description": meta.get("st_description", ""),
                    "downloaded_at": meta.get("downloaded_at", ""),
                }

                all_images.append(entry)
            except Exception as e:
                errors.append(f"Error reading {f}: {e}")

    # Apply filters
    filtered = all_images

    if folder:
        filtered = [img for img in filtered if img["folder"] and folder in img["folder"]]

    if char:
        char_lower = char.lower()
        filtered = [
            img for img in filtered
            if (img["character"] and char_lower in img["character"].lower())
            or any(char_lower in t.lower() for t in img["tags"] if "character:" in t.lower())
        ]

    if artist:
        artist_lower = artist.lower()
        filtered = [
            img for img in filtered
            if (img["artist"] and artist_lower in img["artist"].lower())
            or any(artist_lower in t.lower() for t in img["tags"] if "artist:" in t.lower())
        ]

    if rating:
        filtered = [img for img in filtered if img["rating"] and img["rating"].lower() == rating.lower()]

    if search:
        search_lower = search.lower()
        filtered = [
            img for img in filtered
            if search_lower in img["filename"].lower()
            or search_lower in " ".join(img["tags"]).lower()
            or (img["character"] and search_lower in img["character"].lower())
            or (img["artist"] and search_lower in img["artist"].lower())
            or (img["st_name"] and search_lower in img["st_name"].lower())
        ]

    # Sort
    if sort == "newest":
        filtered.sort(key=lambda x: x["modified"] or "", reverse=True)
    elif sort == "oldest":
        filtered.sort(key=lambda x: x["modified"] or "")
    elif sort == "name":
        filtered.sort(key=lambda x: x["filename"].lower())
    elif sort == "score":
        filtered.sort(key=lambda x: x["score"] or 0, reverse=True)

    total = len(filtered)

    # Paginate
    start = (page - 1) * per_page
    end = start + per_page
    page_images = filtered[start:end]

    # Build folder tree
    folders = get_folder_tree()

    return {
        "images": page_images,
        "total": total,
        "page": page,
        "per_page": per_page,
        "has_more": end < total,
        "folders": folders,
        "errors": errors[:5],  # Only return first 5 errors
    }


def get_folder_tree():
    """Build folder structure tree from downloads directory"""
    tree = []
    if not DOWNLOAD_DIR.exists():
        return tree

    for entry in DOWNLOAD_DIR.iterdir():
        if entry.is_dir():
            # Count images in folder
            image_count = 0
            for f in entry.iterdir():
                if f.suffix.lower() in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".mp4", ".webm"):
                    image_count += 1

            tree.append({
                "name": entry.name,
                "path": str(entry.relative_to(DOWNLOAD_DIR)),
                "image_count": image_count,
            })

    # Sort alphabetically
    tree.sort(key=lambda x: x["name"].lower())
    return tree


@router.get("/library/folders")
async def list_folders():
    """Get folder tree structure"""
    return {"folders": get_folder_tree()}


@router.get("/library/image/{path:path}")
async def get_image_detail(path: str):
    """Get detailed info for a specific image"""
    filepath = DOWNLOAD_DIR / path
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="Image not found")

    stat = filepath.stat()
    meta = {}
    meta_path = filepath.with_suffix(filepath.suffix + ".json")
    if meta_path.exists():
        try:
            with open(meta_path, "r") as f:
                meta = json.load(f)
        except Exception:
            pass

    return {
        "path": str(filepath.relative_to(DOWNLOAD_DIR)),
        "full_path": str(filepath),
        "file_size": stat.st_size,
        "modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
        "metadata": meta,
    }


@router.post("/library/rename")
async def rename_library_image(old_path: str, new_name: str):
    """Rename an image in the library and update its metadata"""
    filepath = DOWNLOAD_DIR / old_path
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="File not found")

    ext = filepath.suffix
    new_filename = f"{new_name}{ext}"
    new_filepath = filepath.parent / new_filename

    counter = 1
    while new_filepath.exists():
        new_filename = f"{new_name}_{counter}{ext}"
        new_filepath = filepath.parent / new_filename
        counter += 1

    try:
        filepath.rename(new_filepath)

        # Update metadata sidecar
        meta_path = filepath.with_suffix(filepath.suffix + ".json")
        new_meta_path = new_filepath.with_suffix(new_filepath.suffix + ".json")
        if meta_path.exists():
            try:
                with open(meta_path, "r") as f:
                    meta = json.load(f)
                meta["st_name"] = new_name
                meta["renamed_at"] = datetime.now(timezone.utc).isoformat()
                with open(meta_path, "w") as f:
                    json.dump(meta, f, indent=2, ensure_ascii=False)
                meta_path.rename(new_meta_path)
            except Exception:
                pass

        return {
            "success": True,
            "old_name": old_path,
            "new_name": str(new_filepath.relative_to(DOWNLOAD_DIR)),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/library/image/{path:path}")
async def delete_library_image(path: str):
    """Delete an image from the library"""
    filepath = DOWNLOAD_DIR / path

    # Safety check - prevent directory traversal
    try:
        filepath.resolve().relative_to(DOWNLOAD_DIR.resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")

    if not filepath.exists():
        raise HTTPException(status_code=404, detail="File not found")

    try:
        filepath.unlink()
        # Delete metadata sidecar
        meta_path = filepath.with_suffix(filepath.suffix + ".json")
        if meta_path.exists():
            meta_path.unlink()
        return {"success": True, "deleted": str(filepath.relative_to(DOWNLOAD_DIR))}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
